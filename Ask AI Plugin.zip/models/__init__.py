"""
AI 模型模块初始化文件

此包包含所有 AI 模型的实现，包括基础模型抽象类和具体模型实现。
"""

from .base import (
    BaseAIModel,
    AIModelFactory,
    LOCAL_OPENAI_COMPAT_PROVIDER_IDS,
    KNOWN_PROVIDER_IDS,
    extract_provider_id,
)
from .grok import GrokModel
from .gemini import GeminiModel
from .deepseek import DeepseekModel
from .kimi import KimiModel
from .mistral import MistralModel
from .custom import CustomModel
from .openai import OpenAIModel
from .anthropic import AnthropicModel
from .nvidia import NvidiaModel
from .nvidia_free import NvidiaFreeModel
from .openrouter import OpenRouterModel
from .perplexity import PerplexityModel
from .ollama import OllamaModel
from .lmstudio import LMStudioModel
from .koboldcpp import KoboldCppModel

# 注册模型到工厂类
AIModelFactory.register_model('grok', GrokModel)
AIModelFactory.register_model('gemini', GeminiModel)
AIModelFactory.register_model('deepseek', DeepseekModel)
AIModelFactory.register_model('kimi', KimiModel)
AIModelFactory.register_model('mistral', MistralModel)
AIModelFactory.register_model('custom', CustomModel)
AIModelFactory.register_model('openai', OpenAIModel)
AIModelFactory.register_model('anthropic', AnthropicModel)
AIModelFactory.register_model('nvidia', NvidiaModel)
AIModelFactory.register_model('nvidia_free', NvidiaFreeModel)
AIModelFactory.register_model('openrouter', OpenRouterModel)
AIModelFactory.register_model('perplexity', PerplexityModel)
AIModelFactory.register_model('ollama', OllamaModel)
AIModelFactory.register_model('lmstudio', LMStudioModel)
AIModelFactory.register_model('koboldcpp', KoboldCppModel)

# 导出公共接口
__all__ = [
    'BaseAIModel',
    'AIModelFactory',
    'LOCAL_OPENAI_COMPAT_PROVIDER_IDS',
    'KNOWN_PROVIDER_IDS',
    'extract_provider_id',
    'GrokModel',
    'GeminiModel',
    'DeepseekModel',
    'KimiModel',
    'MistralModel',
    'CustomModel',
    'OpenAIModel',
    'AnthropicModel',
    'NvidiaModel',
    'NvidiaFreeModel',
    'OpenRouterModel',
    'PerplexityModel',
    'OllamaModel',
    'LMStudioModel',
    'KoboldCppModel',
]
