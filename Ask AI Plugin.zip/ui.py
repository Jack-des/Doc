#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
logger = logging.getLogger(__name__)

from datetime import datetime
from enum import auto
from .utils import mask_api_key, mask_api_key_in_text, safe_log_config, as_unicode_text
from PyQt5.Qt import (Qt, QMenu, QAction, QTextCursor, QApplication, 
                     QKeySequence, QMessageBox, QPixmap, QPainter, QSize, QTimer)
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QTextEdit, QPushButton, 
                            QHBoxLayout, QLabel, QComboBox, QApplication, 
                            QMessageBox, QScrollArea, QWidget, QSizePolicy, 
                            QFrame, QSplitter, QStatusBar, QTextBrowser, QTabWidget, QDialogButtonBox, QToolButton, QMenu, QAction, QToolTip, QGroupBox)
from PyQt5.QtCore import Qt, QTimer, QSize, pyqtSignal, QPoint, QRect, QEvent, QObject, QUrl
from calibre.gui2.actions import InterfaceAction
from calibre.gui2 import info_dialog
from calibre.gui2.keyboard import NameConflict
from calibre_plugins.ask_ai_plugin.config import ConfigDialog, get_prefs
from calibre_plugins.ask_ai_plugin.api import APIClient
from calibre_plugins.ask_ai_plugin.models.base import (
    LOCAL_OPENAI_COMPAT_PROVIDER_IDS,
    extract_provider_id,
)
from .i18n import get_translation, get_suggestion_template
from calibre_plugins.ask_ai_plugin.shortcuts_widget import ShortcutsWidget
from calibre_plugins.ask_ai_plugin.prompts_widget import PromptsWidget
from calibre_plugins.ask_ai_plugin.version import VERSION_DISPLAY, VERSION_STRING
from calibre_plugins.ask_ai_plugin.widgets import apply_button_style
from calibre_plugins.ask_ai_plugin.ui_constants import (
    SPACING_SMALL, SPACING_MEDIUM, SPACING_LARGE,
    MARGIN_MEDIUM, PADDING_MEDIUM,
    FONT_SIZE_LARGE
)
from calibre.utils.resources import get_path as I
import sys
import os
import time
import html

NOWTINY_SITE_URL = 'https://www.nowtiny.xyz/en'
NOWTINY_PLUGIN_MARKDOWN_URL = 'https://www.mobileread.com/forums/showthread.php?p=4591602'
NOWTINY_PLUGIN_TRADSIMP_URL = 'https://www.mobileread.com/forums/showthread.php?t=373788'
NOWTINY_PLUGIN_SIMPLE_GOAL_URL = 'https://www.mobileread.com/forums/showthread.php?p=4602877'
BOOKTOAST_PLUGIN_URL = (
    'https://www.mobileread.com/forums/showthread.php?p=4610192#post4610192'
)
ASK_AI_RELEASE_URL = 'https://www.mobileread.com/forums/showthread.php?p=4547077'

# Bump this when promoting a new related plugin so that card is highlighted again.
ABOUT_RELATED_HIGHLIGHT_ID = 'booktoast'
ABOUT_RELATED_HIGHLIGHT_SEEN_KEY = 'about_related_highlight_seen_id'
ABOUT_LATEST_UPDATE_SEEN_KEY = 'about_latest_update_seen_version'


def _about_unread():
    """Show the About button dot until the user opens About on this version."""
    prefs = get_prefs()
    return prefs.get(ABOUT_LATEST_UPDATE_SEEN_KEY) != VERSION_STRING


def _mark_about_seen():
    prefs = get_prefs()
    prefs[ABOUT_LATEST_UPDATE_SEEN_KEY] = VERSION_STRING


def _about_related_unread():
    prefs = get_prefs()
    return prefs.get(ABOUT_RELATED_HIGHLIGHT_SEEN_KEY) != ABOUT_RELATED_HIGHLIGHT_ID


def _mark_about_related_seen():
    prefs = get_prefs()
    prefs[ABOUT_RELATED_HIGHLIGHT_SEEN_KEY] = ABOUT_RELATED_HIGHLIGHT_ID

# 从 vendor 命名空间导入第三方库
from calibre_plugins.ask_ai_plugin.lib.ask_ai_plugin_vendor import markdown2
from calibre_plugins.ask_ai_plugin.lib.ask_ai_plugin_vendor import bleach

# 存储插件实例的全局变量
# 注意：不要在这里导入自己，会导致循环导入
plugin_instance = None

def get_suggestion_template_from_ui(lang_code):
    """获取指定语言的随机问题提示词模板"""
    from .i18n import get_suggestion_template
    return get_suggestion_template(lang_code)

class AskAIPluginUI(InterfaceAction):
    name = 'Ask AI Plugin'
    # 使用 Ctrl+K 作为默认快捷键，所有平台统一
    action_spec = ('Ask AI Plugin', 'images/ask_ai_plugin.png', 'Ask AI about this book', 'Ctrl+K')
    action_shortcut_name = 'Ask AI: Ask'
    action_type = 'global'
    
    def __init__(self, parent, site_customization):
        try:
            InterfaceAction.__init__(self, parent, site_customization)
        except Exception as e:
            pass
        self.api = None
        self.gui = parent
        # 初始化 i18n
        prefs = get_prefs()
        language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
        self.i18n = get_translation(language)
        
        # 保存对话框实例的引用
        self.ask_dialog = None
        
        # 保存插件实例到全局变量
        global plugin_instance
        plugin_instance = self

    @staticmethod
    def _remove_legacy_debug_log_handlers():
        """Remove file handlers from prior plugin versions that wrote ask_ai_plugin_logs."""
        root_logger = logging.getLogger()
        to_remove = []
        for handler in root_logger.handlers[:]:
            if isinstance(handler, logging.FileHandler):
                try:
                    if 'ask_ai_plugin_logs' in handler.baseFilename:
                        handler.close()
                        to_remove.append(handler)
                except (AttributeError, TypeError):
                    pass
        for handler in to_remove:
            root_logger.removeHandler(handler)
        
    def genesis(self):
        self._remove_legacy_debug_log_handlers()
        icon = get_icons('images/ask_ai_plugin.png')
        self.qaction.setIcon(icon)
        
        # 创建菜单
        self.menu = QMenu(self.gui)
        self.menu.setStyleSheet("""
            QMenu {
                min-width: 80px;
            }
        """)
        
        # 添加主要动作（在菜单中显示当前生效的快捷键提示）
        self.ask_action = QAction(self.i18n['menu_title'], self)
        self.ask_action.triggered.connect(self.show_dialog)
        try:
            # 复用 calibre 管理的主快捷键（实际注册在 menuless_qaction 上）
            self.ask_action.setShortcuts(self.menuless_qaction.shortcuts())
        except Exception:
            pass
        self.menu.addAction(self.ask_action)
        
        # 添加分隔符
        self.menu.addSeparator()

        # 添加配置菜单项（通过 calibre 快捷键系统注册，允许用户在 Preferences -> Shortcuts 中自定义）
        self.config_action = self.create_menu_action(
            self.menu,
            unique_name='open_configuration',
            text=self.i18n['config_title'],
            shortcut='F2',
            description=None,
            triggered=self.show_configuration,
            shortcut_name='Ask AI: Open Configuration',
            persist_shortcut=True,
        )

        # 添加分隔符
        self.menu.addSeparator()

        # 添加 AI Search 菜单项（通过 calibre 快捷键系统注册，允许用户在 Preferences -> Shortcuts 中自定义）
        self.library_action = self.create_menu_action(
            self.menu,
            unique_name='open_ai_search',
            text=self.i18n.get('library_search', 'AI Search'),
            shortcut='Ctrl+Shift+L',
            description=None,
            triggered=self.show_library,
            shortcut_name='Ask AI: AI Search',
            persist_shortcut=True,
        )

        # 添加分隔符
        self.menu.addSeparator()

        # 添加 Prompts 菜单项
        self.prompts_action = QAction(self.i18n.get('prompts_tab', 'Prompts'), self)
        self.prompts_action.triggered.connect(self.show_prompts)
        self.menu.addAction(self.prompts_action)

        # 添加分隔符
        self.menu.addSeparator()

        # 添加 Shortcuts 菜单项
        self.shortcuts_action = QAction(self.i18n.get('shortcuts', 'Shortcuts'), self)
        self.shortcuts_action.triggered.connect(self.show_shortcuts)
        self.menu.addAction(self.shortcuts_action)

        # 添加分隔符
        self.menu.addSeparator()

        # 添加 Statistics 菜单项
        self.stat_action = QAction(self.i18n.get('stat_tab', 'Stat'), self)
        self.stat_action.triggered.connect(self.show_statistics)
        self.menu.addAction(self.stat_action)

        # 添加分隔符
        self.menu.addSeparator()

        # 添加 Tutorial 菜单项
        self.tutorial_action = QAction(self.i18n.get('tutorial', 'Tutorial'), self)
        self.tutorial_action.triggered.connect(self.show_tutorial)
        self.menu.addAction(self.tutorial_action)

        # 注册对话框内快捷键（始终出现在 Preferences -> Shortcuts 中）
        # 注意：实际 QAction 会在 AskDialog 创建时通过 replace_action 绑定到对话框 action 上
        try:
            self.gui.keyboard.register_shortcut(
                self.unique_name + ' - ask_dialog_send',
                'Ask AI: Send (in dialog)',
                default_keys=('Ctrl+Enter',),
                action=None,
                description=None,
                group=self.action_spec[0],
                persist_shortcut=True,
            )
        except NameConflict:
            pass
        except Exception:
            pass

        try:
            self.gui.keyboard.register_shortcut(
                self.unique_name + ' - ask_dialog_random_question',
                'Ask AI: Random Question (in dialog)',
                default_keys=('Ctrl+Shift+R',),
                action=None,
                description=None,
                group=self.action_spec[0],
                persist_shortcut=True,
            )
        except NameConflict:
            pass
        except Exception:
            pass

        # 如果快捷键被标记为 Custom 但 keys 为空（通常来自冲突或旧版本遗留），
        # 则清理该空映射，让 calibre 回退使用 default_keys。
        try:
            send_un = self.unique_name + ' - ask_dialog_send'
            rand_un = self.unique_name + ' - ask_dialog_random_question'
            m = self.gui.keyboard.config.get('map', {}) or {}
            if m.get(send_un) in ((), [], None):
                with self.gui.keyboard.config:
                    m2 = self.gui.keyboard.config.get('map', {}) or {}
                    if m2.get(send_un) in ((), [], None):
                        m2.pop(send_un, None)
                        self.gui.keyboard.config['map'] = m2
            if m.get(rand_un) in ((), [], None):
                with self.gui.keyboard.config:
                    m2 = self.gui.keyboard.config.get('map', {}) or {}
                    if m2.get(rand_un) in ((), [], None):
                        m2.pop(rand_un, None)
                        self.gui.keyboard.config['map'] = m2
        except Exception:
            pass

        try:
            self.gui.keyboard.finalize()
        except Exception:
            pass
        
        # 设置菜单更新事件
        self.menu.aboutToShow.connect(self.about_to_show_menu)
        
        # 设置主图标点击和菜单
        self.qaction.triggered.connect(self.show_dialog)
        self.qaction.setMenu(self.menu)
        self._update_toolbar_text()

    def _update_toolbar_text(self, language=None):
        """更新工具栏主按钮显示名称（action_spec[0] 保持英文供内部标识）。"""
        if language is None:
            prefs = get_prefs()
            language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
        self.i18n = get_translation(language)
        self.qaction.setText(self.i18n.get('plugin_name', 'Ask AI Plugin'))

    def about_to_show_menu(self):
        # 更新菜单项的文本
        prefs = get_prefs()
        language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
        self.i18n = get_translation(language)
        self._update_toolbar_text(language)
        
        # 同步 Ask 菜单项显示的快捷键（跟随用户在 Preferences->Shortcuts 的自定义）
        # macOS 上需要手动将快捷键文本添加到菜单项中
        try:
            shortcuts = self.menuless_qaction.shortcuts()
            self.ask_action.setShortcuts(shortcuts)
            if shortcuts:
                shortcut_text = shortcuts[0].toString()
                self.ask_action.setText(f"{self.i18n['menu_title']}\t{shortcut_text}")
            else:
                self.ask_action.setText(self.i18n['menu_title'])
        except Exception:
            self.ask_action.setText(self.i18n['menu_title'])
        
        # 更新 Configuration 菜单项（包含快捷键）
        try:
            config_shortcuts = self.config_action.shortcuts()
            if config_shortcuts:
                shortcut_text = config_shortcuts[0].toString()
                self.config_action.setText(f"{self.i18n['config_title']}\t{shortcut_text}")
            else:
                self.config_action.setText(self.i18n['config_title'])
        except Exception:
            self.config_action.setText(self.i18n['config_title'])
        
        self.prompts_action.setText(self.i18n.get('prompts_tab', 'Prompts'))
        
        # 更新 AI Search 菜单项（包含快捷键）- macOS 需要手动添加快捷键文本
        try:
            library_shortcuts = self.library_action.shortcuts()
            if library_shortcuts:
                shortcut_text = library_shortcuts[0].toString()
                self.library_action.setText(f"{self.i18n.get('library_search', 'AI Search')}\t{shortcut_text}")
            else:
                self.library_action.setText(self.i18n.get('library_search', 'AI Search'))
        except Exception:
            self.library_action.setText(self.i18n.get('library_search', 'AI Search'))
        
    def initialize_api(self):
        try:
            # 初始化 API 客户端
            prefs = get_prefs()
            language = prefs.get('language', 'en')
            self.i18n = get_translation(language)
            
            # 创建新的 API 客户端，不再需要传递 api_base、model 和 auth_token 参数
            # 因为这些参数现在由 AIModelFactory 根据配置动态创建
            self.api = APIClient(i18n=self.i18n)
            
            # 记录当前使用的模型
            model_name = self.api.model_name
            model_display_name = self.api.model_display_name
            logger.info(f"API 客户端初始化成功，使用模型: {model_display_name} ({model_name})")
        except Exception as e:
            logger.error(f"初始化 API 客户端时出错: {str(e)}")
    
    def apply_settings(self):
        # 应用新的设置
        prefs = get_prefs()
        language = prefs.get('language', 'en')
        self.i18n = get_translation(language)
        
        # 重新加载 API 模型
        if self.api:
            self.api.reload_model()
            model_name = self.api.model_name
            model_display_name = self.api.model_display_name
            logger.info(f"设置已应用，当前使用模型: {model_display_name} ({model_name})")
    
    def show_configuration(self):
        """显示配置对话框"""
        dlg = TabDialog(self.gui)
        dlg.tab_widget.setCurrentIndex(0)  # 默认显示配置标签页
        dlg.exec_()
    
    def show_dialog(self, force_ai_search=False):
        logger.info("=" * 50)
        logger.info(f"show_dialog() 被调用, force_ai_search={force_ai_search}")
        
        try:
            self.initialize_api()
            logger.info("API 初始化完成")
            
            # 检查是否有配置的AI模型
            if not self.api or not self.api._ai_model:
                # 检查是否有 nvidia_free 配置
                prefs = get_prefs()
                has_nvidia_free = prefs.get('models', {}).get('nvidia_free', {}).get('enabled', False)
                
                # 如果有 nvidia_free，不显示此提醒（会显示欢迎提醒）
                if has_nvidia_free:
                    logger.info("有 Nvidia Free 配置，跳过'未配置AI'提醒")
                else:
                    logger.warning("未配置AI模型，显示友好提示")
                    from PyQt5.QtWidgets import QMessageBox
                    
                    # 创建自定义消息框
                    msg_box = QMessageBox(self.gui)
                    msg_box.setWindowTitle(self.i18n.get('no_ai_configured_title', 'No AI Configured'))
                    msg_box.setText(self.i18n.get('no_ai_configured_message', 
                        'Welcome! To start asking questions about your books, you need to configure an AI provider first.\n\n'
                        'Good News: This plugin now has a FREE tier (Nvidia AI Free) that you can use immediately without any configuration!\n\n'
                        'Other Recommended Options:\n'
                        '• Nvidia AI - Get 6 months FREE API access with just your phone number (no credit card required)\n'
                        '• Ollama - Run AI models locally on your computer (completely free and private)\n\n'
                        'Would you like to open the plugin configuration to set up an AI provider now?'))
                    msg_box.setIcon(QMessageBox.Information)
                    
                    # 添加自定义按钮（按从左到右的顺序）
                    open_settings_btn = msg_box.addButton(
                        self.i18n.get('open_settings', 'Plugin Configuration'), 
                        QMessageBox.AcceptRole
                    )
                    ask_anyway_btn = msg_box.addButton(
                        self.i18n.get('ask_anyway', 'Ask Anyway'), 
                        QMessageBox.ActionRole
                    )
                    later_btn = msg_box.addButton(
                        self.i18n.get('later', 'Later'), 
                        QMessageBox.RejectRole
                    )
                    
                    msg_box.exec_()
                    
                    clicked_btn = msg_box.clickedButton()
                    
                    # 如果用户点击"打开设置"
                    if clicked_btn == open_settings_btn:
                        self.show_configuration()
                        return
                    # 如果用户点击"仍要询问"，继续执行，打开询问弹窗
                    elif clicked_btn == ask_anyway_btn:
                        logger.info("用户选择仍要询问，继续打开询问弹窗")
                        # 不return，继续执行下面的代码
                    # 如果用户点击"稍后"，直接返回
                    else:
                        return
            
            # 获取选中的书籍
            if force_ai_search:
                rows = []
                logger.info("强制 AI Search 模式")
            else:
                rows = self.gui.library_view.selectionModel().selectedRows()
                logger.info(f"获取选中的书籍行数: {len(rows) if rows else 0}")
            
            if not rows or len(rows) == 0:
                logger.info("没有选中的书籍，检查是否可以使用AI搜索")
                
                # 检查图书馆书籍数量是否足够（至少20本）
                db = self.gui.current_db
                book_count = db.count()
                logger.info(f"当前图书馆书籍数量: {book_count}")
                
                MIN_BOOKS_FOR_AI_SEARCH = 20
                if book_count < MIN_BOOKS_FOR_AI_SEARCH:
                    logger.warning(f"书籍数量不足，需要至少 {MIN_BOOKS_FOR_AI_SEARCH} 本书才能使用AI搜索")
                    from PyQt5.QtWidgets import QMessageBox
                    message = self.i18n.get('ai_search_not_enough_books_message', 
                        'AI Search requires at least {min_books} books in your library.\n\n'
                        'Your current library has only {book_count} book(s).\n\n'
                        'Please add more books to your library to use AI Search.')
                    message = message.format(min_books=MIN_BOOKS_FOR_AI_SEARCH, book_count=book_count)
                    QMessageBox.information(
                        self.gui,
                        self.i18n.get('ai_search_not_enough_books_title', 'Not Enough Books'),
                        message
                    )
                    return
                
                logger.info("书籍数量足够，同步AI搜索元数据（未变更则跳过重建）")
                prefs = get_prefs()
                # 确保注入门闩打开（不依赖用户是否打开过 Search 配置页）
                prefs['library_chat_enabled'] = True
                from .utils import update_library_metadata
                try:
                    update_library_metadata(self.gui.current_db, prefs, force=False)
                    logger.info("AI搜索元数据已就绪")
                except Exception as e:
                    logger.warning(f"自动更新元数据失败: {e}")
                
                # 检查是否有AI搜索元数据
                library_metadata = prefs.get('library_cached_metadata', '')
                
                if library_metadata:
                    # 有数据，仅在首次使用时显示欢迎消息
                    if prefs.get('ai_search_first_time', True):
                        logger.info("AI搜索首次使用，显示欢迎消息")
                        from PyQt5.QtWidgets import QMessageBox
                        QMessageBox.information(
                            self.gui,
                            self.i18n.get('ai_search_welcome_title', 'Welcome to AI Search'),
                            self.i18n.get('ai_search_welcome_message', 
                                'You haven\'t selected any books, so AI Search is activated!\n\n'
                                'You can now search your entire library using natural language. '
                                'For example, try asking:\n'
                                '• "Do you have any books about Python?"\n'
                                '• "Show me books by Isaac Asimov"\n'
                                '• "Find books about machine learning"\n\n'
                                'AI will search through your library and recommend relevant books.')
                        )
                        # 标记为已显示过欢迎消息
                        prefs['ai_search_first_time'] = False
                    else:
                        logger.info("AI搜索非首次使用，跳过欢迎消息")
                    # 继续执行，不返回，让对话框打开
                    books_info = None  # 标记为AI搜索模式
                else:
                    # 无数据，提示用户初始化AI搜索
                    logger.warning("AI搜索无数据，提示用户初始化")
                    from PyQt5.QtWidgets import QMessageBox
                    reply = QMessageBox.question(
                        self.gui,
                        self.i18n.get('library_init_title', 'Initialize AI Search'),
                        self.i18n.get('library_init_message', 
                            'AI Search requires library metadata to work. Would you like to initialize it now?\n\n'
                            'This will extract book titles and authors from your library.'),
                        QMessageBox.Yes | QMessageBox.No,
                        QMessageBox.Yes
                    )
                    
                    if reply == QMessageBox.Yes:
                        # 打开配置对话框到Search标签页
                        from .ui import TabDialog
                        dlg = TabDialog(self.gui)
                        dlg.tab_widget.setCurrentIndex(1)  # Search tab
                        dlg.exec_()
                    return
            
            # 获取书籍信息
            if not rows or len(rows) == 0:
                # AI搜索模式，books_info已在上面设置为None
                logger.info("AI搜索模式: books_info=None")
            else:
                db = self.gui.current_db
                logger.info("获取数据库实例成功")
                
                # 统一处理单书和多书模式，遇到错误时跳过该书籍
                books_info = []
                failed_books = []
                for row in rows:
                    book_id = self.gui.library_view.model().id(row)
                    try:
                        mi = db.get_metadata(book_id, index_is_id=True)
                        books_info.append(mi)
                    except (OSError, Exception) as e:
                        logger.error(f"Failed to read book metadata (book_id={book_id}): {str(e)}")
                        failed_books.append(book_id)
                
                # 如果有失败的书籍，显示警告但继续处理成功的书籍
                if failed_books:
                    logger.warning(f"Skipped {len(failed_books)} books due to errors: {failed_books}")
                    if books_info:
                        # 有成功的书籍，显示警告信息
                        from PyQt5.QtWidgets import QMessageBox
                        msg = self.i18n.get('skipped_books_warning', 
                            'Skipped {count} book(s) due to file access errors.\nThis may be caused by invalid characters in file paths or files being locked by another program.')
                        msg = msg.format(count=len(failed_books))
                        QMessageBox.warning(self.gui, self.i18n.get('warning', 'Warning'), msg)
                
                # 如果没有成功读取任何书籍，显示错误并返回
                if not books_info:
                    from PyQt5.QtWidgets import QMessageBox
                    QMessageBox.critical(
                        self.gui,
                        self.i18n.get('error', 'Error'),
                        self.i18n.get('failed_to_read_all_books', 
                            'Failed to read metadata for all selected books.\nThis may be caused by invalid characters in file paths or files being locked by another program.')
                    )
                    return
                
                # 单书模式保持向后兼容
                if len(rows) == 1 and len(books_info) == 1:
                    books_info = books_info[0]
                    logger.info(f"Single book mode: book_id={books_info.id}, title={books_info.title}")
                else:
                    logger.info(f"Multi-book mode: {len(books_info)} books")
            
            # 显示对话框
            d = AskDialog(self.gui, books_info, self.api)
            
            # 保存对话框实例的引用
            self.ask_dialog = d
            
            # 对话框关闭时清除引用
            d.finished.connect(lambda result: setattr(self, 'ask_dialog', None))
            
            # 使用 show() 而不是 exec_() 使对话框非阻塞
            # 这样打开书籍时对话框可以保持打开状态
            d.show()
            d.raise_()
            d.activateWindow()
            from calibre_plugins.ask_ai_plugin.ui_constants import configure_ask_dialog_cursors
            configure_ask_dialog_cursors(d)
            
        except Exception as e:
            logger.error(f"show_dialog() error: {str(e)}", exc_info=True)
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.critical(
                self.gui,
                self.i18n.get('error', 'Error'),
                self.i18n.get('error_opening_dialog', 'Error opening dialog:') + f"\n{str(e)}"
            )
    
    def _show_deprecation_notice(self):
        """显示弃用通知对话框"""
        # 创建消息框
        msg_box = QMessageBox(self.gui)
        msg_box.setWindowTitle(self.i18n['deprecation_notice_title'])
        msg_box.setText(self.i18n['deprecation_notice_message'])
        msg_box.setIcon(QMessageBox.Information)
        
        # 添加按钮（按照添加顺序：左侧到右侧）
        # ActionRole 按钮显示在左侧，RejectRole 按钮显示在右侧
        dont_show_btn = msg_box.addButton(self.i18n['deprecation_dont_show_again'], QMessageBox.ActionRole)
        got_it_btn = msg_box.addButton(self.i18n['deprecation_got_it'], QMessageBox.RejectRole)
        msg_box.setDefaultButton(got_it_btn)
        
        # 显示对话框
        msg_box.exec_()
        
        # 处理用户选择
        clicked_button = msg_box.clickedButton()
        prefs = get_prefs()
        
        if clicked_button == dont_show_btn:
            # 用户选择"不再提醒"
            prefs['show_deprecation_notice'] = False
            logger.info("Deprecation notice disabled by user")
    
    def show_shortcuts(self):
        dlg = TabDialog(self.gui)
        dlg.tab_widget.setCurrentIndex(3)  # Shortcuts 标签页（第4个）
        dlg.exec_()
    
    def show_prompts(self):
        """显示 Prompts 配置对话框"""
        dlg = TabDialog(self.gui)
        dlg.tab_widget.setCurrentIndex(2)  # Prompts 标签页（第3个）
        dlg.exec_()
    
    def show_library(self):
        """打开 AI Search 对话框"""
        self.show_dialog(force_ai_search=True)
    
    def show_statistics(self):
        """显示 Statistics 统计对话框"""
        dlg = TabDialog(self.gui)
        dlg.tab_widget.setCurrentIndex(4)  # Statistics 标签页（第5个）
        dlg.exec_()
    
    def show_tutorial(self):
        """显示教程对话框"""
        dlg = TabDialog(self.gui)
        dlg.tab_widget.setCurrentIndex(5)  # Tutorial 标签页（第6个，现在是最后一个）
        dlg.exec_()
    
    def config_widget(self):
        """
        返回配置对话框组件
        这个方法被 calibre 的插件系统调用，用于显示插件配置界面
        """
        from calibre_plugins.ask_ai_plugin.config import ConfigDialog
        return ConfigDialog(self.gui)
    
    def save_settings(self, config_widget):
        """
        保存配置对话框中的设置
        
        Args:
            config_widget: 由 config_widget() 方法返回的配置组件
        """
        if hasattr(config_widget, 'save_settings'):
            config_widget.save_settings()

    def update_menu_texts(self, language=None):
        """更新菜单项的文本
        
        Args:
            language: 可选参数，指定要使用的语言。如果不指定，则从配置中读取。
        """
        import logging
        logger = logging.getLogger(__name__)
        
        try:
            # 保存原始状态
            original_texts = {
                'ask': self.ask_action.text(),
                'config': self.config_action.text(),
                'shortcuts': self.shortcuts_action.text(),
                'tutorial': self.tutorial_action.text(),
                'stat': self.stat_action.text(),
            }
            
            # 如果没有指定语言，从配置中读取
            if language is None:
                prefs = get_prefs()
                language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
            
            logger.debug(f"更新菜单文本，使用语言: {language}")
            
            # 更新文本
            self.i18n = get_translation(language)
            self.ask_action.setText(self.i18n['menu_title'])
            self.config_action.setText(self.i18n['config_title'])
            self.shortcuts_action.setText(self.i18n['shortcuts'])
            self.tutorial_action.setText(self.i18n.get('tutorial', 'Tutorial'))
            self.stat_action.setText(self.i18n.get('stat_tab', 'Stat'))
            self._update_toolbar_text(language)

        except Exception as e:
            # 发生错误时恢复原始状态
            logger.error(f"更新菜单文本时出错: {str(e)}")
            self.ask_action.setText(original_texts['ask'])
            self.config_action.setText(original_texts['config'])
            self.shortcuts_action.setText(original_texts['shortcuts'])
            self.tutorial_action.setText(original_texts['tutorial'])
            self.stat_action.setText(original_texts['stat'])

class AskGrokConfigWidget(QWidget):
    """配置页面组件"""
    # 定义与 ConfigDialog 相同的信号
    language_changed = pyqtSignal(str)
    settings_saved = pyqtSignal()  # 添加设置保存信号
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.gui = parent
        prefs = get_prefs()
        language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
        self.i18n = get_translation(language)
        
        # 创建主布局 - 使用统一的 Tab 布局函数
        from .ui_constants import setup_tab_widget_layout
        layout = setup_tab_widget_layout(self)
        
        # 复用现有的 ConfigDialog
        self.config_dialog = ConfigDialog(self.gui)
        layout.addWidget(self.config_dialog)
        
        # 连接 ConfigDialog 的信号，并转发出去
        self.config_dialog.language_changed.connect(self.on_language_changed)
        self.config_dialog.settings_saved.connect(self.settings_saved.emit)  # 转发设置保存信号
    
    def on_language_changed(self, lang_code):
        """当语言改变时更新界面并转发信号"""
        # 更新自身的语言
        self.i18n = get_translation(lang_code)
        
        # 在日志中输出语言变更信息
        import logging
        logger = logging.getLogger(__name__)
        logger.debug(f"语言已切换为: {lang_code}")
        
        # 转发语言变更信号
        self.language_changed.emit(lang_code)

class AboutWidget(QWidget):
    """Local About page with version info and themed recommendation cards."""

    def __init__(self, parent=None, highlight_related_id=None):
        super().__init__(parent)
        prefs = get_prefs()
        language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
        self.language = language
        self.i18n = get_translation(language)
        self._highlight_related_id = highlight_related_id
        self._recommendation_cards = []
        self._restyling = False
        self._build_ui()
        self.apply_translations()

    def _build_ui(self):
        from .ui_constants import setup_tab_widget_layout
        from calibre.gui2 import open_url

        outer = setup_tab_widget_layout(self)
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        content = QWidget()
        cl = QVBoxLayout(content)
        cl.setSpacing(SPACING_MEDIUM)
        cl.setContentsMargins(PADDING_MEDIUM, PADDING_MEDIUM, PADDING_MEDIUM, PADDING_MEDIUM)

        self.title_label = QLabel()
        title_font = self.title_label.font()
        title_font.setBold(True)
        title_font.setPointSize(title_font.pointSize() + 2)
        self.title_label.setFont(title_font)
        cl.addWidget(self.title_label)

        self.version_label = QLabel()
        cl.addWidget(self.version_label)

        self.description_label = QLabel()
        self.description_label.setWordWrap(True)
        cl.addWidget(self.description_label)

        self.latest_update_label = QLabel()
        self.latest_update_label.setWordWrap(True)
        cl.addWidget(self.latest_update_label)

        self.mobile_read_link_label = QLabel()
        self.mobile_read_link_label.setWordWrap(True)
        self.mobile_read_link_label.setTextFormat(Qt.RichText)
        self.mobile_read_link_label.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.mobile_read_link_label.setOpenExternalLinks(False)
        self.mobile_read_link_label.linkActivated.connect(
            lambda _url: open_url(QUrl(ASK_AI_RELEASE_URL))
        )
        cl.addWidget(self.mobile_read_link_label)

        self.section_divider_label = QLabel('---')
        cl.addWidget(self.section_divider_label)

        self.recommend_heading_label = QLabel()
        heading_font = self.recommend_heading_label.font()
        heading_font.setBold(True)
        self.recommend_heading_label.setFont(heading_font)
        cl.addWidget(self.recommend_heading_label)

        self.markdown_card, self.markdown_title, self.markdown_desc, self.markdown_btn = (
            self._create_recommendation_card(lambda: open_url(QUrl(NOWTINY_PLUGIN_MARKDOWN_URL)))
        )
        cl.addWidget(self.markdown_card)

        self.tradsimp_card, self.tradsimp_title, self.tradsimp_desc, self.tradsimp_btn = (
            self._create_recommendation_card(lambda: open_url(QUrl(NOWTINY_PLUGIN_TRADSIMP_URL)))
        )
        cl.addWidget(self.tradsimp_card)

        self.simple_goal_card, self.simple_goal_title, self.simple_goal_desc, self.simple_goal_btn = (
            self._create_recommendation_card(
                lambda: open_url(QUrl(NOWTINY_PLUGIN_SIMPLE_GOAL_URL)),
                highlighted=(self._highlight_related_id == 'simple_goal'),
            )
        )
        cl.addWidget(self.simple_goal_card)

        self.booktoast_card, self.booktoast_title, self.booktoast_desc, self.booktoast_btn = (
            self._create_recommendation_card(
                lambda: open_url(QUrl(BOOKTOAST_PLUGIN_URL)),
                highlighted=(self._highlight_related_id == 'booktoast'),
            )
        )
        cl.addWidget(self.booktoast_card)

        self.recommend_note_label = QLabel()
        self.recommend_note_label.setWordWrap(True)
        cl.addWidget(self.recommend_note_label)

        self.nowtiny_link_label = QLabel()
        self.nowtiny_link_label.setWordWrap(True)
        self.nowtiny_link_label.setTextFormat(Qt.RichText)
        self.nowtiny_link_label.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.nowtiny_link_label.setOpenExternalLinks(False)
        self.nowtiny_link_label.linkActivated.connect(
            lambda _url: open_url(QUrl(NOWTINY_SITE_URL))
        )
        cl.addWidget(self.nowtiny_link_label)

        cl.addStretch(1)
        scroll.setWidget(content)
        outer.addWidget(scroll)

    def _create_recommendation_card(self, on_open, highlighted=False):
        card = QWidget()
        card_layout = QHBoxLayout(card)
        card_layout.setContentsMargins(12, 10, 12, 10)
        card_layout.setSpacing(12)

        text_layout = QVBoxLayout()
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(2)

        title_label = QLabel()
        title_font = title_label.font()
        title_font.setBold(True)
        title_label.setFont(title_font)
        text_layout.addWidget(title_label)

        desc_label = QLabel()
        desc_label.setWordWrap(True)
        text_layout.addWidget(desc_label)
        card_layout.addLayout(text_layout, 1)

        # 卡片里的下划线文字链接，不是设置/工具栏按钮，不套用共享按钮字号和高度。
        action_btn = QPushButton()
        action_btn.setCursor(Qt.PointingHandCursor)
        action_btn.clicked.connect(on_open)
        card_layout.addWidget(action_btn, 0, Qt.AlignRight | Qt.AlignVCenter)

        self._style_recommendation_card(
            card, title_label, desc_label, action_btn, highlighted=highlighted
        )
        self._recommendation_cards.append(
            (card, title_label, desc_label, action_btn, highlighted)
        )
        return card, title_label, desc_label, action_btn

    def _style_recommendation_card(self, card, title_label, desc_label, action_btn, highlighted=False):
        """Match markdown-output recommendation cards (light/dark aware)."""
        try:
            from qt.core import QPalette
            window_role = QPalette.ColorRole.Window
        except Exception:
            from PyQt5.QtGui import QPalette
            window_role = QPalette.Window

        window_color = self.palette().color(window_role)
        is_dark_ui = window_color.lightness() < 128
        if is_dark_ui:
            card_bg = '#3a3d41'
            card_border = '#4a4d52'
            title_color = '#f2f2f2'
            desc_color = '#d0d0d0'
            link_color = '#66b3ff'
            link_hover_color = '#90c9ff'
            accent = '#ff8a65'
        else:
            card_bg = '#e8eaed'
            card_border = '#d7dadd'
            title_color = '#1a1a1a'
            desc_color = '#4a4a4a'
            link_color = '#0066cc'
            link_hover_color = '#004499'
            accent = '#e65100'

        card.setObjectName('recommendationCard')
        if highlighted:
            card.setStyleSheet(
                'QWidget#recommendationCard {{'
                'background: {};'
                'border: 1px solid {};'
                'border-left: 4px solid {};'
                'border-radius: 8px;'
                '}}'
                .format(card_bg, card_border, accent)
            )
        else:
            card.setStyleSheet(
                'QWidget#recommendationCard {{'
                'background: {};'
                'border: 1px solid {};'
                'border-radius: 8px;'
                '}}'
                .format(card_bg, card_border)
            )
        title_label.setStyleSheet('color: {}; background: transparent;'.format(title_color))
        desc_label.setStyleSheet('color: {}; background: transparent;'.format(desc_color))
        action_btn.setFlat(True)
        action_btn.setStyleSheet(
            'QPushButton {{'
            'color: {};'
            'background: transparent;'
            'border: none;'
            'text-decoration: underline;'
            'padding: 0;'
            '}}'
            'QPushButton:hover {{'
            'color: {};'
            '}}'
            .format(link_color, link_hover_color)
        )

    def _restyle_cards(self):
        if self._restyling:
            return
        self._restyling = True
        try:
            for card, title_label, desc_label, action_btn, highlighted in self._recommendation_cards:
                self._style_recommendation_card(
                    card, title_label, desc_label, action_btn, highlighted=highlighted
                )
        finally:
            self._restyling = False

    def changeEvent(self, event):
        if event.type() == QEvent.PaletteChange and not self._restyling:
            self._restyle_cards()
        super().changeEvent(event)

    def apply_translations(self):
        title = self.i18n.get('about_title', 'About Ask AI Plugin')
        version_label = self.i18n.get('about_version_label', 'Version')
        self.title_label.setText(title)
        self.version_label.setText('{}: {}'.format(version_label, VERSION_DISPLAY))
        self.description_label.setText(
            self.i18n.get(
                'about_description',
                'Ask questions about books in calibre, using the AI providers you choose.',
            )
        )
        self.latest_update_label.setText(
            self.i18n.get(
                'about_latest_update',
                'Latest update (2026.10.16): Updated to the latest model names',
            )
        )
        link_text = self.i18n.get('about_mobileread_link_text', 'MobileRead')
        self.mobile_read_link_label.setText(
            '<a href="{url}">{text}</a>'.format(url=ASK_AI_RELEASE_URL, text=html.escape(link_text))
        )
        self.recommend_heading_label.setText(
            self.i18n.get(
                'about_related_plugins',
                'Nowtiny calibre plugin recommendations',
            )
        )
        self.markdown_title.setText(
            self.i18n.get('about_markdown_title', 'Markdown for calibre')
        )
        self.markdown_desc.setText(
            self.i18n.get('about_markdown_desc', 'Export books as Markdown text files.')
        )
        self.tradsimp_title.setText(
            self.i18n.get('about_tradsimp_title', 'Chinese Text Conversion for calibre')
        )
        self.tradsimp_desc.setText(
            self.i18n.get(
                'about_tradsimp_desc',
                'Convert Traditional and Simplified Chinese in ebooks.',
            )
        )
        self.simple_goal_title.setText(
            self.i18n.get('about_simple_goal_title', 'Simple Goal for calibre')
        )
        self.simple_goal_desc.setText(
            self.i18n.get(
                'about_simple_goal_desc',
                'Keep a short list of books you are reading, see progress, and sync from the viewer.',
            )
        )
        self.booktoast_title.setText(
            self.i18n.get('about_booktoast_title', 'Booktoast for calibre')
        )
        self.booktoast_desc.setText(
            self.i18n.get(
                'about_booktoast_desc',
                'When calibre opens, briefly shows a highlight you once marked.',
            )
        )
        open_text = self.i18n.get('about_open_button', 'MobileRead')
        self.markdown_btn.setText(open_text)
        self.tradsimp_btn.setText(open_text)
        self.simple_goal_btn.setText(open_text)
        self.booktoast_btn.setText(open_text)
        self.recommend_note_label.setText(
            self.i18n.get(
                'about_mobileread_note',
                'Note: MobileRead is the developer page for calibre plugin releases and more version updates.',
            )
        )
        nowtiny_label = self.i18n.get('about_open_nowtiny', 'Open Nowtiny')
        nowtiny_note = self.i18n.get(
            'about_nowtiny_note',
            'More tools and plugin status are on Nowtiny.',
        )
        self.nowtiny_link_label.setText(
            '{note}<br><a href="{url}">{text}</a>'.format(
                note=html.escape(nowtiny_note),
                url=NOWTINY_SITE_URL,
                text=html.escape(nowtiny_label),
            )
        )

    def update_content(self):
        """更新内容（语言切换时调用）"""
        prefs = get_prefs()
        self.language = prefs.get('language', self.language) if hasattr(prefs, 'get') and callable(prefs.get) else self.language
        self.i18n = get_translation(self.language)
        self.apply_translations()
        self._restyle_cards()


class TutorialWidget(QWidget):
    """教程页面组件"""
    def __init__(self, parent=None):
        super().__init__(parent)
        prefs = get_prefs()
        language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
        self.i18n = get_translation(language)
        
        # 创建主布局 - 使用统一的 Tab 布局函数
        from .ui_constants import setup_tab_widget_layout
        layout = setup_tab_widget_layout(self)
        
        # 创建文本浏览器
        from PyQt5.QtWidgets import QTextBrowser, QFrame
        self.text_browser = QTextBrowser()
        self.text_browser.setOpenExternalLinks(False)  # 禁用链接点击
        self.text_browser.setReadOnly(True)  # 只读
        self.text_browser.setFrameShape(QFrame.NoFrame)  # 移除边框，与其他 Tab 保持一致
        layout.addWidget(self.text_browser)
        
        # 加载教程内容
        self.load_tutorial()
        
    def load_tutorial(self):
        """加载教程内容"""
        import logging
        logger = logging.getLogger(__name__)
        
        try:
            # 从插件资源读取教程
            from calibre.customize.ui import find_plugin
            plugin = find_plugin('Ask AI Plugin')
            
            if not plugin:
                self.text_browser.setHtml("<h2>Error: Plugin not found</h2>")
                return
            
            # Prefer the latest versioned tutorial; keep older names for upgrade mismatches
            tutorial_data = None
            matched = None
            for requested in (
                'tutorial/tutorial_v1.1.md',
                'tutorial/tutorial_v1.0.md',
                'tutorial/tutorial_v0.9.md',
                'tutorial/tutorial_v0.8.md',
            ):
                tutorial_data = plugin.get_resources(requested)
                if tutorial_data:
                    matched = requested
                    break
            
            if not tutorial_data:
                self.text_browser.setHtml("<h2>Error: Tutorial file not found</h2>")
                return
            
            tutorial_content = tutorial_data.decode('utf-8')
            
            # 转换 markdown 到 HTML
            html_content = self.markdown_to_html(tutorial_content)
            
            # 设置 HTML 内容
            self.text_browser.setHtml(html_content)
            
            logger.info(f"Tutorial loaded: {len(tutorial_content)} bytes from {matched}")
            
        except Exception as e:
            logger.error(f"Failed to load tutorial: {str(e)}")
            self.text_browser.setHtml(f"<h2>Error loading tutorial</h2><p>{str(e)}</p>")
    
    def markdown_to_html(self, markdown_text):
        """简单的 markdown 转 HTML - 极简风格"""
        import re
        
        lines = markdown_text.split('\n')
        result = []
        in_ul = False
        in_ol = False
        in_paragraph = False
        
        for line in lines:
            stripped = line.strip()
            
            # Headers
            if stripped.startswith('# '):
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                if in_paragraph:
                    result.append('</p>')
                    in_paragraph = False
                content = stripped[2:]
                result.append(f'<h1>{content}</h1>')
            elif stripped.startswith('## '):
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                if in_paragraph:
                    result.append('</p>')
                    in_paragraph = False
                content = stripped[3:]
                result.append(f'<h2>{content}</h2>')
            elif stripped.startswith('### '):
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                if in_paragraph:
                    result.append('</p>')
                    in_paragraph = False
                content = stripped[4:]
                result.append(f'<h3>{content}</h3>')
            # Horizontal rule
            elif stripped == '---':
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                if in_paragraph:
                    result.append('</p>')
                    in_paragraph = False
                result.append('<hr>')
            # Unordered list
            elif stripped.startswith('- '):
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                if in_paragraph:
                    result.append('</p>')
                    in_paragraph = False
                if not in_ul:
                    result.append('<ul>')
                    in_ul = True
                content = self._process_inline(stripped[2:])
                result.append(f'<li>{content}</li>')
            # Ordered list
            elif re.match(r'^\d+\.\s+', stripped):
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_paragraph:
                    result.append('</p>')
                    in_paragraph = False
                if not in_ol:
                    result.append('<ol>')
                    in_ol = True
                content = self._process_inline(re.sub(r'^\d+\.\s+', '', stripped))
                result.append(f'<li>{content}</li>')
            # Empty line
            elif not stripped:
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                if in_paragraph:
                    result.append('</p>')
                    in_paragraph = False
            # Regular text
            else:
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                if not in_paragraph:
                    result.append('<p>')
                    in_paragraph = True
                else:
                    result.append('<br>')
                result.append(self._process_inline(stripped))
        
        # Close any open tags
        if in_ul:
            result.append('</ul>')
        if in_ol:
            result.append('</ol>')
        if in_paragraph:
            result.append('</p>')
        
        html = '\n'.join(result)
        
        # 添加样式 - 极简主义风格，支持明暗模式
        styled_html = f"""
        <style>
            body {{ 
                font-family: Arial, sans-serif; 
                line-height: 1.65; 
                padding: 20px;
                color: palette(window-text);
                background: transparent;
            }}
            h1 {{ 
                color: palette(window-text); 
                border-bottom: 2px solid palette(mid); 
                padding-bottom: 10px;
                font-size: 1.5em;
                margin-top: 0.5em;
                margin-bottom: 0.8em;
            }}
            h2 {{ 
                color: palette(window-text); 
                font-weight: bold;
                font-size: 1em;
                margin-top: 1.5em;
                margin-bottom: 0.6em;
            }}
            h3 {{ 
                color: palette(window-text); 
                margin-top: 1.2em;
                margin-bottom: 0.5em;
                font-size: 1em;
                opacity: 0.85;
            }}
            code {{ 
                background: palette(alternate-base); 
                padding: 2px 5px; 
                font-family: monospace;
                color: palette(text);
                border-radius: 3px;
            }}
            ul {{ 
                margin-left: 12px;
                padding-left: 12px;
                color: palette(window-text);
                margin-top: 0.4em;
                margin-bottom: 0.6em;
            }}
            ol {{ 
                margin-left: 12px;
                padding-left: 12px;
                color: palette(window-text);
                margin-top: 0.4em;
                margin-bottom: 0.6em;
            }}
            li {{ 
                margin-bottom: 0.3em;
            }}
            hr {{ 
                border: none; 
                border-top: 1px solid palette(mid); 
                margin: 1.2em 0;
                opacity: 0.5;
            }}
            p {{
                color: palette(window-text);
                margin: 0.5em 0;
            }}
            strong {{
                color: palette(window-text);
                font-weight: bold;
            }}
        </style>
        {html}
        """
        
        return styled_html
    
    def _process_inline(self, text):
        """处理行内元素：粗体、代码、链接"""
        import re
        # Bold
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
        # Inline code
        text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
        # Links (keep text but remove link functionality)
        text = re.sub(r'\[([^\]]+)\]\(([^\)]+)\)', r'<span style="color: palette(link);">\1</span>', text)
        return text
    
    def update_content(self):
        """更新内容（语言切换时调用）"""
        self.load_tutorial()


class TabDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.gui = parent
        prefs = get_prefs()
        language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
        self.i18n = get_translation(language)
        
        # 设置窗口属性
        self.setWindowTitle(self.i18n['config_title'])
        self.setMinimumWidth(780)
        self.setMinimumHeight(650)
        # 设置初始窗口大小，确保有足够空间显示所有内容
        self.resize(900, 780)
        
        # 创建标签页
        self.tab_widget = QTabWidget()
        
        # 初始化标签页索引追踪
        self.last_tab_index = 0
        self.is_switching_tab = False  # 防止递归调用
        
        # 使用 tabBar 的 tabBarClicked 信号来在切换前检查
        self.tab_widget.tabBar().tabBarClicked.connect(self.on_tab_bar_clicked)
        
        # 连接标签页切换信号（用于更新UI状态）
        self.tab_widget.currentChanged.connect(self.on_tab_changed)

        # 创建General页面 (index 0)
        self.config_widget = AskGrokConfigWidget(self.gui)
        self.tab_widget.addTab(self.config_widget, self.i18n['general_tab'])
        
        # 语言变更信号已在下方连接到config_widget.config_dialog.language_changed

        # 创建Search页面 (index 1) - Killer feature!
        from .config import LibraryWidget
        self.library_widget = LibraryWidget(self, self.gui)
        self.tab_widget.addTab(self.library_widget, self.i18n.get('library_tab', 'Search'))
        
        # 连接Search页面的配置变更信号
        self.library_widget.config_changed.connect(self.update_save_button_state)

        # 创建Prompts页面 (index 2)
        self.prompts_widget = PromptsWidget(self)
        self.tab_widget.addTab(self.prompts_widget, self.i18n.get('prompts_tab', 'Prompts'))
        
        # 连接Prompts页面的配置变更信号
        self.prompts_widget.config_changed.connect(self.update_save_button_state)
        
        # 加载Prompts页面的初始值
        current_lang = get_prefs().get('language', 'en')
        self.prompts_widget.load_initial_values(current_lang)

        # 创建快捷键页面 (index 3)
        self.shortcuts_widget = ShortcutsWidget(self)
        self.tab_widget.addTab(self.shortcuts_widget, self.i18n['shortcuts'])

        # 创建统计页面 (index 4)
        from .statistics_widget import StatisticsWidget, init_statistics
        # 初始化统计数据（从历史记录同步）
        init_statistics(prefs)
        self.statistics_widget = StatisticsWidget(self)
        self.tab_widget.addTab(self.statistics_widget, self.i18n.get('stat_tab', 'Stat'))

        # 创建教程页面 (index 5)
        self.tutorial_widget = TutorialWidget()
        self.tab_widget.addTab(self.tutorial_widget, self.i18n.get('tutorial', 'Tutorial'))
        
        # 创建主布局
        layout = QVBoxLayout()
        layout.addWidget(self.tab_widget)
        
        # 创建按钮布局
        button_layout = QHBoxLayout()
        button_layout.setAlignment(Qt.AlignVCenter)
        
        # 添加左侧间距
        button_layout.addSpacing(10)
        
        # 获取配置对话框实例
        config_dialog = self.config_widget.config_dialog
        
        # 创建保存按钮（左侧）
        self.save_button = QPushButton(self.i18n.get('save_button', 'Save'))
        apply_button_style(self.save_button)
        self.save_button.clicked.connect(self.on_save_clicked)
        self.save_button.setEnabled(False)  # 初始化时禁用保存按钮
        button_layout.addWidget(self.save_button, 0, Qt.AlignVCenter)

        # About 与保存/关闭同级加入底栏，避免外包一层导致 macOS 原生按钮错位
        self.about_button = QPushButton(self.i18n.get('about', 'About'))
        apply_button_style(self.about_button)
        self.about_button.clicked.connect(self.show_about_dialog)
        button_layout.addWidget(self.about_button, 0, Qt.AlignVCenter)
        self.about_unread_dot = QLabel(self.about_button)
        self.about_unread_dot.setFixedSize(8, 8)
        self.about_unread_dot.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.about_unread_dot.raise_()
        self.about_button.installEventFilter(self)
        self._style_about_unread_dot()
        self._update_about_unread_dot()
        
        # 创建保存成功提示标签
        self.save_feedback_label = QLabel("")
        self.save_feedback_label.setStyleSheet("color: green; font-weight: bold;")
        self.save_feedback_label.hide()
        button_layout.addWidget(self.save_feedback_label)
        
        # 将配置对话框的配置变更信号连接到更新保存按钮状态的方法
        config_dialog.config_changed.connect(self.update_save_button_state)
        
        # 连接保存成功信号
        config_dialog.settings_saved.connect(self.on_settings_saved)
        
        # 添加弹性空间，使按钮分别位于左右两侧
        button_layout.addStretch()

        # 添加 Online Tutorial 链接
        self.online_tutorial_link = QLabel()
        self.online_tutorial_link.setTextFormat(Qt.RichText)
        self.online_tutorial_link.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.online_tutorial_link.setOpenExternalLinks(True)
        self.online_tutorial_link.setCursor(Qt.PointingHandCursor)
        self.online_tutorial_link.setText(f'<a href="https://ask-ai-blog.pages.dev/en/docs/">{self.i18n.get("online_tutorial", "Online Tutorial")}</a>')
        self.online_tutorial_link.setAlignment(Qt.AlignVCenter)
        self.online_tutorial_link.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        button_layout.addWidget(self.online_tutorial_link, 0, Qt.AlignVCenter)
        button_layout.addSpacing(12)

        # 添加 Reddit 链接（关闭按钮左侧）
        self.reddit_link = QLabel()
        self.reddit_link.setTextFormat(Qt.RichText)
        self.reddit_link.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.reddit_link.setOpenExternalLinks(True)
        self.reddit_link.setCursor(Qt.PointingHandCursor)
        self.reddit_link.setText('<a href="https://www.reddit.com/r/AskAIPlugin_calibre/">Reddit</a>')
        self.reddit_link.setAlignment(Qt.AlignVCenter)
        self.reddit_link.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        button_layout.addWidget(self.reddit_link, 0, Qt.AlignVCenter)
        button_layout.addSpacing(12)
        
        # 添加Close按钮（右侧）
        self.close_button = QPushButton(self.i18n.get('close_button', 'Close'))
        apply_button_style(self.close_button)
        self.close_button.clicked.connect(self.reject)
        button_layout.addWidget(self.close_button, 0, Qt.AlignVCenter)
        
        # 添加右侧间距
        button_layout.addSpacing(10)
        
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
        # 连接配置组件的信号
        self.config_widget.settings_saved.connect(self.on_settings_saved)
        self.config_widget.language_changed.connect(self.on_language_changed)

    def _style_about_unread_dot(self):
        if not hasattr(self, 'about_unread_dot'):
            return
        # Match button/label text color in light and dark themes (no accent red).
        text_color = self.about_button.palette().color(
            self.about_button.foregroundRole()
        ).name()
        self.about_unread_dot.setStyleSheet(
            'background-color: {}; border-radius: 4px; border: none;'.format(text_color)
        )

    def _update_about_unread_dot(self):
        if not hasattr(self, 'about_unread_dot'):
            return
        show = _about_unread()
        self.about_unread_dot.setVisible(show)
        if show:
            self._style_about_unread_dot()
            self._position_about_unread_dot()

    def _position_about_unread_dot(self):
        if not hasattr(self, 'about_unread_dot') or not hasattr(self, 'about_button'):
            return
        btn = self.about_button
        dot = self.about_unread_dot
        dot.move(max(0, btn.width() - dot.width() - 2), 2)

    def eventFilter(self, obj, event):
        if (
            hasattr(self, 'about_button')
            and obj is self.about_button
            and event.type() in (QEvent.Resize, QEvent.Show, QEvent.PaletteChange)
        ):
            if event.type() == QEvent.PaletteChange:
                self._style_about_unread_dot()
            self._position_about_unread_dot()
        return super().eventFilter(obj, event)

    def show_about_dialog(self, _url=None):
        """Open the local About page instead of a remote story URL."""
        highlight_id = ABOUT_RELATED_HIGHLIGHT_ID if _about_related_unread() else None
        _mark_about_related_seen()
        _mark_about_seen()
        self._update_about_unread_dot()

        dialog = QDialog(self)
        dialog.setWindowTitle(self.i18n.get('about_plugin', self.i18n.get('about', 'About')))
        dialog.resize(620, 640)
        layout = QVBoxLayout(dialog)
        layout.addWidget(AboutWidget(dialog, highlight_related_id=highlight_id))
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        ok_button = button_box.button(QDialogButtonBox.Ok)
        if ok_button is not None:
            ok_button.setText(self.i18n.get('close_button', 'Close'))
            apply_button_style(ok_button)
        button_box.accepted.connect(dialog.accept)
        layout.addWidget(button_box)
        dialog.exec_()
    
    def on_language_changed(self, new_language):
        """当语言改变时更新所有组件"""
        import logging
        logger = logging.getLogger(__name__)
        logger.debug(f"TabDialog接收到语言变更信号: {new_language}")
        
        self.i18n = get_translation(new_language)
        
        # 更新窗口标题
        self.setWindowTitle(self.i18n['config_title'])
        logger.debug(f"更新窗口标题为: {self.i18n['config_title']}")
        
        # 更新标签页标题 (6 tabs: General, Search, Prompts, Shortcuts, Stat, Tutorial)
        self.tab_widget.setTabText(0, self.i18n['general_tab'])
        self.tab_widget.setTabText(1, self.i18n.get('library_tab', 'Search'))
        self.tab_widget.setTabText(2, self.i18n.get('prompts_tab', 'Prompts'))
        self.tab_widget.setTabText(3, self.i18n['shortcuts'])
        self.tab_widget.setTabText(4, self.i18n.get('stat_tab', 'Stat'))
        self.tab_widget.setTabText(5, self.i18n.get('tutorial', 'Tutorial'))
        logger.debug("已更新标签页标题")
        
        # 更新底部链接文本
        if hasattr(self, 'online_tutorial_link'):
            self.online_tutorial_link.setText(f'<a href="https://ask-ai-blog.pages.dev/en/docs/">{self.i18n.get("online_tutorial", "Online Tutorial")}</a>')
        if hasattr(self, 'about_button'):
            self.about_button.setText(self.i18n.get('about', 'About'))
        logger.debug("已更新底部链接文本")
        
        # 更新 Prompts Widget 的 i18n
        if hasattr(self, 'prompts_widget'):
            self.prompts_widget.i18n = self.i18n
            self.prompts_widget.retranslate_ui()
            # 注意：retranslate_ui() 已经处理了模板的重新加载，不需要再调用 load_initial_values
        
        # 更新保存按钮文本
        if hasattr(self, 'save_button'):
            self.save_button.setText(self.i18n.get('save_button', 'Save'))
            logger.debug("已更新保存按钮文本")
        
        # 更新所有按钮文本（包括关闭按钮）
        for button in self.findChildren(QPushButton):
            button_text = button.text()
            # 更新关闭按钮
            if button_text in ['Close', '关闭', 'Закрыть', 'Fermer', 'Schließen', 'Cerrar', 'Chiudi', 'Fechar', 'Sluiten', 'Stäng', 'Lukk', 'Sulje', 'Luk', '閉じる', '關閉', '闭']:
                button.setText(self.i18n.get('close_button', 'Close'))
                logger.debug("已更新关闭按钮文本")
        
        # 也更新QDialogButtonBox中的按钮（如果存在）
        for button_box in self.findChildren(QDialogButtonBox):
            close_button = button_box.button(QDialogButtonBox.Close)
            if close_button:
                close_button.setText(self.i18n.get('close_button', 'Close'))
                logger.debug("已更新QDialogButtonBox关闭按钮文本")
        
        # 确保 ConfigDialog 实例也更新了语言
        if hasattr(self.config_widget, 'config_dialog'):
            logger.debug("更新ConfigDialog实例的语言")
            self.config_widget.config_dialog.i18n = self.i18n
            self.config_widget.config_dialog.retranslate_ui()
        
        # 更新Search页面（LibraryWidget）
        if hasattr(self, 'library_widget'):
            logger.debug("更新Search页面")
            self.library_widget.retranslate_ui()
        
        # 更新快捷键页面
        logger.debug("更新快捷键页面")
        self.shortcuts_widget.update_shortcuts()
        
        # 更新统计页面
        if hasattr(self, 'statistics_widget'):
            logger.debug("更新统计页面")
            self.statistics_widget.update_language(new_language)
        
        # 通知主界面更新菜单，直接传递新语言参数
        if plugin_instance:
            logger.debug(f"通知主界面更新菜单，语言: {new_language}")
            plugin_instance.update_menu_texts(new_language)
            
            # 更新主对话框的界面语言
            if hasattr(plugin_instance, 'ask_dialog') and plugin_instance.ask_dialog:
                logger.debug(f"更新主对话框的界面语言为: {new_language}")
                # 如果存在update_language方法，直接调用
                if hasattr(plugin_instance.ask_dialog, 'update_language'):
                    plugin_instance.ask_dialog.update_language(new_language)
                
                # 更新 response_handler 和 suggestion_handler 的 i18n 对象
                if hasattr(plugin_instance.ask_dialog, 'suggestion_handler'):
                    logger.debug("更新对话框组件的i18n对象")
                    plugin_instance.ask_dialog.response_handler.update_i18n(self.i18n)
                    plugin_instance.ask_dialog.suggestion_handler.update_i18n(self.i18n)
    
    def show_deprecation_notice(self):
        """显示弃用通知对话框"""
        # 创建消息框
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle(self.i18n['deprecation_notice_title'])
        msg_box.setText(self.i18n['deprecation_notice_message'])
        msg_box.setIcon(QMessageBox.Information)
        
        # 添加按钮（按照添加顺序：左侧到右侧）
        # ActionRole 按钮显示在左侧，RejectRole 按钮显示在右侧
        dont_show_btn = msg_box.addButton(self.i18n['deprecation_dont_show_again'], QMessageBox.ActionRole)
        got_it_btn = msg_box.addButton(self.i18n['deprecation_got_it'], QMessageBox.RejectRole)
        msg_box.setDefaultButton(got_it_btn)
        
        # 显示对话框
        msg_box.exec_()
        
        # 处理用户选择
        clicked_button = msg_box.clickedButton()
        prefs = get_prefs()
        
        if clicked_button == dont_show_btn:
            # 用户选择"不再提醒"
            prefs['show_deprecation_notice'] = False
            logger.info("Deprecation notice disabled by user from config dialog")
    
    def on_settings_saved(self):
        """当设置保存时的处理函数"""
        import logging
        logger = logging.getLogger(__name__)
        
        # 重新加载全局 API 实例
        from calibre_plugins.ask_ai_plugin.api import api
        api.reload_model()
        
        # 更新已打开的AskDialog实例的模型信息
        try:
            if plugin_instance and hasattr(plugin_instance, 'ask_dialog') and plugin_instance.ask_dialog:
                # 确保 AskDialog 的 API 实例也被重新加载
                if hasattr(plugin_instance.ask_dialog, 'api'):
                    plugin_instance.ask_dialog.api.reload_model()
                # 然后更新 UI 显示
                plugin_instance.ask_dialog.update_model_info()
                logger.info("配置已保存，模型信息已更新")
        except Exception as e:
            logger.error(f"更新模型信息时出错: {str(e)}")
        
        # 获取最新的语言设置
        new_language = get_prefs().get('language', 'en')
        # 更新界面
        self.on_language_changed(new_language)
    
    def keyPressEvent(self, event):
        """处理按键事件"""
        if event.key() == Qt.Key_Escape:
            # 如果配置页面有未保存的更改，先重置字段
            if hasattr(self, 'config_widget') and hasattr(self.config_widget, 'config_dialog') and hasattr(self.config_widget.config_dialog, 'check_for_changes'):
                # 使用check_for_changes方法检查是否有未保存的更改
                if self.config_widget.config_dialog.check_for_changes():
                    self.config_widget.config_dialog.reset_to_initial_values()
            # 关闭窗口
            self.reject()
        else:
            super().keyPressEvent(event)
    
    def on_tab_bar_clicked(self, target_index):
        """在标签页切换前检查未保存的更改
        
        :param target_index: 目标标签页索引
        """
        # 防止递归调用
        if self.is_switching_tab:
            return
        
        current_index = self.tab_widget.currentIndex()
        
        # 如果点击的是当前标签页，不需要检查
        if current_index == target_index:
            return
        
        # 检查当前标签页是否有未保存的更改
        if current_index == 1:  # Prompts tab
            if hasattr(self, 'prompts_widget') and self.prompts_widget.check_for_changes():
                # 创建自定义对话框以支持 i18n
                msg_box = QMessageBox(self)
                msg_box.setWindowTitle(self.i18n.get('unsaved_changes_title', 'Unsaved Changes'))
                msg_box.setText(self.i18n.get('unsaved_changes_message', 
                    'You have unsaved changes in the Prompts tab. Do you want to save them?'))
                msg_box.setIcon(QMessageBox.Question)
                
                # 添加自定义按钮（支持 i18n）
                yes_button = msg_box.addButton(self.i18n.get('yes_button', 'Yes'), QMessageBox.YesRole)
                no_button = msg_box.addButton(self.i18n.get('no_button', 'No'), QMessageBox.NoRole)
                cancel_button = msg_box.addButton(self.i18n.get('cancel_button', 'Cancel'), QMessageBox.RejectRole)
                msg_box.setDefaultButton(yes_button)
                
                msg_box.exec_()
                clicked_button = msg_box.clickedButton()
                
                if clicked_button == yes_button:
                    # 保存更改并切换
                    self.prompts_widget.save_settings()
                    self.on_settings_saved()
                    self.is_switching_tab = True
                    self.tab_widget.setCurrentIndex(target_index)
                    self.is_switching_tab = False
                elif clicked_button == no_button:
                    # 不保存，直接切换
                    self.is_switching_tab = True
                    self.tab_widget.setCurrentIndex(target_index)
                    self.is_switching_tab = False
                else:  # cancel_button
                    # 取消切换，停留在当前标签页
                    return
            else:
                # 没有未保存的更改，直接切换
                self.is_switching_tab = True
                self.tab_widget.setCurrentIndex(target_index)
                self.is_switching_tab = False
        else:
            # 其他标签页，直接切换
            self.is_switching_tab = True
            self.tab_widget.setCurrentIndex(target_index)
            self.is_switching_tab = False
    
    def on_tab_changed(self, index):
        """处理标签页切换事件（更新UI状态）
        
        :param index: 当前标签页索引
        """
        # 保存当前标签页索引
        self.last_tab_index = index
        
        # 在 General 标签页（索引为0）或 Prompts 标签页（索引为1）显示保存按钮
        if hasattr(self, 'save_button'):
            self.save_button.setVisible(index == 0 or index == 1)
            
            # 如果切换到 General 或 Prompts 标签页，更新保存按钮状态
            if index == 0 or index == 1:
                self.update_save_button_state()
        
        # 如果切换到 Statistics 标签页（索引为4），刷新统计数据
        if index == 4 and hasattr(self, 'statistics_widget'):
            self.statistics_widget.refresh_stats()
    
    def on_save_clicked(self):
        """处理保存按钮点击事件"""
        current_index = self.tab_widget.currentIndex()
        
        if current_index == 0:  # General tab
            if hasattr(self, 'config_widget') and hasattr(self.config_widget, 'config_dialog'):
                # 调用配置对话框的保存方法
                self.config_widget.config_dialog.save_settings()
        elif current_index == 1:  # Prompts tab
            if hasattr(self, 'prompts_widget'):
                self.prompts_widget.save_settings()
                self.on_settings_saved()
        elif current_index == 3:  # Library tab (Shortcuts是index 2)
            if hasattr(self, 'library_widget'):
                self.library_widget.save_settings()
                self.on_settings_saved()
    
    def on_settings_saved(self):
        """处理设置保存成功事件"""
        # 重新加载全局 API 实例，确保新默认模型生效
        try:
            from calibre_plugins.ask_ai_plugin.api import api
            api.reload_model()
        except Exception as e:
            logger.error(f"重新加载全局API失败: {str(e)}")

        # 刷新已打开的 AskDialog
        try:
            if plugin_instance and hasattr(plugin_instance, 'ask_dialog') and plugin_instance.ask_dialog:
                ask_dialog = plugin_instance.ask_dialog
                if hasattr(ask_dialog, 'api'):
                    ask_dialog.api.reload_model()
                ask_dialog.update_model_info()
                logger.info("配置已保存，已刷新 AskDialog 模型信息")
        except Exception as e:
            logger.error(f"刷新 AskDialog 模型信息失败: {str(e)}")

        # 同步语言（保存时语言可能发生变化）
        new_language = get_prefs().get('language', 'en')
        self.on_language_changed(new_language)

        # 禁用保存按钮
        if hasattr(self, 'save_button'):
            self.save_button.setEnabled(False)
        
        # 显示保存成功提示
        if hasattr(self, 'save_feedback_label'):
            self.save_feedback_label.setText(self.i18n.get('saved', 'Saved'))
            self.save_feedback_label.show()
            
            # 1秒后隐藏提示
            QTimer.singleShot(1000, self.save_feedback_label.hide)
    
    def update_save_button_state(self):
        """更新保存按钮的启用/禁用状态"""
        current_index = self.tab_widget.currentIndex()
        has_changes = False
        
        if current_index == 0:  # General tab
            if hasattr(self, 'config_widget') and hasattr(self.config_widget, 'config_dialog'):
                # 检查是否有配置变更
                config_dialog = self.config_widget.config_dialog
                has_changes = config_dialog.check_for_changes()
        elif current_index == 1:  # Prompts tab
            if hasattr(self, 'prompts_widget'):
                has_changes = self.prompts_widget.check_for_changes()
        elif current_index == 3:  # Library tab
            if hasattr(self, 'library_widget'):
                has_changes = self.library_widget.has_changes()
        
        # 根据是否有变更设置保存按钮状态
        if hasattr(self, 'save_button'):
            self.save_button.setEnabled(has_changes)
            
        # 如果有变更，隐藏保存成功提示
        if has_changes and hasattr(self, 'save_feedback_label'):
            self.save_feedback_label.hide()
    
    def reject(self):
        """处理关闭按钮"""
        import logging
        from PyQt5.QtWidgets import QMessageBox
        logger = logging.getLogger(__name__)
        
        # 检查 Prompts Tab 是否有未保存的更改
        if hasattr(self, 'prompts_widget') and self.prompts_widget.check_for_changes():
            logger.info("检测到 Prompts Tab 有未保存的更改，显示确认对话框")
            
            reply = QMessageBox.question(
                self,
                self.i18n.get('unsaved_changes_title', 'Unsaved Changes'),
                self.i18n.get('unsaved_changes_message', 
                    'You have unsaved changes in the Prompts tab. Do you want to save them?'),
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                QMessageBox.Yes
            )
            
            if reply == QMessageBox.Yes:
                self.prompts_widget.save_settings()
                super().reject()
            elif reply == QMessageBox.No:
                super().reject()
            else:
                return  # 取消关闭
        
        # 检查是否有未保存的输入框变化
        elif hasattr(self, 'config_widget') and hasattr(self.config_widget, 'config_dialog'):
            config_dialog = self.config_widget.config_dialog
            
            if config_dialog.has_unsaved_input_changes:
                logger.info("检测到未保存的输入框变化，显示确认对话框")
                
                # 创建自定义按钮的确认对话框
                msg_box = QMessageBox(self)
                msg_box.setWindowTitle(self.i18n.get('unsaved_changes_title', 'Unsaved Changes'))
                msg_box.setText(self.i18n.get('unsaved_changes_message', 'You have unsaved changes. What would you like to do?'))
                msg_box.setIcon(QMessageBox.Question)
                
                # 添加自定义按钮（支持 i18n）
                save_button = msg_box.addButton(
                    self.i18n.get('save_and_close', 'Save and Close'), 
                    QMessageBox.AcceptRole
                )
                discard_button = msg_box.addButton(
                    self.i18n.get('discard_changes', 'Discard Changes'), 
                    QMessageBox.DestructiveRole
                )
                cancel_button = msg_box.addButton(
                    self.i18n.get('cancel', 'Cancel'), 
                    QMessageBox.RejectRole
                )
                
                # 设置默认按钮为取消
                msg_box.setDefaultButton(cancel_button)
                
                # 显示对话框
                msg_box.exec_()
                clicked_button = msg_box.clickedButton()
                
                if clicked_button == save_button:
                    # 保存并关闭
                    logger.info("用户选择保存并关闭")
                    config_dialog.save_settings()
                    super().reject()
                elif clicked_button == discard_button:
                    # 不保存，直接关闭
                    logger.info("用户选择不保存，直接关闭")
                    super().reject()
                else:
                    # 取消关闭
                    logger.info("用户取消关闭操作")
                    return
            else:
                # 没有未保存的变化，检查默认 AI 是否有效配置
                if not self._check_default_ai_before_close():
                    # 用户取消关闭或选择切换默认 AI
                    return
                super().reject()
        else:
            super().reject()
    
    def _check_default_ai_before_close(self):
        """关闭前检查默认 AI 是否有效配置
        
        Returns:
            bool: True 表示可以关闭，False 表示用户取消关闭
        """
        import logging
        from PyQt5.QtWidgets import QMessageBox
        logger = logging.getLogger(__name__)
        
        prefs = get_prefs()
        default_ai = prefs.get('selected_model', 'grok')
        
        # 获取已配置的 AI 列表（复用 AskDialog 的逻辑）
        models_config = prefs.get('models', {})
        configured_ai_ids = []
        
        for ai_id, config in models_config.items():
            # 检查是否有模型名称
            has_model = bool(config.get('model', '').strip())
            if not has_model:
                continue
            
            # 检查是否有有效配置
            # 获取 provider_id（从 config 中获取，或从 ai_id 中提取）
            provider_id = extract_provider_id(ai_id, config)
            
            if provider_id in LOCAL_OPENAI_COMPAT_PROVIDER_IDS:
                has_valid_config = bool(config.get('api_base_url', '').strip())
                if not has_valid_config:
                    continue
            else:
                # 根据 provider_id 判断字段名（Grok 使用 auth_token，其他使用 api_key）
                token_field = 'auth_token' if provider_id == 'grok' else 'api_key'
                has_token = bool(config.get(token_field, '').strip())
                if not has_token:
                    continue
            
            configured_ai_ids.append(ai_id)
        
        # 检查默认 AI 是否在已配置列表中
        if default_ai not in configured_ai_ids:
            logger.warning(f"默认 AI ({default_ai}) 未有效配置")
            
            # 如果没有任何已配置的 AI，直接关闭
            if not configured_ai_ids:
                logger.warning("没有任何已配置的 AI")
                return True
            
            # 获取第一个已配置的 AI 的显示名称
            first_ai_id = configured_ai_ids[0]
            first_ai_config = models_config.get(first_ai_id, {})
            first_ai_name = first_ai_config.get('display_name', first_ai_id)
            
            # 获取默认 AI 的显示名称
            default_ai_config = models_config.get(default_ai, {})
            default_ai_name = default_ai_config.get('display_name', default_ai)
            
            # 弹窗询问用户
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle(self.i18n.get('invalid_default_ai_title', 'Invalid Default AI'))
            msg_box.setText(self.i18n.get('invalid_default_ai_message', 
                'The default AI "{default_ai}" is not properly configured.\n\n'
                'Would you like to switch to "{first_ai}" instead?').format(
                    default_ai=default_ai_name,
                    first_ai=first_ai_name
                ))
            msg_box.setIcon(QMessageBox.Warning)
            
            switch_button = msg_box.addButton(
                self.i18n.get('switch_to_ai', 'Switch to {ai}').format(ai=first_ai_name),
                QMessageBox.AcceptRole
            )
            keep_button = msg_box.addButton(
                self.i18n.get('keep_current', 'Keep Current'),
                QMessageBox.RejectRole
            )
            
            msg_box.setDefaultButton(switch_button)
            msg_box.exec_()
            
            if msg_box.clickedButton() == switch_button:
                # 切换到第一个已配置的 AI
                logger.info(f"用户选择切换默认 AI 到: {first_ai_id}")
                prefs['selected_model'] = first_ai_id
                
                # 更新 ConfigDialog 中的选择
                if hasattr(self, 'config_widget') and hasattr(self.config_widget, 'config_dialog'):
                    config_dialog = self.config_widget.config_dialog
                    if hasattr(config_dialog, 'model_combo'):
                        index = config_dialog.model_combo.findData(first_ai_id)
                        if index >= 0:
                            config_dialog.model_combo.setCurrentIndex(index)
                            logger.info(f"已更新 ConfigDialog 中的默认 AI 选择")
                
                return True
            else:
                # 保持当前设置
                logger.info("用户选择保持当前默认 AI 设置")
                return True
        
        # 默认 AI 有效配置，可以关闭
        return True


from calibre_plugins.ask_ai_plugin.response_handler import ResponseHandler
from calibre_plugins.ask_ai_plugin.random_question import SuggestionHandler


class AskDialog(QDialog):
    LANGUAGE_MAP = {
        # 英语（书籍语言名，不用界面“默认语言”标注，避免拼进请求）
        'en': 'English',
        'eng': 'English',
        
        # 丹麦语
        'da': 'Dansk',
        'dan': 'Dansk',
        
        # 德语
        'de': 'Deutsch',
        'deu': 'Deutsch',
        
        # 西班牙语
        'es': 'Español',
        'spa': 'Español',
        
        # 芬兰语
        'fi': 'Suomi',
        'fin': 'Suomi',
        
        # 法语
        'fr': 'Français',
        'fra': 'Français',
        
        # 日语
        'ja': '日本語',
        'jpn': '日本語',
        
        # 荷兰语
        'nl': 'Nederlands',
        'nld': 'Nederlands',
        
        # 挪威语
        'no': 'Norsk',
        'nor': 'Norsk',
        
        # 葡萄牙语
        'pt': 'Português',
        'por': 'Português',
        
        # 俄语
        'ru': 'Русский',
        'rus': 'Русский',
        
        # 瑞典语
        'sv': 'Svenska',
        'swe': 'Svenska',
        
        # 简体中文
        'zh': '简体中文',
        'zho': '简体中文',
        
        # 繁体中文
        'zh-hk': '繁體中文',
        'zh-tw': '繁體中文',
        'zht': '繁體中文',
        
        # 粤语
        'yue': '粵語',
        'zh-yue': '粵語',

        # 常见书籍语言（Calibre ISO 639）
        'ar': 'العربية',
        'ara': 'العربية',
        'he': 'עברית',
        'heb': 'עברית',
        'fa': 'فارسی',
        'per': 'فارسی',
        'ur': 'اردو',
        'ko': '한국어',
        'kor': '한국어',
        'th': 'ไทย',
        'tha': 'ไทย',
        'hi': 'हिन्दी',
        'hin': 'हिन्दी',
        'hi-in': 'हिन्दी',
        'bn': 'বাংলা',
        'ben': 'বাংলা',
        'ta': 'தமிழ்',
        'tam': 'தமிழ்',
        'te': 'తెలుగు',
        'tel': 'తెలుగు',
        'ml': 'മലയാളം',
        'mal': 'മലയാളം',
        'kn': 'ಕನ್ನಡ',
        'kan': 'ಕನ್ನಡ',
        'mr': 'मराठी',
        'mar': 'मराठी',
        'gu': 'ગુજરાતી',
        'guj': 'ગુજરાતી',
        'pa': 'ਪੰਜਾਬੀ',
        'pan': 'ਪੰਜਾਬੀ',
        'or': 'ଓଡ଼ିଆ',
        'ori': 'ଓଡ଼ିଆ',
        'as': 'অসমীয়া',
        'asm': 'অসমীয়া',
        'sa': 'संस्कृतम्',
        'san': 'संस्कृतम्',
        'ne': 'नेपाली',
        'nep': 'नेपाली',
        'id': 'Bahasa Indonesia',
        'ind': 'Bahasa Indonesia',
        'vi': 'Tiếng Việt',
        'vie': 'Tiếng Việt',
        'tr': 'Türkçe',
        'tur': 'Türkçe',
        'pl': 'Polski',
        'pol': 'Polski',
        'uk': 'Українська',
        'ukr': 'Українська',
        'cs': 'Čeština',
        'ces': 'Čeština',
        'el': 'Ελληνικά',
        'ell': 'Ελληνικά',
        'und': 'Unknown',
    }
    
    def __init__(self, gui, books_info, api, history_uid=None):
        """
        Args:
            books_info: 单个 Metadata 对象（单书模式）或 Metadata 列表（多书模式）
            history_uid: 可选，用于加载特定历史记录
        """
        import logging
        logger = logging.getLogger(__name__)
        
        try:
            super().__init__(gui)
            logger.info("QDialog 初始化完成")
            
            self.gui = gui
            self.api = api
            prefs = get_prefs()
            language = prefs.get('language', 'en') if hasattr(prefs, 'get') and callable(prefs.get) else 'en'
            self.i18n = get_translation(language)
            logger.info(f"语言设置: {language}")
        except Exception as e:
            logger.error(f"AskDialog.__init__() 初始化阶段1失败: {str(e)}", exc_info=True)
            raise
        
        # 统一处理为列表
        # 特殊处理：books_info 为 None 表示 AI 搜索模式
        if books_info is None:
            self.books_info = []  # AI搜索模式，无书籍
            self.is_multi_book = False
            self.book_info = None
            self.books_metadata = []
            self.book_metadata = None
        elif isinstance(books_info, list):
            self.books_info = books_info  # 多书模式
            self.is_multi_book = len(books_info) > 1
            self.book_info = self.books_info[0]  # 向后兼容
            self.books_metadata = [self._extract_metadata(book) for book in self.books_info]
            self.book_metadata = self.books_metadata[0]  # 向后兼容
        else:
            self.books_info = [books_info]  # 单书模式
            self.is_multi_book = False
            self.book_info = self.books_info[0]  # 向后兼容
            self.books_metadata = [self._extract_metadata(book) for book in self.books_info]
            self.book_metadata = self.books_metadata[0]  # 向后兼容
        
        # 生成或加载 UID
        # AI Search：优先上次会话；若本地有更新的记录则用最新（避免强杀 App 后指针过期）
        if not history_uid and not self.books_info:
            prefs = get_prefs()
            last_uid = prefs.get('ai_search_last_history_uid')
            from .history_manager import HistoryManager
            temp_history_manager = HistoryManager()
            ai_search_histories = temp_history_manager.get_ai_search_histories()
            newest = ai_search_histories[0] if ai_search_histories else None
            last_hist = (
                temp_history_manager.get_history_by_uid(last_uid) if last_uid else None
            )
            if last_hist and newest:
                if (last_hist.get('timestamp') or '') >= (newest.get('timestamp') or ''):
                    history_uid = last_uid
                    logger.info(
                        "AI Search mode, using last saved history UID: %s", last_uid
                    )
                else:
                    history_uid = newest['uid']
                    prefs['ai_search_last_history_uid'] = history_uid
                    prefs.commit()
                    logger.info(
                        "AI Search mode, last UID stale; loading newest: %s",
                        history_uid,
                    )
            elif last_hist:
                history_uid = last_uid
                logger.info(
                    "AI Search mode, using last saved history UID: %s", last_uid
                )
            elif newest:
                history_uid = newest['uid']
                logger.info(
                    "AI Search mode, loading newest history UID: %s", history_uid
                )
        
        self._explicit_history_uid = history_uid
        if history_uid:
            self.current_uid = history_uid
        else:
            self.current_uid = self._generate_uid()
        
        # 初始化处理器
        self.response_handler = ResponseHandler(self)
        # 确保 SuggestionHandler 正确初始化
        self.suggestion_handler = SuggestionHandler(parent=self)
        
        # 临时缓存：用于暂存随机问题（在用户点击发送前不保存历史）
        self._pending_random_question = None
        self._is_generating_random_question = False
        
        # 连接语言变更信号
        import logging
        logger = logging.getLogger(__name__)
        logger.debug("连接AskDialog到语言变更信号")
        
        # 将当前对话框保存到插件实例中，方便其他组件访问
        if plugin_instance:
            plugin_instance.ask_dialog = self
            logger.debug("已将AskDialog实例保存到插件实例中")
        
        
        # 设置当前书籍元数据到response_handler
        if hasattr(self.response_handler, 'history_manager'):
            self.response_handler.current_metadata = self.book_metadata
        
        # 读取保存窗口的大小
        prefs = get_prefs()
        self.saved_width = prefs.get('ask_dialog_width', 800)  # 增加默认宽度
        self.saved_height = prefs.get('ask_dialog_height', 600)
        
        # 设置窗口属性
        self.setWindowTitle(self.i18n['menu_title'])
        self.setMinimumWidth(500)  # 增加最小宽度
        self.setMinimumHeight(600)
        
        # 设置窗口标志，启用最大化和最小化按钮
        from PyQt5.QtCore import Qt
        self.setWindowFlags(
            Qt.Window |  # 作为独立窗口
            Qt.WindowMaximizeButtonHint |  # 启用最大化按钮
            Qt.WindowCloseButtonHint |  # 启用关闭按钮
            Qt.WindowTitleHint  # 显示标题栏
        )
        
        # 创建 UI
        self.setup_ui()
        
        # 设置处理器
        self.response_handler.setup(
            response_area=self.response_area,
            send_button=self.send_button,
            i18n=self.i18n,
            api=self.api,
            input_area=self.input_area,  # 添加输入区域
            stop_button=self.stop_button  # 添加停止按钮
        )
        self.suggestion_handler.setup(self.response_area, self.input_area, self.suggest_button, self.api, self.i18n, self.stop_button)
        
        # 添加事件过滤器
        self.input_area.installEventFilter(self)
        
        # 监听输入框内容变化，动态切换按钮高光状态
        self.input_area.textChanged.connect(self._update_button_focus)
        
        # 加载历史记录（仅在显式指定 history_uid 时加载）
        has_loaded_history = self._load_history()

        # 将 Preferences->Shortcuts 中的快捷键绑定到对话框 action（仅对话框窗口内生效）
        try:
            if plugin_instance and hasattr(plugin_instance, 'gui'):
                send_un = plugin_instance.unique_name + ' - ask_dialog_send'
                rand_un = plugin_instance.unique_name + ' - ask_dialog_random_question'

                plugin_instance.gui.keyboard.replace_action(send_un, self.send_action)
                plugin_instance.gui.keyboard.replace_action(rand_un, self.suggest_action)
                plugin_instance.gui.keyboard.finalize()

                # Fallback defaults: if calibre clears defaults due to conflicts,
                # keep dialog usable by applying a local WindowShortcut.
                # Do NOT override user customizations in Preferences->Shortcuts (including disabling).
                cfg_map = {}
                try:
                    cfg_map = plugin_instance.gui.keyboard.config.get('map', {}) or {}
                except Exception:
                    cfg_map = {}

                if (cfg_map.get(send_un) in (None, (), [])) and not self.send_action.shortcuts():
                    key = 'Ctrl+Enter'
                    self.send_action.setShortcuts([QKeySequence(key, QKeySequence.SequenceFormat.PortableText)])

                if (cfg_map.get(rand_un) in (None, (), [])) and not self.suggest_action.shortcuts():
                    key = 'Ctrl+Shift+R'
                    self.suggest_action.setShortcuts([QKeySequence(key, QKeySequence.SequenceFormat.PortableText)])
        except Exception:
            pass

        # 初始化后更新所有面板的按钮状态（包括导出历史按钮）
        if hasattr(self, 'response_panels') and self.response_panels:
            for panel in self.response_panels:
                if hasattr(panel, 'update_button_states'):
                    panel.update_button_states()
        
        # 设置窗口大小
        self.resize(self.saved_width, self.saved_height)

        # 连接窗口大小变化信号
        self.resizeEvent = self.on_resize
        
        # 检查默认 AI 是否与当前选中的 AI 一致
        # 只有在没有加载历史记录时才检查（新对话），避免与历史记录的AI冲突
        if not has_loaded_history:
            self._check_default_ai_mismatch()
            # 检查是否需要显示 Nvidia Free 首次使用提醒
            self._check_nvidia_free_first_use()

    def _register_dialog_shortcut(self, action, unique_suffix, shortcut_name, default_keys):
        try:
            if plugin_instance is not None and hasattr(plugin_instance, 'unique_name'):
                unique_name = f'{plugin_instance.unique_name} - {unique_suffix}'
            else:
                unique_name = f'Ask AI Plugin - {unique_suffix}'

            keys = ((default_keys,) if isinstance(default_keys, (str, bytes)) else tuple(default_keys))
            self.gui.keyboard.register_shortcut(
                unique_name,
                shortcut_name,
                default_keys=keys,
                action=action,
                description=None,
                group='Ask AI Plugin',
                persist_shortcut=True,
            )
            # Ensure shortcut dicts get fully initialized (including set_to_default)
            # and key conflicts are resolved for the newly registered shortcut.
            self.gui.keyboard.finalize()
        except NameConflict:
            pass
        except Exception:
            pass

    def _generate_uid(self):
        """生成唯一 UID"""
        import hashlib
        from datetime import datetime
        
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        # AI搜索模式：books_info 为空列表
        if self.books_info:
            book_ids = sorted([str(book.id) for book in self.books_info])
            book_ids_str = ','.join(book_ids)
        else:
            book_ids_str = 'ai_search'  # AI搜索模式标记
        unique_string = f"{timestamp}_{book_ids_str}"
        uid_hash = hashlib.md5(unique_string.encode()).hexdigest()[:12]
        return f"{timestamp}_{uid_hash}"
    
    def _update_history_button_context(self, ai_id, timestamp, model_info=None):
        """将历史上下文写入历史按钮文本（替代独立灰字标签）。"""
        from .config import get_prefs
        from .api import APIClient
        from .models.base import DEFAULT_MODELS
        
        # 优先使用 model_info（从历史记录中获取）
        if model_info and isinstance(model_info, dict):
            provider_name = model_info.get('provider_name', '')
            model_name = model_info.get('model', '')
            
            if provider_name and model_name:
                ai_display = f"{provider_name} - {model_name}"
            elif provider_name:
                ai_display = provider_name
            elif model_name:
                ai_display = model_name
            else:
                ai_display = ai_id
        else:
            # 回退到从配置中获取
            prefs = get_prefs()
            ai_configs = prefs.get('ai_configs', {})
            
            if ai_id in ai_configs:
                config = ai_configs[ai_id]
                display_name = config.get('display_name', ai_id)
                model_name = config.get('model', '')
                if model_name:
                    ai_display = f"{display_name} - {model_name}"
                else:
                    ai_display = display_name
            else:
                ai_provider = APIClient._MODEL_TO_PROVIDER.get(ai_id)
                if ai_provider and ai_provider in DEFAULT_MODELS:
                    display_name = DEFAULT_MODELS[ai_provider].display_name
                    model_name = ai_id if ai_id != 'default' else ''
                    if model_name:
                        ai_display = f"{display_name} - {model_name}"
                    else:
                        ai_display = display_name
                else:
                    ai_display = ai_id
        
        # 格式化时间戳（缩略显示）
        try:
            from datetime import datetime
            dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
            # 只显示日期和时间，不显示秒
            time_display = dt.strftime('%m-%d %H:%M')
        except ValueError:
            time_display = timestamp
        
        history_label = self.i18n.get('history', 'History')
        info_text = f"{history_label} · {ai_display} · {time_display}"
        self._history_button_context_text = info_text
        self._refresh_history_button_text()
        logger.info(f"[历史按钮] 更新上下文: {info_text}")

    def _reset_history_button_text(self):
        """恢复历史按钮默认文字。"""
        self._history_button_context_text = None
        self._refresh_history_button_text()

    def _refresh_history_button_text(self):
        """按当前按钮宽度刷新历史按钮文字（长文本省略，避免与下拉箭头重叠）。"""
        if not hasattr(self, 'history_button') or not self.history_button:
            return
        full_text = getattr(self, '_history_button_context_text', None)
        btn = self.history_button
        if not full_text:
            btn.setText(self.i18n.get('history', 'History'))
            btn.setToolTip('')
            return
        from .ui_constants import elide_ask_toolbar_toolbutton_text
        btn_width = btn.width() if btn.width() > 0 else btn.minimumWidth()
        btn.setText(elide_ask_toolbar_toolbutton_text(full_text, btn.font(), btn_width))
        btn.setToolTip(full_text)

    def _blur_input_area(self):
        """发送后移除输入框文字光标，避免误以为仍可编辑。"""
        if hasattr(self, 'input_area') and self.input_area:
            self.input_area.clearFocus()
        self.setFocus(Qt.OtherFocusReason)

    def _update_history_info_label(self, ai_id, timestamp, model_info=None):
        """兼容旧调用：转发到历史按钮更新。"""
        self._update_history_button_context(ai_id, timestamp, model_info=model_info)

    def _extract_metadata(self, book_info):
        """提取单本书的元数据"""
        pubdate = book_info.get('pubdate', '')
        if hasattr(pubdate, 'strftime'):
            pubdate = pubdate.strftime('%Y-%m-%d')
        elif isinstance(pubdate, str) and 'T' in pubdate:
            pubdate = pubdate.split('T')[0]
        
        # 检查书籍是否仍存在于数据库
        try:
            db = self.gui.current_db
            db.get_metadata(book_info.id, index_is_id=True)
            deleted = False
        except Exception:
            deleted = True
        
        return {
            'id': book_info.id,
            'title': book_info.get('title', ''),
            'authors': book_info.get('authors', []),
            'publisher': book_info.get('publisher', ''),
            'pubdate': pubdate,
            'languages': book_info.get('languages', []),
            'series': book_info.get('series', ''),
            'deleted': deleted
        }
    
    def _update_window_title(self):
        """更新窗口标题"""
        if not self.books_info:
            # AI搜索模式
            title = f"{self.i18n['menu_title']} - {self.i18n.get('library_search', 'AI Search')}"
        elif self.is_multi_book:
            book_count = len(self.books_info)
            title = f"{self.i18n['menu_title']} - {book_count}{self.i18n.get('books_unit', '本书')}"
        else:
            title = f"{self.i18n['menu_title']} - {self.book_info.title}"
        
        self.setWindowTitle(title)
    
    
    def _prompt_large_selection_routing(self, book_count):
        """Ask user how to handle a large multi-book selection."""
        from PyQt5.QtWidgets import QMessageBox

        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle(self.i18n.get('large_selection_dialog_title', 'Many Books Selected'))
        msg.setText(self.i18n.get(
            'large_selection_dialog_message',
            'You selected {count} books. For library-wide questions, AI Search works better '
            'and searches your entire library with compact metadata.\n\n'
            'Switch to AI Search, or continue with the selected books in compact format?'
        ).format(count=book_count))

        ai_search_btn = msg.addButton(
            self.i18n.get('large_selection_use_ai_search', 'Use AI Search'),
            QMessageBox.AcceptRole,
        )
        continue_btn = msg.addButton(
            self.i18n.get('large_selection_continue', 'Continue with Selection'),
            QMessageBox.ActionRole,
        )
        cancel_btn = msg.addButton(
            self.i18n.get('cancel', 'Cancel'),
            QMessageBox.RejectRole,
        )
        msg.exec_()

        clicked = msg.clickedButton()
        if clicked is None or clicked == cancel_btn:
            return 'cancel'
        if clicked == ai_search_btn:
            return 'ai_search'
        return 'continue'

    def _prepare_ai_search_metadata(self):
        """Ensure library metadata is cached before AI Search routing."""
        import logging
        from calibre_plugins.ask_ai_plugin.config import get_prefs
        from calibre_plugins.ask_ai_plugin.utils import update_library_metadata, get_library_metadata

        logger = logging.getLogger(__name__)
        prefs = get_prefs()
        prefs['library_chat_enabled'] = True

        try:
            # Dirty-check inside update_library_metadata skips rebuild when unchanged
            update_library_metadata(self.gui.current_db, prefs, force=False)
            return bool(
                get_library_metadata(prefs)
                and (prefs.get('library_cached_tsv') or '').strip()
            )
        except Exception as e:
            logger.warning(f"Failed to update library metadata for AI Search routing: {e}")
            return False

    def _build_multi_book_prompt(self, question):
        """构建多书提示词（超过阈值时自动使用 compact 格式）"""
        from calibre_plugins.ask_ai_plugin.config import get_prefs
        from calibre_plugins.ask_ai_plugin.utils import (
            format_books_compact_tsv,
            split_compact_tsv_lines,
            is_placeholder_metadata,
            clean_prompt_metadata_text,
        )
        from calibre_plugins.ask_ai_plugin.prompt_limits import (
            COMPACT_METADATA_THRESHOLD,
            get_max_prompt_length,
        )

        prefs = get_prefs()
        book_count = len(self.books_info)
        use_compact = book_count > COMPACT_METADATA_THRESHOLD

        from calibre_plugins.ask_ai_plugin.prompts_widget import resolve_request_template
        template = resolve_request_template(prefs, 'multi')
        if not template:
            template = self.i18n.get('multi_book_default_template',
                """Here is information about multiple books:

{books_metadata}

User question: {query}

Please answer the question based on the above book information.""")

        if use_compact:
            compact_lines = split_compact_tsv_lines(format_books_compact_tsv(self.books_info))
            max_length = get_max_prompt_length(True, prefs)
            overhead = len(template.format(books_metadata='', query=question)) + 200

            included_lines = []
            current_len = 0
            for line in compact_lines:
                add_len = len(line) + (1 if included_lines else 0)
                if included_lines and current_len + add_len > max_length - overhead:
                    break
                included_lines.append(line)
                current_len += add_len

            books_metadata = '\n'.join(included_lines)
            if len(included_lines) < book_count:
                note = self.i18n.get(
                    'multi_book_truncation_note',
                    'Note: Only the first {included} of {total} selected books are included due to the '
                    'prompt limit. Use AI Search to query your entire library, or raise the custom limit '
                    'in Plugin Configuration → General.'
                ).format(included=len(included_lines), total=book_count)
                books_metadata = f"{books_metadata}\n\n{note}"
        else:
            books_metadata_text = []
            for idx, book in enumerate(self.books_info, 1):
                book_text = self.i18n.get(
                    'multi_book_entry_header', 'Book {idx}:'
                ).format(idx=idx) + '\n'
                book_text += (
                    f"  {self.i18n.get('metadata_title', 'Title')}: "
                    f"{clean_prompt_metadata_text(book.title)}\n"
                )

                if book.authors:
                    authors = clean_prompt_metadata_text(', '.join(book.authors))
                    if not is_placeholder_metadata(authors, 'author'):
                        book_text += f"  {self.i18n.get('metadata_authors', 'Author')}: {authors}\n"

                if hasattr(book, 'pubdate') and book.pubdate:
                    year = str(book.pubdate.year) if hasattr(book.pubdate, 'year') else str(book.pubdate)
                    if not is_placeholder_metadata(year, 'pubyear'):
                        book_text += f"  {self.i18n.get('metadata_pubyear', 'Publication Date')}: {year}\n"

                if hasattr(book, 'series') and book.series:
                    if not is_placeholder_metadata(book.series, 'series'):
                        book_text += f"  {self.i18n.get('metadata_series', 'Series')}: {book.series}\n"

                if book.publisher and not is_placeholder_metadata(book.publisher, 'publisher'):
                    book_text += f"  {self.i18n.get('metadata_publisher', 'Publisher')}: {book.publisher}\n"

                if book.language:
                    lang_name = self.get_language_name(book.language)
                    if not is_placeholder_metadata(lang_name, 'language'):
                        book_text += f"  {self.i18n.get('metadata_language', 'Language')}: {lang_name}\n"

                books_metadata_text.append(book_text)

            books_metadata = '\n'.join(books_metadata_text)

        prompt = template.format(
            books_metadata=books_metadata,
            query=question
        )

        from calibre_plugins.ask_ai_plugin.prompts_widget import apply_prompt_enhancements
        prompt = apply_prompt_enhancements(prompt)

        return prompt
    
    def _create_history_switcher(self):
        """创建历史记录切换按钮和菜单"""
        from PyQt5.QtWidgets import QToolButton, QMenu, QActionGroup
        
        self.history_button = QToolButton()
        self.history_button.setText(self.i18n.get('history', '历史记录'))
        self.history_button.setPopupMode(QToolButton.InstantPopup)  # 点击整个按钮弹出菜单
        self.history_button.setSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.Minimum)
        
        self.history_menu = QMenu()
        self.history_button.setMenu(self.history_menu)
        
        # 创建动作组，用于实现单选效果
        self.history_action_group = QActionGroup(self)
        self.history_action_group.setExclusive(True)
        
        from .ui_constants import style_ask_toolbar_widget
        style_ask_toolbar_widget(self.history_button)
        
        self._load_related_histories()
        
        return self.history_button
    
    def _load_related_histories(self):
        """加载当前书籍关联的所有历史记录"""
        import logging
        logger = logging.getLogger(__name__)
        
        if not hasattr(self.response_handler, 'history_manager'):
            return
        
        # 动态调整菜单最大宽度，防止超出窗口
        window_width = self.width()
        # 菜单最大宽度为窗口宽度的 70%，但不超过 500px，不小于 250px
        max_menu_width = max(250, min(500, int(window_width * 0.7)))
        
        # 使用 setMaximumWidth 而不是 setStyleSheet，这样可以保留 Qt 默认的 hover 效果
        self.history_menu.setMaximumWidth(max_menu_width)
        
        
        # 清空菜单和动作组
        self.history_menu.clear()
        # 清空动作组中的所有动作
        for action in self.history_action_group.actions():
            self.history_action_group.removeAction(action)
        
        # 获取当前书籍的所有历史记录
        book_ids = [book.id for book in self.books_info]
        all_histories = self.response_handler.history_manager.get_related_histories(book_ids)
        
        if not all_histories:
            # 如果没有历史记录，只显示提示，不显示其他选项
            no_history_action = self.history_menu.addAction(self.i18n.get('no_history', 'No history records'))
            no_history_action.setEnabled(False)
            return
        
        # 有历史记录时，添加“新对话”选项
        new_conversation_action = self.history_menu.addAction(self.i18n.get('new_conversation', 'New Conversation'))
        new_conversation_action.setCheckable(True)
        new_conversation_action.triggered.connect(self._on_new_conversation)
        self.history_action_group.addAction(new_conversation_action)
        
        # 添加分隔线
        self.history_menu.addSeparator()
        
        # 历史记录列表（按时间倒序显示）
        # 根据菜单宽度动态计算问题预览的最大字符数
        # 估算：每个字符约占 8-10px，时间戳约占 150px，留出边距和图标空间
        max_question_chars = max(15, int((max_menu_width - 200) / 10))
        
        # 标记是否找到匹配的历史记录
        found_match = False
        
        for idx, history in enumerate(all_histories):
            book_count = len(history['books'])
            # 显示问题的前 N 个字符（根据菜单宽度动态调整）
            question_text = history.get('question', '').strip()
            if not question_text:
                # 使用占位符文本显示空问题
                question_preview = self.i18n.get('empty_question_placeholder', '(No question)')
            else:
                question_preview = question_text[:max_question_chars]
                if len(question_text) > max_question_chars:
                    question_preview += '...'
            display_text = f"{question_preview} - {history['timestamp']}"
            
            
            action = self.history_menu.addAction(display_text)
            action.setCheckable(True)
            # 如果是当前UID，设置为选中状态
            if history['uid'] == self.current_uid:
                action.setChecked(True)
                found_match = True
            else:
                pass
            action.triggered.connect(lambda checked, uid=history['uid']: self._on_history_switched(uid))
            # 添加到动作组，实现单选效果
            self.history_action_group.addAction(action)
        
        # 如果没有找到匹配的历史记录，选中"新对话"
        if not found_match:
            new_conversation_action.setChecked(True)
        else:
            pass
        
        # 在底部添加分隔线和清空选项
        self.history_menu.addSeparator()
        clear_action = self.history_menu.addAction(self.i18n.get('clear_current_book_history', 'Clear Current Book History'))
        clear_action.triggered.connect(self._on_clear_current_book_history)
    
    def _on_new_conversation(self):
        """新对话事件：清空输入和响应区域，并生成新的UID"""
        import logging
        logger = logging.getLogger(__name__)
        
        # 生成新的UID，确保新对话不会覆盖旧的历史记录
        self.current_uid = self._generate_uid()
        logger.info(f"新对话已生成新的UID: {self.current_uid}")
        
        # 清空输入区域
        self.input_area.clear()
        
        # 清空所有面板的响应区域
        if hasattr(self, 'response_panels') and self.response_panels:
            for panel in self.response_panels:
                panel.clear_response()
            logger.info(f"切换到新对话，已清空 {len(self.response_panels)} 个面板")
        else:
            # 单面板模式（向后兼容）
            self.response_area.clear()
            logger.info("切换到新对话，已清空响应区域")
        
        # 刷新历史记录菜单，更新选中状态
        self._load_related_histories()
    
    def _on_history_switched(self, uid):
        """历史记录切换事件"""
        import logging
        logger = logging.getLogger(__name__)
        
        # 获取历史记录
        history = self.response_handler.history_manager.get_history_by_uid(uid)
        if not history:
            logger.warning(f"未找到历史记录: {uid}")
            return
        
        
        # 重建书籍列表
        books_info = []
        book_ids_to_select = []  # 用于反向选择
        
        for book_meta in history['books']:
            book_ids_to_select.append(book_meta['id'])
            if not book_meta['deleted']:
                try:
                    db = self.gui.current_db
                    mi = db.get_metadata(book_meta['id'], index_is_id=True)
                    books_info.append(mi)
                except Exception as e:
                    logger.warning(f"无法加载书籍 {book_meta['id']}: {str(e)}")
        
        # 更新当前状态
        if books_info:
            self.books_info = books_info
            self.book_info = books_info[0]
        self.is_multi_book = len(history['books']) > 1
        self.current_uid = uid
        
        # 重新提取元数据
        self.books_metadata = [self._extract_metadata(book) for book in self.books_info]
        self.book_metadata = self.books_metadata[0]
        
        # 反向选择：在 Calibre 中选中这些书籍（如果技术可行）
        self._select_books_in_calibre(book_ids_to_select)
        
        # 更新 UI
        self._update_window_title()
        self._rebuild_metadata_widget()
        
        # 加载问答内容
        self.input_area.setPlainText(history['question'])
        
        # 处理多AI响应格式
        if 'answers' in history and isinstance(history['answers'], dict):
            # 新格式：多AI响应
            if hasattr(self, 'response_panels') and self.response_panels:
                # 多面板模式：根据历史记录中的AI响应来加载
                # 获取历史记录中所有AI的ID（排除'default'）
                history_ai_ids = [ai_id for ai_id in history['answers'].keys() if ai_id != 'default']
                
                # 如果历史记录中没有具体AI ID，只有default，则使用default
                if not history_ai_ids and 'default' in history['answers']:
                    history_ai_ids = ['default']
                
                logger.info(f"历史记录中包含 {len(history_ai_ids)} 个AI响应: {history_ai_ids}")
                
                # 为每个历史AI响应分配一个面板
                for idx, ai_id in enumerate(history_ai_ids):
                    if idx >= len(self.response_panels):
                        logger.warning(f"历史记录有 {len(history_ai_ids)} 个AI响应，但只有 {len(self.response_panels)} 个面板")
                        break
                    
                    panel = self.response_panels[idx]
                    answer_data = history['answers'][ai_id]
                    answer_text = answer_data.get('answer', answer_data) if isinstance(answer_data, dict) else answer_data
                    
                    # 智能AI切换：检查历史AI是否仍然可用
                    if ai_id != 'default':
                        # 阻止信号触发，避免重复调用_update_all_panel_ai_switchers
                        panel.ai_switcher.blockSignals(True)
                        
                        # 检查历史AI是否在当前可用的AI列表中
                        ai_found = False
                        for i in range(panel.ai_switcher.count()):
                            if panel.ai_switcher.itemData(i) == ai_id:
                                panel.ai_switcher.setCurrentIndex(i)
                                logger.info(f"面板 {idx} 切换到历史AI: {ai_id}")
                                ai_found = True
                                break
                        
                        # 如果历史AI不可用，使用默认AI
                        if not ai_found:
                            prefs = get_prefs()
                            default_ai = prefs.get('selected_model', 'grok')
                            logger.warning(f"历史AI {ai_id} 不可用，切换到默认AI: {default_ai}")
                            fallback_applied = False
                            
                            # 尝试切换到默认AI
                            for i in range(panel.ai_switcher.count()):
                                if panel.ai_switcher.itemData(i) == default_ai:
                                    panel.ai_switcher.setCurrentIndex(i)
                                    logger.info(f"面板 {idx} 已切换到默认AI: {default_ai}")
                                    fallback_applied = True
                                    break
                            # 若默认AI也不可用，回退到第一个可用AI
                            if not fallback_applied:
                                for i in range(panel.ai_switcher.count()):
                                    candidate_ai = panel.ai_switcher.itemData(i)
                                    if candidate_ai:
                                        panel.ai_switcher.setCurrentIndex(i)
                                        fallback_applied = True
                                        logger.warning(f"面板 {idx} 默认AI不可用，回退到首个可用AI: {candidate_ai}")
                                        break
                        
                        panel.ai_switcher.blockSignals(False)
                    
                    # 先设置当前问题
                    panel.set_current_question(history['question'])
                    
                    # 加载历史响应
                    panel.response_handler._update_ui_from_signal(
                        answer_text,
                        is_response=True,
                        is_history=True
                    )
                    logger.info(f"为面板 {idx} 加载AI {ai_id} 的历史响应（长度: {len(answer_text)}）")
                    
                    # 更新历史信息标签（只在第一个面板时更新）
                    if idx == 0:
                        timestamp = history.get('timestamp', '未知时间')
                        # 从answer_data中获取model_info（正确的位置）
                        model_info = answer_data.get('model_info', None) if isinstance(answer_data, dict) else None
                        logger.info(f"[加载历史] AI={ai_id}, model_info={'存在' if model_info else '不存在'}")
                        
                        # 如果历史记录中没有model_info（旧版本），从面板API获取
                        if not model_info and hasattr(panel, 'api'):
                            api_obj = panel.api
                            model_info = {
                                'provider_name': getattr(api_obj, 'provider_name', 'Unknown'),
                                'model': getattr(api_obj, 'model', 'Unknown'),
                                'api_base': getattr(api_obj, 'api_base', '')
                            }
                        
                        self._update_history_info_label(ai_id, timestamp, model_info)
                    
                    # 再次更新按钮状态（确保在响应加载后更新）
                    panel.update_button_states()
                
                # 清空未使用的面板
                for idx in range(len(history_ai_ids), len(self.response_panels)):
                    self.response_panels[idx].response_area.clear()
                    logger.debug(f"清空未使用的面板 {idx}")
                
                # 统一更新所有面板的AI切换器（实现互斥逻辑）
                self._update_all_panel_ai_switchers()
            else:
                # 单面板模式：加载default或第一个AI的响应
                if 'default' in history['answers']:
                    answer_data = history['answers']['default']
                elif history['answers']:
                    answer_data = list(history['answers'].values())[0]
                else:
                    answer_data = ''
                
                answer_text = answer_data.get('answer', answer_data) if isinstance(answer_data, dict) else answer_data
                self.response_handler._update_ui_from_signal(
                    answer_text,
                    is_response=True,
                    is_history=True
                )
        else:
            # 旧格式：单一响应（向后兼容）
            answer = history.get('answer', '')
            self.response_handler._update_ui_from_signal(
                answer,
                is_response=True,
                is_history=True
            )
        
        
        # 刷新历史记录菜单，更新选中状态
        self._load_related_histories()
    
    def _on_clear_current_book_history(self):
        """清空当前书籍的历史记录"""
        from PyQt5.QtWidgets import QMessageBox
        import logging
        logger = logging.getLogger(__name__)
        
        # 确认对话框
        book_count = len(self.books_info)
        book_titles = ', '.join([book.title[:20] for book in self.books_info[:3]])
        if book_count > 3:
            book_titles += f" ... ({book_count} books)"
        
        confirm_msg = self.i18n.get(
            'confirm_clear_book_history',
            'Are you sure you want to clear all history for:\n{book_titles}?'
        ).format(book_titles=book_titles)
        
        reply = QMessageBox.question(
            self,
            self.i18n.get('confirm', 'Confirm'),
            confirm_msg,
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        # 获取当前书籍的所有历史记录
        book_ids = [book.id for book in self.books_info]
        all_histories = self.response_handler.history_manager.get_related_histories(book_ids)
        
        # 删除所有相关历史记录
        deleted_count = 0
        for history in all_histories:
            uid = history['uid']
            if self.response_handler.history_manager.delete_history(uid):
                deleted_count += 1
        
        
        # 清空当前界面
        self.input_area.clear()
        if hasattr(self, 'response_panels') and self.response_panels:
            for panel in self.response_panels:
                panel.clear_response()
        else:
            self.response_area.clear()
        
        # 重新加载历史记录菜单
        self._load_related_histories()
        
        # 显示成功消息
        success_msg = self.i18n.get('history_cleared', '{deleted_count} history records cleared.').format(deleted_count=deleted_count)
        QMessageBox.information(
            self,
            self.i18n.get('success', 'Success'),
            success_msg
        )
    
    def _select_books_in_calibre(self, book_ids):
        """在 Calibre 主界面中选中指定书籍"""
        import logging
        logger = logging.getLogger(__name__)
        
        try:
            from PyQt5.QtCore import QItemSelectionModel
            
            # 清除当前选择
            self.gui.library_view.selectionModel().clear()
            
            # 选中指定书籍
            db = self.gui.current_db
            selected_count = 0
            
            for book_id in book_ids:
                try:
                    # 使用 Calibre 的 API 选中书籍
                    # 通过 set_current_row 方法选中书籍
                    if db.has_id(book_id):
                        # 使用 select_rows 方法选中多本书
                        self.gui.library_view.select_rows([book_id], using_ids=True, change_current=False)
                        selected_count += 1
                    else:
                        logger.debug(f"书籍 {book_id} 不存在于数据库中")
                except Exception as e:
                    logger.debug(f"书籍 {book_id} 可能已被删除或不在当前视图中: {str(e)}")
            
            logger.info(f"在 Calibre 中选中了 {selected_count}/{len(book_ids)} 本书")
            
        except Exception as e:
            logger.warning(f"无法在 Calibre 中选中书籍: {str(e)}")
    
    def _rebuild_metadata_widget(self):
        """刷新可折叠元数据栏。"""
        if hasattr(self, 'metadata_bar') and self.metadata_bar:
            self.metadata_bar.refresh(
                books_metadata=self.books_metadata,
                is_multi_book=self.is_multi_book,
                is_ai_search=not self.books_info,
            )
            self._update_window_title()

    def _update_ai_search_info_label(self):
        """刷新 AI Search 模式下的元数据摘要。"""
        if hasattr(self, 'metadata_bar') and self.metadata_bar:
            self.metadata_bar.refresh(is_ai_search=True)

    def _load_history_content(self, history):
        """加载历史记录内容到UI
        
        Args:
            history: 历史记录字典
            
        Returns:
            bool: 如果成功加载返回True
        """
        self.input_area.setPlainText(history['question'])
        
        # 检查是否有多面板模式
        if hasattr(self, 'response_panels') and self.response_panels:
            # 多面板模式：为每个面板加载对应AI的历史响应
            
            if 'answers' in history and history['answers']:
                # 获取历史记录中所有AI的ID（排除'default'）
                history_ai_ids = [ai_id for ai_id in history['answers'].keys() if ai_id != 'default']
                
                # 如果历史记录中没有具体AI ID，只有default，则使用default
                if not history_ai_ids and 'default' in history['answers']:
                    history_ai_ids = ['default']
                
                # 为每个历史AI响应分配一个面板
                for idx, ai_id in enumerate(history_ai_ids):
                    if idx >= len(self.response_panels):
                        logger.warning(f"历史记录有 {len(history_ai_ids)} 个AI响应，但只有 {len(self.response_panels)} 个面板")
                        break
                    
                    panel = self.response_panels[idx]
                    answer_data = history['answers'][ai_id]
                    answer_text = answer_data.get('answer', answer_data) if isinstance(answer_data, dict) else answer_data
                    
                    # 智能AI切换：检查历史AI是否仍然可用
                    if ai_id != 'default':
                        # 阻止信号触发，避免重复调用_update_all_panel_ai_switchers
                        panel.ai_switcher.blockSignals(True)
                        
                        # 检查历史AI是否在当前可用的AI列表中
                        ai_found = False
                        for i in range(panel.ai_switcher.count()):
                            if panel.ai_switcher.itemData(i) == ai_id:
                                panel.ai_switcher.setCurrentIndex(i)
                                logger.info(f"面板 {idx} 切换到历史AI: {ai_id}")
                                ai_found = True
                                break
                        
                        # 如果历史AI不可用，使用默认AI
                        if not ai_found:
                            prefs = get_prefs()
                            default_ai = prefs.get('selected_model', 'grok')
                            logger.warning(f"历史AI {ai_id} 不可用，切换到默认AI: {default_ai}")
                            
                            # 尝试切换到默认AI
                            for i in range(panel.ai_switcher.count()):
                                if panel.ai_switcher.itemData(i) == default_ai:
                                    panel.ai_switcher.setCurrentIndex(i)
                                    logger.info(f"面板 {idx} 已切换到默认AI: {default_ai}")
                                    break
                        
                        panel.ai_switcher.blockSignals(False)
                    
                    # 先设置当前问题
                    panel.set_current_question(history['question'])
                    
                    # 加载历史响应
                    panel.response_handler._update_ui_from_signal(
                        answer_text,
                        is_response=True,
                        is_history=True
                    )
                    logger.info(f"为面板 {idx} 加载AI {ai_id} 的历史响应（长度: {len(answer_text)}）")
                    
                    # 更新历史信息标签（只在第一个面板时更新）
                    if idx == 0:
                        timestamp = history.get('timestamp', '未知时间')
                        # 从answer_data中获取model_info（正确的位置）
                        model_info = answer_data.get('model_info', None) if isinstance(answer_data, dict) else None
                        logger.info(f"[加载历史] AI={ai_id}, model_info={'存在' if model_info else '不存在'}")
                        
                        # 如果历史记录中没有model_info（旧版本），从面板API获取
                        if not model_info and hasattr(panel, 'api'):
                            api_obj = panel.api
                            model_info = {
                                'provider_name': getattr(api_obj, 'provider_name', 'Unknown'),
                                'model': getattr(api_obj, 'model', 'Unknown'),
                                'api_base': getattr(api_obj, 'api_base', '')
                            }
                        
                        self._update_history_info_label(ai_id, timestamp, model_info)
                    
                    # 再次更新按钮状态（确保在响应加载后更新）
                    panel.update_button_states()
                
                # 清空未使用的面板
                logger.info(f"准备清空未使用的面板，范围: {len(history_ai_ids)} 到 {len(self.response_panels)}")
                for idx in range(len(history_ai_ids), len(self.response_panels)):
                    panel = self.response_panels[idx]
                    logger.info(f"准备清空面板 {idx}，panel_index={panel.panel_index}")
                    panel.response_area.clear()
                    # 清空后更新按钮状态，禁用复制按钮
                    logger.info(f"面板 {idx} 已清空，准备更新按钮状态")
                    panel.update_button_states()
                    logger.info(f"面板 {idx} 按钮状态已更新")
                
                # 统一更新所有面板的AI切换器（实现互斥逻辑）
                self._update_all_panel_ai_switchers()
            else:
                logger.warning("历史记录中没有answers字段")
        else:
            # 单面板模式（向后兼容）
            logger.info("单面板模式，加载历史记录")
            
            # 兼容新旧格式：优先使用answers字典，回退到answer字段
            if 'answers' in history and history['answers']:
                # 新格式：从answers字典中获取第一个响应（通常是'default'或第一个AI的响应）
                first_ai_id = list(history['answers'].keys())[0]
                answer_data = history['answers'][first_ai_id]
                answer_text = answer_data['answer'] if isinstance(answer_data, dict) else answer_data
            elif 'answer' in history:
                # 旧格式：直接使用answer字段
                answer_text = history['answer']
                logger.info("加载旧格式历史记录")
            else:
                answer_text = ""
                logger.warning("历史记录中没有找到答案内容")
            
            if answer_text:
                self.response_handler._update_ui_from_signal(
                    answer_text, 
                    is_response=True,
                    is_history=True
                )
        
        logger.info(f"已加载历史记录，时间: {history.get('timestamp', '未知')}")
        
        # 更新导出历史按钮状态
        if hasattr(self, 'response_panels') and self.response_panels:
            for panel in self.response_panels:
                if hasattr(panel, 'update_export_all_button_state'):
                    panel.update_export_all_button_state()
        
        # 刷新历史记录菜单，更新选中状态
        self._load_related_histories()
        
        # 成功加载了历史记录
        return True

    def _load_history(self):
        """加载历史记录 - 智能匹配当前书籍组合
        
        Returns:
            bool: 如果成功加载了历史记录返回True，否则返回False
        """
        import logging
        logger = logging.getLogger(__name__)
        
        try:
            # AI Search 模式（books_info为空）：直接通过 UID 加载历史记录
            if not self.books_info and self._explicit_history_uid:
                logger.info(f"AI Search mode, loading history by UID: {self._explicit_history_uid}")
                history = self.response_handler.history_manager.get_history_by_uid(self._explicit_history_uid)
                if history:
                    return self._load_history_content(history)
                else:
                    logger.warning(f"AI Search history not found: {self._explicit_history_uid}")
                    return False
            
            # 首先检查是否有待发送的随机问题
            book_ids = tuple(sorted([book.id for book in self.books_info]))
            prefs = get_prefs()
            pending_questions = prefs.get('pending_random_questions', {})
            
            if str(book_ids) in pending_questions:
                pending_data = pending_questions[str(book_ids)]
                
                # 恢复待发送的随机问题状态
                self.current_uid = pending_data['uid']
                self._pending_random_question = pending_data['question']
                self._is_generating_random_question = True
                self.input_area.setPlainText(pending_data['question'])
                
                # 清空响应区域（因为还没有AI回答）
                if hasattr(self, 'response_panels') and self.response_panels:
                    for panel in self.response_panels:
                        panel.clear_response()
                else:
                    self.response_area.clear()
                
                logger.info("已恢复待发送的随机问题状态，等待用户点击发送")
                # 不从临时存储中删除，等用户发送后再删除
                # 这不算加载历史记录，因为还没有AI回答
                return False

            # 新打开对话框默认视为“新对话”，不自动加载最近历史
            # 否则会覆盖 Config 中的默认 AI / 用户当前选择
            if not self._explicit_history_uid:
                return False
            
            # 获取当前书籍ID集合
            current_book_ids = set([book.id for book in self.books_info])
            
            # 获取所有相关历史记录
            all_histories = self.response_handler.history_manager.get_related_histories(list(current_book_ids))
            
            if not all_histories:
                return False
            
            # 查找最佳匹配的历史记录（始终加载最新的，不过滤空问题）
            matched_history = None
            
            # 优先级1: 完全匹配（UID相同的书籍组合）
            for history in all_histories:
                history_book_ids = set([book['id'] for book in history['books']])
                if history_book_ids == current_book_ids:
                    matched_history = history
                    question = history.get('question', '').strip()
                    question_preview = question[:30] + '...' if len(question) > 30 else question if question else '(空问题)'
                    # 使用现有 UID，不创建新的
                    old_uid = self.current_uid
                    self.current_uid = history['uid']
                    break
            
            # 优先级2: 当前选择被包含在某个历史记录中
            if not matched_history:
                for history in all_histories:
                    history_book_ids = set([book['id'] for book in history['books']])
                    if current_book_ids.issubset(history_book_ids):
                        matched_history = history
                        question = history.get('question', '').strip()
                        question_preview = question[:30] + '...' if len(question) > 30 else question if question else '(空问题)'
                        # 保持当前 UID，只有发起新对话时才会创建新 UID
                        break
            
            # 如果找到匹配的历史记录，加载它
            if matched_history:
                return self._load_history_content(matched_history)
            else:
                logger.info("没有找到匹配的历史记录（书籍组合不同），显示新对话")
                
                # 即使没有匹配的历史记录，也要更新按钮状态（可能有其他历史记录）
                if hasattr(self, 'response_panels') and self.response_panels:
                    for panel in self.response_panels:
                        if hasattr(panel, 'update_export_all_button_state'):
                            panel.update_export_all_button_state()
                
                # 没有加载历史记录
                return False
                
        except Exception as e:
            logger.error(f"加载历史记录失败: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return False
    
    # 注意：clear_history() 方法已废弃，使用 _on_clear_current_book_history() 代替
    
    def on_resize(self, event):
        """窗口大小变化时的处理函数（包含响应式布局调整）"""
        try:
            prefs = get_prefs()
            prefs['ask_dialog_width'] = self.width()
            prefs['ask_dialog_height'] = self.height()
        except Exception:
            prefs = None
        
        # 响应式布局调整
        height = self.height()
        
        from .ui_constants import ASK_INPUT_HEIGHT, ASK_INPUT_HEIGHT_COMPACT, ASK_RESPONSE_PANEL_MIN_HEIGHT

        if height < 650:
            if hasattr(self, 'input_area'):
                self.input_area.setFixedHeight(ASK_INPUT_HEIGHT_COMPACT)
        else:
            if hasattr(self, 'input_area'):
                self.input_area.setFixedHeight(ASK_INPUT_HEIGHT)

        if hasattr(self, 'response_panels'):
            for panel in self.response_panels:
                panel.setMinimumHeight(ASK_RESPONSE_PANEL_MIN_HEIGHT)

        self._refresh_history_button_text()
        
        super().resizeEvent(event)

    def update_model_info(self):
        """更新模型信息显示
        在配置更改后调用此方法，更新界面上显示的模型信息
        """
        import logging
        logger = logging.getLogger(__name__)
        
        try:
            # 确保模型已经重新加载
            self.api.reload_model()
            
            # 获取最新的模型显示名称
            model_display_name = self.api.model_display_name
            logger.debug(f"更新模型信息: {model_display_name}")
            
            # 更新窗口标题
            if hasattr(self, 'book_info') and self.book_info:
                self.setWindowTitle(f"{self.i18n['menu_title']} [{model_display_name}] - {self.book_info.title}")
                logger.debug("已更新窗口标题")
            else:
                logger.warning("无法更新窗口标题: 书籍信息不可用")
                
        except Exception as e:
            logger.error(f"更新模型信息时出错: {str(e)}")
    
    # 注意：_populate_model_switcher() 方法已废弃，因为全局模型切换器已被移除
    
    # 注意：on_model_switched() 方法已废弃，因为全局模型切换器已被移除
    # 现在每个面板都有自己的AI切换器，切换逻辑在 response_panel.py 中处理
    
    @staticmethod
    def book_language_label(lang_code, unknown='Unknown'):
        """Book-language name spliced into prompts. Unknown uses the UI word."""
        if not lang_code:
            return None
        lang_code = as_unicode_text(lang_code).lower().strip()
        if lang_code in ('und', 'un', 'zxx', 'unknown'):
            return unknown
        mapped = AskDialog.LANGUAGE_MAP.get(lang_code)
        if mapped:
            return mapped
        try:
            from calibre.utils.localization import calibre_langcode_to_name
            name = calibre_langcode_to_name(lang_code)
            if name:
                return name
        except Exception:
            pass
        return lang_code

    def get_language_name(self, lang_code):
        """将语言代码转换为易读的语言名称"""
        return self.book_language_label(
            lang_code, self.i18n.get('unknown', 'Unknown')
        )
    
    def _create_response_container(self, count: int, show_panel_ai_switcher=True):
        """根据并行AI数量创建响应容器
        
        Args:
            count: 并行AI数量 (目前仅支持1-2)
            show_panel_ai_switcher: 是否在面板内显示 AI 切换器
        
        Returns:
            包含响应面板的容器组件
        """
        from .response_panel import ResponsePanel
        
        # 限制为1-2个（3-4功能暂未完成）
        if count > 2:
            logger.warning(f"并行AI数量 {count} 超过限制，自动降级到2")
            count = 2
        
        container = QWidget()
        container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        if count == 1:
            layout = QVBoxLayout(container)
        else:
            layout = QHBoxLayout(container)
        
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(SPACING_SMALL)
        
        # 创建响应面板列表
        self.response_panels = []
        
        # 获取已配置的AI列表
        configured_ais = self._get_configured_ais()
        
        # 简化逻辑：只处理1-2个面板
        for i in range(count):
            panel = ResponsePanel(
                i, self, self.api, self.i18n,
                show_ai_switcher=show_panel_ai_switcher,
            )
            panel.ai_changed.connect(self._on_panel_ai_changed)
            self._setup_panel_handler(panel)
            self.response_panels.append(panel)
            layout.addWidget(panel, stretch=1)
        
        # 初始化所有面板的AI切换器，并设置默认选择
        self._update_all_panel_ai_switchers()
        self._set_default_ai_selections()
        
        return container
    
    def _get_configured_ais(self):
        """获取已配置的AI列表
        
        Returns:
            list: [(ai_id, display_name), ...]
        """
        prefs = get_prefs()
        models_config = prefs.get('models', {})
        
        configured_ais = []
        for ai_id, config in models_config.items():
            # 实际检查配置是否有效，而不仅仅依赖 is_configured 标志
            # 因为 is_configured 可能没有被正确更新
            
            # 检查是否有模型名称
            has_model = bool(config.get('model', '').strip())
            if not has_model:
                continue
            
            # 检查是否有API Key（Ollama除外，它是本地服务）
            # 获取 provider_id（从 config 中获取，或从 ai_id 中提取）
            provider_id = extract_provider_id(ai_id, config)
            
            if provider_id in LOCAL_OPENAI_COMPAT_PROVIDER_IDS:
                # 本地 OpenAI 兼容服务：需要有 api_base_url
                has_valid_config = bool(config.get('api_base_url', '').strip())
                if not has_valid_config:
                    continue
            else:
                # 其他AI必须有token（根据 provider_id 判断字段名）
                token_field = 'auth_token' if provider_id == 'grok' else 'api_key'
                has_token = bool(config.get(token_field, '').strip())
                if not has_token:
                    continue
            
            # 与设置页同一套显示名。Grok 等固定名称不读旧配置里的 display_name。
            from .config import get_provider_display_name
            display_name = get_provider_display_name(provider_id, config, i18n=self.i18n)

            model_name = config.get('model', 'unknown')
            full_display = f"{display_name} - {model_name}"
            configured_ais.append((ai_id, full_display))
        
        return configured_ais
    
    def _update_all_panel_ai_switchers(self):
        """更新所有面板的AI切换器（实现互斥逻辑）"""
        if not hasattr(self, 'response_panels') or not self.response_panels:
            return
        
        # 获取已配置的AI列表
        configured_ais = self._get_configured_ais()
        
        # 获取当前并行AI数量
        prefs = get_prefs()
        parallel_ai_count = prefs.get('parallel_ai_count', 1)
        
        # 如果是单面板模式，不应用互斥逻辑
        if parallel_ai_count == 1:
            # 单面板模式：所有AI都可用
            for i, panel in enumerate(self.response_panels):
                if i < parallel_ai_count:
                    panel.populate_ai_switcher(configured_ais, set())
            return
        
        # 多面板模式：应用互斥逻辑
        # 收集已被使用的AI（只收集可见面板的）
        used_ais = set()
        for i, panel in enumerate(self.response_panels):
            # 只收集可见面板（根据 parallel_ai_count）的 AI 使用情况
            if i < parallel_ai_count:
                ai_id = panel.get_selected_ai()
                if ai_id:
                    used_ais.add(ai_id)
        
        # 更新每个面板
        for i, panel in enumerate(self.response_panels):
            # 只更新可见面板
            if i < parallel_ai_count:
                current_ai = panel.get_selected_ai()
                # 排除其他面板使用的AI（但保留当前面板自己选中的）
                other_used_ais = used_ais - {current_ai} if current_ai else used_ais
                panel.populate_ai_switcher(configured_ais, other_used_ais)
    
    def _setup_panel_handler(self, panel):
        """为面板设置ResponseHandler
        
        Args:
            panel: ResponsePanel实例
        """
        from calibre_plugins.ask_ai_plugin.response_handler import ResponseHandler
        from calibre_plugins.ask_ai_plugin.api import APIClient
        
        # 为每个面板创建独立的APIClient实例
        # 这样可以避免多面板并发时的模型切换冲突
        panel_api = APIClient()
        
        # 创建独立的ResponseHandler实例
        handler = ResponseHandler(self)
        
        # 设置handler，使用面板独立的API实例
        handler.setup(
            response_area=panel.response_area,
            send_button=self.send_button,
            i18n=self.i18n,
            api=panel_api,  # 使用独立的API实例
            input_area=self.input_area,
            stop_button=self.stop_button
        )
        
        # 将handler和api关联到面板
        panel.setup_response_handler(handler)
        panel.api = panel_api  # 更新面板的API引用
        
        # 连接面板的请求完成信号
        panel.request_finished.connect(self._on_panel_request_finished)
        
        logger.info(f"已为面板 {panel.panel_index} 设置独立的ResponseHandler和APIClient")
    
    def _on_panel_request_finished(self, panel_index):
        """面板请求完成事件处理
        
        Args:
            panel_index: 完成的面板索引
        """
        logger.info(f"面板 {panel_index} 请求完成")
        
        # 检查是否所有面板都已完成
        # 这里简化处理：任何一个面板完成都不改变按钮状态
        # 实际上应该等所有面板都完成，但这需要更复杂的状态管理
        # 暂时保持按钮状态不变，让用户手动点击停止按钮来恢复
    
    def _set_default_ai_selections(self):
        """为每个面板设置默认的AI选择
        
        规则：
        1. 从配置中读取上次的选择（记忆功能）
        2. 如果没有记忆，按顺序分配不同的AI
        3. 如果AI数量不足，超出的面板留空
        """
        prefs = get_prefs()
        
        # 读取上次的AI选择记忆
        saved_selections = prefs.get('panel_ai_selections', {}) or {}
        
        # 获取已配置的AI列表
        configured_ais = self._get_configured_ais()
        
        if not configured_ais:
            logger.warning("没有已配置的AI，无法设置默认选择")
            return
        
        # 读取当前配置中的默认AI
        default_ai = prefs.get('selected_model', 'grok')
        force_default_once = bool(prefs.get('force_default_ai_on_next_open', False))

        def set_panel_ai(panel, ai_id):
            """程序化设置 AI 时屏蔽信号，避免初始化反写默认值。"""
            index = panel.ai_switcher.findData(ai_id)
            if index < 0:
                return False
            panel.ai_switcher.blockSignals(True)
            panel.ai_switcher.setCurrentIndex(index)
            panel.ai_switcher.blockSignals(False)
            return True
        
        # 为每个面板设置默认AI
        for i, panel in enumerate(self.response_panels):
            panel_key = f"panel_{i}"

            target_ai = None

            # hybrid 规则：仅当配置页刚改过默认 AI 时，下次打开强制应用一次默认值
            if i == 0 and force_default_once and any(ai_id == default_ai for ai_id, _ in configured_ais):
                target_ai = default_ai
            elif panel_key in saved_selections:
                saved_ai_id = saved_selections[panel_key]
                if any(ai_id == saved_ai_id for ai_id, _ in configured_ais):
                    target_ai = saved_ai_id
            elif i == 0 and any(ai_id == default_ai for ai_id, _ in configured_ais):
                target_ai = default_ai
            elif i < len(configured_ais):
                target_ai = configured_ais[i][0]

            if target_ai and set_panel_ai(panel, target_ai):
                saved_selections[panel_key] = target_ai
                logger.info(f"面板 {i} 初始化选择: {target_ai}")
            else:
                panel.ai_switcher.blockSignals(True)
                panel.ai_switcher.setCurrentIndex(-1)
                panel.ai_switcher.blockSignals(False)
                saved_selections.pop(panel_key, None)
                logger.info(f"面板 {i} 留空（AI数量不足或目标AI不可用）")
        
        # 将更新后的面板选择记忆回写到配置中
        prefs['panel_ai_selections'] = saved_selections
        if force_default_once:
            prefs['force_default_ai_on_next_open'] = False
            prefs.commit()

        # 更新所有面板的AI切换器（实现互斥）
        self._update_all_panel_ai_switchers()

        # 初始化完成，允许后续用户切换时触发默认AI确认逻辑
        for panel in self.response_panels:
            panel._is_initializing = False
    
    def _check_default_ai_mismatch(self):
        """检查配置中的默认 AI 是否与当前选中的 AI 一致
        
        如果不一致，弹窗询问用户是否切换到默认 AI
        
        注意：只在 Parallel AI Count 为 1 时才检查，为 2 时跳过
        """
        from PyQt5.QtWidgets import QMessageBox
        from PyQt5.QtCore import QTimer
        
        prefs = get_prefs()
        
        # 获取并行AI数量
        parallel_ai_count = prefs.get('parallel_ai_count', 1)
        
        # 如果是并行模式（2个AI），跳过检查
        # 因为并行模式下，用户已经在配置中明确选择了要使用的AI
        if parallel_ai_count == 2:
            logger.debug("并行AI模式（2个AI），跳过默认AI检查")
            return
        
        default_ai = prefs.get('selected_model', 'grok')
        
        # 获取第一个面板当前选中的 AI
        if not self.response_panels:
            return
        
        first_panel = self.response_panels[0]
        current_ai_id = first_panel.ai_switcher.currentData()
        
        # 如果当前 AI 是 None（未选择），不需要提示，直接返回
        if current_ai_id is None:
            logger.debug("当前未选择 AI，跳过默认 AI 检查")
            return
        
        # 如果一致，也需要确保 API 使用的是面板选中的 AI（而不是配置中的默认 AI）
        # 因为用户可能之前选择了"否"，导致面板 AI 与配置不一致
        if current_ai_id == default_ai:
            logger.debug(f"当前 AI ({current_ai_id}) 与默认 AI ({default_ai}) 一致")
            # 仍然需要切换 API 到面板选中的 AI，确保一致性
            self._switch_api_to_panel_ai(current_ai_id)
            return
        
        # 获取 AI 显示名称
        from .models.base import DEFAULT_MODELS, AIProvider
        from .api import APIClient
        
        default_ai_provider = APIClient._MODEL_TO_PROVIDER.get(default_ai)
        current_ai_provider = APIClient._MODEL_TO_PROVIDER.get(current_ai_id)
        
        default_ai_name = DEFAULT_MODELS.get(default_ai_provider).display_name if default_ai_provider else default_ai
        # 处理 None 的情况，使用 i18n
        if current_ai_id is None:
            current_ai_name = self.i18n.get('select_ai', '-- Select AI --')
        else:
            current_ai_name = DEFAULT_MODELS.get(current_ai_provider).display_name if current_ai_provider else current_ai_id
        
        logger.info(f"检测到 AI 不一致 - 当前: {current_ai_name} ({current_ai_id}), 默认: {default_ai_name} ({default_ai})")
        
        # 使用 QTimer 延迟弹窗，避免在初始化过程中阻塞
        def show_dialog():
            reply = QMessageBox.question(
                self,
                self.i18n.get('default_ai_mismatch_title', 'Default AI Changed'),
                self.i18n.get('default_ai_mismatch_message', 
                    'The default AI in configuration has been changed to "{default_ai}",\n'
                    'but the current conversation is using "{current_ai}".\n\n'
                    'Would you like to switch to the new default AI?').format(
                        default_ai=default_ai_name,
                        current_ai=current_ai_name
                    ),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes
            )
            
            if reply == QMessageBox.Yes:
                # 切换到默认 AI
                logger.info(f"用户选择切换到默认 AI: {default_ai}")
                
                # 先重新更新面板的AI切换器，确保所有AI都可用
                logger.info(f"重新更新面板AI切换器，确保 {default_ai} 可用")
                self._update_all_panel_ai_switchers()
                
                # 更新第一个面板的 AI 选择
                index = first_panel.ai_switcher.findData(default_ai)
                logger.info(f"在面板 0 的AI切换器中查找 {default_ai}，index={index}")
                
                # 调试：打印面板中所有可用的AI
                available_ais = []
                for i in range(first_panel.ai_switcher.count()):
                    ai_id = first_panel.ai_switcher.itemData(i)
                    ai_text = first_panel.ai_switcher.itemText(i)
                    available_ais.append(f"{ai_text}({ai_id})")
                logger.info(f"面板 0 当前可用的AI: {', '.join(available_ais)}")
                
                if index >= 0:
                    first_panel.ai_switcher.setCurrentIndex(index)
                    
                    # 重新加载 API 模型
                    self.api.reload_model()
                    
                    # 更新窗口标题
                    self._update_window_title()
                    
                    logger.info(f"已切换到默认 AI: {default_ai_name}")
                else:
                    logger.warning(f"未找到默认 AI: {default_ai}")
            else:
                # 用户选择继续使用当前 AI
                logger.info(f"用户选择继续使用当前 AI: {current_ai_name} ({current_ai_id})")
                
                # 强制 API 使用当前面板选中的 AI，而不是配置中的默认 AI
                self._switch_api_to_panel_ai(current_ai_id)
        
        # 延迟 100ms 后显示对话框
        QTimer.singleShot(100, show_dialog)
        
    def _switch_api_to_panel_ai(self, ai_id: str):
        """强制 API 切换到指定的 AI
        
        当用户选择不切换到默认 AI 时，需要确保 API 使用面板选中的 AI
        
        Args:
            ai_id: AI 模型 ID（如 'openrouter', 'gemini' 等）
        """
        try:
            # 使用 API 的内部方法切换模型
            self.api._switch_to_model(ai_id)
            logger.info(f"API 已切换到面板选中的 AI: {ai_id}")
            
            # 更新窗口标题
            self._update_window_title()
        except Exception as e:
            logger.error(f"切换 API 到面板 AI 失败: {str(e)}")
    
    def _check_nvidia_free_first_use(self):
        """检查是否需要显示 Nvidia Free 首次使用提醒
        
        条件：
        1. 用户从未看过提醒（nvidia_free_first_use_shown = False）
        2. 当前使用的是 nvidia_free（默认 AI）
        3. 用户没有配置其他 AI（或者只配置了 nvidia_free）
        """
        from PyQt5.QtWidgets import QMessageBox
        from PyQt5.QtCore import QTimer
        
        prefs = get_prefs()
        
        # 检查是否已经显示过提醒
        if prefs.get('nvidia_free_first_use_shown', False):
            return
        
        # 获取当前选中的 AI
        if not self.response_panels:
            return
        
        first_panel = self.response_panels[0]
        current_ai_id = first_panel.ai_switcher.currentData()
        
        # 只在使用 nvidia_free 时显示提醒
        if current_ai_id != 'nvidia_free':
            return
        
        # 检查用户是否配置了其他 AI（排除 nvidia_free）
        models_config = prefs.get('models', {})
        configured_ais = []
        for model_id, config in models_config.items():
            if model_id != 'nvidia_free' and config.get('enabled', False):
                # 检查是否真正配置了（有 API key 或其他必要配置）
                provider_id = extract_provider_id(model_id, config)
                if provider_id in LOCAL_OPENAI_COMPAT_PROVIDER_IDS:
                    # 本地 OpenAI 兼容服务不需要 API key
                    configured_ais.append(model_id)
                elif config.get('api_key') or config.get('auth_token'):
                    configured_ais.append(model_id)
        
        # 如果用户已经配置了其他 AI，不显示提醒（说明是老用户）
        if configured_ais:
            logger.info(f"用户已配置其他 AI: {configured_ais}，跳过 Nvidia Free 首次使用提醒")
            # 标记为已显示，避免后续再检查
            prefs['nvidia_free_first_use_shown'] = True
            prefs.commit()  # 立即保存，避免重复检查
            return
        
        def show_reminder():
            """显示首次使用提醒对话框"""
            msg_box = QMessageBox(self)
            msg_box.setIcon(QMessageBox.Information)
            msg_box.setWindowTitle(self.i18n.get('nvidia_free_first_use_title', 'Welcome to Ask AI Plugin'))
            msg_box.setText(self.i18n.get('nvidia_free_first_use_message', 
                'Now you can just ask without any configuration! The developer maintains a free tier for you, but it may not be very stable. Enjoy!\n\nYou can configure your own AI providers in the settings for better stability.'))
            msg_box.setStandardButtons(QMessageBox.Ok)
            msg_box.exec_()
            
            # 标记为已显示
            prefs['nvidia_free_first_use_shown'] = True
            prefs.commit()  # 立即保存，避免重复显示
            logger.info("已显示 Nvidia Free 首次使用提醒")
        
        # 延迟 300ms 后显示提醒（在 AI 不匹配对话框之后）
        QTimer.singleShot(300, show_reminder)
    
    def _save_panel_ai_selections(self):
        """保存所有面板的AI选择到配置"""
        prefs = get_prefs()
        
        selections = {}
        for i, panel in enumerate(self.response_panels):
            ai_id = panel.get_selected_ai()
            if ai_id:
                selections[f"panel_{i}"] = ai_id
        
        prefs['panel_ai_selections'] = selections
        logger.info(f"已保存面板AI选择: {selections}")
    
    def _on_panel_ai_changed(self, panel_index, new_ai_id):
        """面板AI切换事件处理
        
        Args:
            panel_index: 面板索引
            new_ai_id: 新选中的AI ID
        """
        panel = None
        # 更新对应面板的API对象（修复模型信息显示错误）
        if panel_index < len(self.response_panels) and new_ai_id:
            panel = self.response_panels[panel_index]
            # 切换面板的API到选中的AI
            panel.api._switch_to_model(new_ai_id)
            logger.info(f"[面板AI切换] 面板{panel_index}: {new_ai_id}")
        
        # 如果是第一个面板切换 AI，同步更新 API 使用的模型和默认 AI 配置
        # 这样随机问题和发送请求都会使用面板选中的 AI
        if panel_index == 0 and new_ai_id:
            self._switch_api_to_panel_ai(new_ai_id)
            # 初始化阶段不回写默认值，避免覆盖配置页刚保存的新默认
            if panel is not None and not getattr(panel, '_is_initializing', False):
                prefs = get_prefs()
                prefs['selected_model'] = new_ai_id
                panel_selections = prefs.get('panel_ai_selections', {}) or {}
                panel_selections['panel_0'] = new_ai_id
                prefs['panel_ai_selections'] = panel_selections
                prefs['force_default_ai_on_next_open'] = False
                prefs.commit()
                logger.info(f"[面板AI切换] 已同步更新默认 AI: {new_ai_id}")
        
        # 更新所有面板的AI切换器（实现互斥）
        self._update_all_panel_ai_switchers()
        
        # 保存选择到配置
        self._save_panel_ai_selections()
    
    def setup_ui(self):
        # 确保模型已经加载
        self.api.reload_model()
        
        # 获取当前使用的模型显示名称
        model_display_name = self.api.model_display_name
        
        # 更新窗口标题
        self._update_window_title()
        
        # 获取并行AI数量配置
        prefs = get_prefs()
        self.parallel_ai_count = prefs.get('parallel_ai_count', 1)
        
        # 限制为1-2个AI（3-4功能暂未完成）
        if self.parallel_ai_count > 2:
            logger.warning(f"并行AI数量 {self.parallel_ai_count} 超过限制，自动降级到2")
            self.parallel_ai_count = 2
            prefs['parallel_ai_count'] = 2
        
        # 根据并行AI数量动态设置最小宽度和高度（降低最小高度以适应小屏幕）
        min_widths = {
            1: 600,   # 单个：保持现有
            2: 1000,  # 2个：每个500px
        }
        min_heights = {
            1: 500,   # 单个：降低到500px以适应笔记本
            2: 500,   # 2个横向：同样高度
        }
        self.setMinimumWidth(min_widths.get(self.parallel_ai_count, 600))
        self.setMinimumHeight(min_heights.get(self.parallel_ai_count, 500))
        
        from .ui_constants import configure_ask_dialog_root, ASK_INPUT_HEIGHT, ASK_INPUT_HEIGHT_COMPACT
        from .ask_metadata_bar import AskMetadataBar
        from .ask_toolbar import AskToolbar

        layout = QVBoxLayout()
        configure_ask_dialog_root(layout)
        self.setLayout(layout)

        self.ask_toolbar = AskToolbar(self.i18n)
        self.ask_toolbar.set_ai_search_mode(not self.books_info)
        layout.addWidget(self.ask_toolbar)

        self.metadata_bar = AskMetadataBar(self.i18n, language_name_fn=self.get_language_name)
        self.metadata_bar.refresh(
            books_metadata=self.books_metadata,
            is_multi_book=self.is_multi_book,
            is_ai_search=not self.books_info,
        )
        layout.addWidget(self.metadata_bar)

        self.input_area = QTextEdit()
        self.input_area.setPlaceholderText(self.i18n['input_placeholder'])
        self.input_area.setFixedHeight(ASK_INPUT_HEIGHT)
        self.input_area.setStyleSheet("""
            QTextEdit {
                border: 1px solid palette(mid);
                border-radius: 4px;
                padding: 5px;
            }
            QTextEdit:focus {
                border: 1px solid palette(highlight);
                border-radius: 4px;
                padding: 5px;
                outline: none;
            }
        """)
        layout.addWidget(self.input_area)

        self.suggest_button = self.ask_toolbar.suggest_button
        self.stop_button = self.ask_toolbar.stop_button
        self.send_button = self.ask_toolbar.send_button
        self.suggest_button.clicked.connect(self.generate_suggestion)
        self.stop_button.clicked.connect(self.stop_request)
        self.send_button.clicked.connect(self.send_question)

        self.suggest_action = QAction(self.i18n['suggest_button'], self)
        self.suggest_action.setShortcutContext(Qt.WindowShortcut)
        self.suggest_action.triggered.connect(self.generate_suggestion)
        self.addAction(self.suggest_action)

        self.send_action = QAction(self.i18n['send_button'], self)
        self.send_action.setShortcutContext(Qt.WindowShortcut)
        self.send_action.triggered.connect(self.send_question)
        self.addAction(self.send_action)

        show_panel_ai = self.parallel_ai_count > 1
        response_container = self._create_response_container(
            self.parallel_ai_count,
            show_panel_ai_switcher=show_panel_ai,
        )
        layout.addWidget(response_container, stretch=1)

        if self.parallel_ai_count == 1 and self.response_panels:
            if sys.platform == 'darwin':
                # macOS 下给历史按钮留更多空间，避免右侧挤压
                self.response_panels[0].ai_switcher.setMaximumWidth(240)
                self.response_panels[0].ai_switcher.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            self.ask_toolbar.add_left_widget(self.response_panels[0].ai_switcher)

        self.history_button = self._create_history_switcher()
        self.ask_toolbar.add_left_widget(self.history_button)

        if self.response_panels:
            self.response_area = self.response_panels[0].response_area
            self.response_handler = self.response_panels[0].response_handler
    
    def _update_button_focus(self):
        """根据输入框内容动态切换按钮的高光状态"""
        has_text = bool(self.input_area.toPlainText().strip())
        
        # 如果用户修改了输入框内容，清除随机问题相关的临时状态
        if hasattr(self, '_pending_random_question'):
            current_text = self.input_area.toPlainText()
            if current_text != self._pending_random_question:
                # 用户修改了随机问题，清除临时缓存和标记
                if self._pending_random_question is not None:
                    logger.debug("用户修改了输入框内容，清除随机问题临时状态")
                    self._pending_random_question = None
                    if hasattr(self, '_is_generating_random_question'):
                        self._is_generating_random_question = False
        
        if has_text:
            # 输入框有内容：发送按钮高光，随机问题按钮取消高光
            self.send_button.setDefault(True)
            self.suggest_button.setDefault(False)
        else:
            # 输入框为空：随机问题按钮高光，发送按钮取消高光
            self.suggest_button.setDefault(True)
            self.send_button.setDefault(False)
    
    def _has_history_data(self):
        """检查当前UID是否有历史记录（有AI回答）
        
        Returns:
            bool: 如果有历史记录且包含AI回答返回True，否则返回False
        """
        if not hasattr(self, 'response_handler') or not hasattr(self.response_handler, 'history_manager'):
            return False
        
        history = self.response_handler.history_manager.get_history_by_uid(self.current_uid)
        if not history:
            return False
        
        # 检查是否有AI回答
        answers = history.get('answers', {})
        if not answers:
            return False
        
        # 检查是否有任何非空的回答
        for ai_id, answer_data in answers.items():
            if isinstance(answer_data, dict):
                answer = answer_data.get('answer', '')
            else:
                answer = answer_data
            if answer and answer.strip():
                return True
        
        return False
    
    def generate_suggestion(self):
        """生成随机问题（只发送到第一个AI面板）"""
        # 检查是否有有效的AI配置
        if not self.api or not self.api._ai_model:
            logger.warning("未配置有效的AI服务，显示提示")
            self._show_ai_service_required_dialog()
            return
        
        # 随机问题只使用第一个AI（不并行），并显式使用其当前选中的模型
        model_id = None
        panel_api = None
        if hasattr(self, 'response_panels') and self.response_panels:
            # 确保第一个面板有选中的AI
            first_panel = self.response_panels[0]
            model_id = first_panel.get_selected_ai()
            panel_api = first_panel.api  # 获取面板的 API 实例
            if not model_id:
                logger.warning("第一个面板没有选中AI，无法生成随机问题")
                self._show_ai_service_required_dialog()
                return
        
        # 如果没有面板API，使用全局API
        if not panel_api:
            panel_api = self.api
        
        # 临时更新 suggestion_handler 的 API 实例
        self.suggestion_handler.api = panel_api
        logger.info(f"随机问题使用面板 API 实例，模型: {model_id}")
        
        # 检查是否有历史数据
        if self._has_history_data():
            logger.info("检测到当前有历史记录，点击随机问题将创建新会话")
            # 创建新会话
            self._on_new_conversation()
        
        # 标记这是一个随机问题请求
        self._is_generating_random_question = True
        
        # 使用选中的模型生成随机问题
        self.suggestion_handler.generate(self.book_info, model_id=model_id)

    def _show_ai_service_required_dialog(self):
        """显示需要AI服务的提示对话框"""
        from PyQt5.QtWidgets import QMessageBox
        
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle(self.i18n.get('auth_token_required_title', 'AI Service Required'))
        msg_box.setText(self.i18n.get('auth_token_required_message', 
            'Please configure a valid AI service in Plugin Configuration.'))
        msg_box.setIcon(QMessageBox.Information)
        
        # 只添加确认按钮（避免在Ask对话框打开时再打开配置对话框导致错误）
        msg_box.addButton(
            self.i18n.get('confirm', 'OK'),
            QMessageBox.AcceptRole
        )
        
        msg_box.exec_()
    
    def _check_auth_token(self):
        """检查当前选择的模型是否设置了API Key"""
        from calibre_plugins.ask_ai_plugin.config import get_prefs
        
        prefs = get_prefs()
        selected_model = prefs.get('selected_model', 'grok')
        models_config = prefs.get('models', {})
        model_config = models_config.get(selected_model, {})
        
        provider_id = extract_provider_id(selected_model, model_config)
        
        # 本地 OpenAI 兼容服务 / Custom / nvidia_free 不强制要求用户 API Key
        if provider_id in LOCAL_OPENAI_COMPAT_PROVIDER_IDS or provider_id in ('custom', 'nvidia_free'):
            return True
        
        # 获取token字段名，根据 provider_id 判断
        token_field = 'auth_token' if provider_id == 'grok' else 'api_key'
        token = model_config.get(token_field, '')
            
        if not token or not token.strip():
            # 显示友好的提示对话框
            self._show_ai_service_required_dialog()
            
            # 直接返回False，表示验证失败
            return False
        
        return True
    
    def send_question(self):
        """发送问题"""
        import logging
        from calibre_plugins.ask_ai_plugin.config import get_prefs
        from calibre_plugins.ask_ai_plugin.prompt_limits import (
            LARGE_SELECTION_THRESHOLD,
            count_books_in_library_metadata,
            validate_prompt_length,
        )
        logger = logging.getLogger(__name__)
        
        # 检查是否是随机问题请求
        is_random_question = hasattr(self, '_is_generating_random_question') and self._is_generating_random_question
        
        # 如果是随机问题，已经在generate_suggestion中创建了新会话，这里不需要再创建
        # 如果不是随机问题，检查当前UID是否已有历史记录
        if not is_random_question:
            if hasattr(self, 'response_handler') and hasattr(self.response_handler, 'history_manager'):
                if self.current_uid in self.response_handler.history_manager.histories:
                    old_uid = self.current_uid
                    self.current_uid = self._generate_uid()
                    logger.info(f"检测到已有历史记录，生成新UID: {old_uid} -> {self.current_uid}")
        else:
            logger.info("随机问题请求，使用已创建的新会话UID")
            # 清除临时存储中的待发送随机问题（因为用户已经点击发送）
            book_ids = tuple(sorted([book.id for book in self.books_info]))
            prefs = get_prefs()
            pending_questions = prefs.get('pending_random_questions', {})
            if str(book_ids) in pending_questions:
                del pending_questions[str(book_ids)]
                prefs['pending_random_questions'] = pending_questions
                logger.info(f"已清除临时存储中的待发送随机问题: book_ids={book_ids}")
            
            # 重置标记和临时缓存
            self._is_generating_random_question = False
            self._pending_random_question = None
        
        # 检查 token 是否有效
        if not self._check_auth_token():
            logger.error("Token 验证失败")
            return
            
        try:
            # 获取输入的问题
            question = self.input_area.toPlainText()
            # 标准化换行符并确保使用 UTF-8 编码
            question = as_unicode_text(question)

            prefs = get_prefs()
            use_library_chat = False
            book_count_for_validation = len(self.books_info)
            validation_is_multi = self.is_multi_book

            # 大规模选书：引导使用 AI Search 或 compact 多书模式
            if self.is_multi_book and len(self.books_info) > LARGE_SELECTION_THRESHOLD:
                routing = self._prompt_large_selection_routing(len(self.books_info))
                if routing == 'cancel':
                    return
                if routing == 'ai_search':
                    if not self._prepare_ai_search_metadata():
                        self.response_handler.handle_error(
                            self.i18n.get('library_update_failed', 'Failed to update library data')
                        )
                        return
                    prompt = question
                    use_library_chat = True
                    book_count_for_validation = count_books_in_library_metadata(prefs)
                    validation_is_multi = True
                    logger.info("大规模选书已路由到 AI Search 管线")
                else:
                    logger.info("大规模选书继续使用 compact 多书模式")
                    prompt = self._build_multi_book_prompt(question)
            elif self.is_multi_book:
                # 多书模式：使用多书提示词
                logger.info("使用多书模式构建提示词...")
                prompt = self._build_multi_book_prompt(question)
            else:
                # 单书模式：使用原有逻辑
                logger.info("使用单书模式构建提示词...")
                
                # 安全地获取书籍的作者或作者列表
                try:
                    authors = self.book_info.authors if hasattr(self.book_info, 'authors') else []
                    author_str = ', '.join(authors) if authors else ''
                except AttributeError:
                    author_str = ''
                
                # 安全地获取书籍的出版年份
                try:
                    pubyear = ''
                    if hasattr(self.book_info, 'pubdate') and self.book_info.pubdate:
                        if hasattr(self.book_info.pubdate, 'year'):
                            pubyear = str(self.book_info.pubdate.year)
                        else:
                            pubyear = str(self.book_info.pubdate)
                except Exception as e:
                    logger.error(f"获取出版年份时出错: {str(e)}")
                    pubyear = ''
                
                # 安全地获取书籍的语言类别
                try:
                    language = self.book_info.language
                    language_name = self.get_language_name(language) if language else ''
                except (AttributeError, KeyError):
                    language_name = ''
                
                # 安全地获取书籍的系列名
                try:
                    series = self.book_info.series if hasattr(self.book_info, 'series') and self.book_info.series else ''
                except AttributeError:
                    series = ''
                
                # 准备模板变量
                from calibre_plugins.ask_ai_plugin.utils import (
                    omit_placeholder_template_fields,
                    clean_prompt_metadata_text,
                )
                template_vars = {
                    'query': as_unicode_text(question),
                    'title': clean_prompt_metadata_text(
                        as_unicode_text(
                            getattr(self.book_info, 'title', None),
                            self.i18n.get('unknown', 'Unknown'),
                        )
                    ) or self.i18n.get('unknown', 'Unknown'),
                    'author': clean_prompt_metadata_text(as_unicode_text(author_str)),
                    'publisher': as_unicode_text(getattr(self.book_info, 'publisher', None)),
                    'pubyear': as_unicode_text(pubyear) if pubyear else '',
                    'language': as_unicode_text(language_name) if language_name else '',
                    'series': as_unicode_text(series) if series else ''
                }
                
                # 获取配置的模板
                prefs = get_prefs()
                from calibre_plugins.ask_ai_plugin.prompts_widget import resolve_request_template
                template = resolve_request_template(prefs, 'ask')
                
                # 如果模板为空，使用当前界面语言的默认模板（字段名也走 i18n）
                if not template:
                    from calibre_plugins.ask_ai_plugin.i18n import get_default_template
                    template = get_default_template(prefs.get('language', 'en') or 'en')
                
                logger.info(f"使用的模板: {template}")
                
                # 检查并替换模板中的变量名，确保用户输入能够正确插入
                if '{query}' not in template and '{question}' in template:
                    logger.info("检测到旧版模板变量 {question}，自动替换为 {query}")
                    template = template.replace('{question}', '{query}')
                
                template = omit_placeholder_template_fields(template, template_vars)
                
                # 格式化提示词
                try:
                    prompt = template.format(**template_vars)
                except KeyError as e:
                    self.response_handler.handle_error(self.i18n.get('template_error', 'Template error: {error}').format(error=str(e)))
                    return
                
                # 应用 persona 和语言指令
                from calibre_plugins.ask_ai_plugin.prompts_widget import apply_prompt_enhancements
                prompt = apply_prompt_enhancements(prompt)
            
            logger.info(f"最终提示词长度: {len(prompt)}")
            
        except Exception as e:
            self.response_handler.handle_error(f"{self.i18n.get('error_preparing_request', 'Error preparing request')}: {str(e)}")
            return

        # 长度校验（AI Search 在 ui 层仅校验用户问题；完整 prompt 在 api 层二次校验）
        if not use_library_chat:
            length_error = validate_prompt_length(
                prompt, validation_is_multi, prefs, self.i18n, book_count_for_validation,
            )
            if length_error:
                self.response_handler.handle_error(length_error)
                return
        
        self._reset_history_button_text()
        self._blur_input_area()
        
        # 禁用发送按钮并显示加载状态，显示停止按钮
        self.send_button.setVisible(False)
        self.stop_button.setVisible(True)
        
        # 判断是否使用Library Chat（未选书时，或大规模选书已路由到 AI Search）
        if not use_library_chat and not self.books_info:
            # AI搜索模式（books_info为空列表）
            # AI搜索现在始终启用，只要有元数据就使用
            prefs = get_prefs()
            library_metadata = prefs.get('library_cached_metadata', '')
            if library_metadata:
                use_library_chat = True
                logger.info("AI搜索模式，将使用图书馆搜索模式")
            else:
                logger.warning("AI搜索模式但无元数据")
        
        # 开始异步请求 - 并行发送到所有面板
        parallel_start_time = time.time()
        try:
            if hasattr(self, 'response_panels') and self.response_panels:
                # 多面板模式：并行发送到所有面板
                for panel in self.response_panels:
                    # 设置当前问题（用于按钮状态判断）
                    panel.set_current_question(question)
                    
                    selected_ai = panel.get_selected_ai()
                    if selected_ai:
                        request_time = time.time()
                        elapsed_ms = (request_time - parallel_start_time) * 1000
                        panel.send_request(prompt, model_id=selected_ai, use_library_chat=use_library_chat)
                    else:
                        logger.warning(f"面板 {panel.panel_index} 没有选中AI，跳过")
                total_time = (time.time() - parallel_start_time) * 1000
                logger.info(f"所有请求已发出，总耗时: {total_time:.2f}ms，面板数: {len(self.response_panels)}")
            else:
                # 向后兼容：单面板模式
                self.response_handler.start_async_request(prompt, use_library_chat=use_library_chat)
                logger.info(f"异步请求已启动（单面板模式），use_library_chat={use_library_chat}")
        except Exception as e:
            logger.error(f"启动异步请求时出错: {str(e)}")
            if hasattr(self, 'response_handler'):
                self.response_handler.handle_error(f"{self.i18n.get('error_starting_request', 'Error starting request')}: {str(e)}")
            # 恢复按钮状态
            self.send_button.setVisible(True)
            self.stop_button.setVisible(False)
    
    def stop_request(self):
        """停止当前请求（包括发送请求和随机问题生成）"""
        import logging
        logger = logging.getLogger(__name__)
        logger.info("用户请求停止当前请求")
        
        # 检查是否是随机问题生成请求
        if hasattr(self, 'suggestion_handler') and self.suggestion_handler:
            # 检查是否有正在进行的随机问题生成
            if hasattr(self.suggestion_handler, '_worker') and self.suggestion_handler._worker and not self.suggestion_handler._worker.is_finished():
                logger.info("停止随机问题生成")
                self.suggestion_handler.stop()
                return
        
        # 停止所有面板的请求
        if hasattr(self, 'response_panels') and self.response_panels:
            for panel in self.response_panels:
                if hasattr(panel, 'response_handler') and panel.response_handler:
                    panel.response_handler.cancel_request()
            logger.info(f"已停止 {len(self.response_panels)} 个面板的请求")
        elif hasattr(self, 'response_handler'):
            # 向后兼容：单面板模式
            self.response_handler.cancel_request()
        
        # 恢复按钮状态
        self.send_button.setVisible(True)
        self.stop_button.setVisible(False)
        
        logger.info("请求已停止，按钮状态已恢复")
    
    def eventFilter(self, obj, event):
        """事件过滤器，用于处理快捷键"""
        if event.type() == event.KeyPress:
            # 处理单独的 Enter 键：根据输入框内容决定触发哪个按钮
            # 注意：Ctrl/Cmd+Enter 由 QAction shortcut 处理，以保证在对话框任意控件聚焦时均可触发。
            if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
                # 检查是否有修饰键（Shift等），如果有则不处理（允许换行）
                if event.modifiers() & (Qt.ShiftModifier | Qt.AltModifier):
                    return False
                
                has_text = bool(self.input_area.toPlainText().strip())
                if has_text:
                    # 输入框有内容：触发发送
                    self.send_question()
                else:
                    # 输入框为空：触发随机问题
                    self.generate_suggestion()
                return True
        return False

    def update_language(self, new_language=None):
        """更新界面语言"""
        import logging
        logger = logging.getLogger(__name__)
        
        # 如果没有指定语言，从配置中获取
        if not new_language:
            from calibre_plugins.ask_ai_plugin.config import get_prefs
            prefs = get_prefs()
            new_language = prefs.get('language', 'en')
        
        logger.debug(f"AskDialog 更新语言为: {new_language}")
        
        # 更新i18n对象
        from .i18n import get_translation
        self.i18n = get_translation(new_language)
        
        # 更新窗口标题 - 使用统一的方法处理AI搜索模式
        self._update_window_title()
        
        # 更新发送按钮文本
        if hasattr(self, 'send_button'):
            self.send_button.setText(self.i18n.get('send', 'Send'))
        
        # 更新输入区域占位符文本
        if hasattr(self, 'input_area'):
            self.input_area.setPlaceholderText(self.i18n.get('ask_placeholder', 'Ask about this book...'))
        
        if hasattr(self, 'suggest_button'):
            self.suggest_button.setText(self.i18n.get('suggest_button', 'Random'))
        if hasattr(self, 'stop_button'):
            self.stop_button.setText(self.i18n.get('stop_button', 'Stop'))
        if hasattr(self, 'send_button'):
            self.send_button.setText(self.i18n.get('send_button', 'Send'))
        self._refresh_history_button_text()
        
        logger.debug("AskDialog 界面语言更新完成")
    
    def showEvent(self, event):
        """显示时恢复鼠标光标，避免继承 Calibre 读元数据时的 loading 状态。"""
        super().showEvent(event)
        from .ui_constants import configure_ask_dialog_cursors
        configure_ask_dialog_cursors(self)
        QTimer.singleShot(0, self._refresh_history_button_text)

    def closeEvent(self, event):
        """处理窗口关闭事件"""
        import logging
        logger = logging.getLogger(__name__)

        from .ui_constants import reset_application_cursor
        reset_application_cursor()

        prefs = get_prefs()
        prefs['ask_dialog_width'] = self.width()
        prefs['ask_dialog_height'] = self.height()
        
        logger.info("="*80)
        logger.info(f"[ASKDIALOG_CLOSE] closeEvent 被调用")
        logger.info(f"[ASKDIALOG_CLOSE] books_info 是否为空: {not self.books_info}")
        
        if not self.books_info and self.current_uid:
            history = self.response_handler.history_manager.get_history_by_uid(self.current_uid)
            if history and history.get('answers'):
                prefs['ai_search_last_history_uid'] = self.current_uid
                prefs.commit()
                logger.info(f"[ASKDIALOG_CLOSE] AI搜索模式，保存历史UID: {self.current_uid}")
        
        # 如果有待发送的随机问题，保存到临时存储
        if hasattr(self, '_pending_random_question') and self._pending_random_question and self.books_info:
            # 使用书籍ID作为key保存待发送的随机问题和新会话UID
            # AI搜索模式下books_info为空，不保存随机问题
            book_ids = tuple(sorted([book.id for book in self.books_info]))
            prefs = get_prefs()
            pending_questions = prefs.get('pending_random_questions', {})
            pending_questions[str(book_ids)] = {
                'question': self._pending_random_question,
                'uid': self.current_uid,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            prefs['pending_random_questions'] = pending_questions
            logger.info(f"保存待发送的随机问题到临时存储: book_ids={book_ids}, uid={self.current_uid}")
        
        if hasattr(self, 'response_handler') and self.response_handler:
            self.response_handler.prepare_close()
            if hasattr(self.response_handler, 'cleanup'):
                self.response_handler.cleanup()
        if hasattr(self, 'suggestion_handler') and self.suggestion_handler:
            self.suggestion_handler.prepare_close()
            if hasattr(self.suggestion_handler, 'cleanup'):
                self.suggestion_handler.cleanup()
        event.accept()
