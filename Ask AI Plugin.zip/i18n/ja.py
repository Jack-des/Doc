#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Japanese language translations for Ask AI Plugin.
"""

from ..models.base import BaseTranslation, TranslationRegistry, AIProvider


@TranslationRegistry.register
class JapaneseTranslation(BaseTranslation):
    """Japanese language translation."""
    
    @property
    def code(self) -> str:
        return "ja"
    
    @property
    def name(self) -> str:
        return "日本語"
    
    @property
    def default_template(self) -> str:
        return '背景：あなたは「Ask AI Plugin」プラグインを通じて、calibre (http://calibre-ebook.com) という強力な電子書籍管理アプリケーションのユーザーをサポートしています。このプラグインにより、ユーザーは calibre ライブラリ内の書籍について質問できます。注意：このプラグインは、選択された書籍の内容、テーマ、または関連トピックに関する質問にのみ回答でき、書籍のメタデータを直接変更したり、calibre の操作を実行したりすることはできません。書籍情報：タイトル：「{title}」、著者：{author}、出版社：{publisher}、出版年：{pubyear}、言語：{language}、シリーズ：{series}。ユーザーの質問：{query}。書籍情報とあなたの知識に基づいて、役立つ回答を提供してください。'
    
    @property
    def suggestion_template(self) -> str:
        return """あなたは本のレビューの専門家です。{author}著の本「{title}」公開言語は「{language}」について、読者が本の核心的な考え、実用的な応用、または独自の視点をよりよく理解するのに役立つような、1つの洞察に富んだ質問を生成してください。ルール： 1. 質問のみを返し、導入や説明は不要です 2. 本の内容に焦点を当て、タイトルだけに焦点を当てないでください 3. 質問を実用的で考えさせられるようにしてください 4. 30〜200文字以内に保ちます 5. 創造的に、同じ本でも毎回異なる質問を生成してください"""
    
    @property
    def multi_book_default_template(self) -> str:
        return """複数の本に関する情報は次のとおりです：{books_metadata} ユーザーの質問：{query} 上記の本の情報に基づいて質問に答えてください。"""
    
    @property
    def translations(self) -> dict:
        return {
            # プラグイン情報
            'plugin_name': 'Ask AI プラグイン',
            'plugin_desc': 'AIを使用して本について質問する',
            
            # UI - タブとセクション
            'config_title': '設定',
            'general_tab': '一般',
            'ai_models': 'AI',
            'shortcuts': 'ショートカット',
            'shortcuts_note': "これらのショートカットは calibre でカスタマイズできます: 設定 -> ショートカット（'Ask AI' で検索）。\nこのページはデフォルト/例のショートカットを表示しています。ショートカット設定で変更した場合は、calibre の設定が優先されます。",
            'prompts_tab': 'プロンプト',
            'about': '情報',
            'metadata': 'メタデータ',
            
            # セクションサブタイトル
            'language_settings': '言語',
            'language_subtitle': 'お好みのインターフェース言語を選択してください',
            'ai_providers_subtitle': 'AIプロバイダーを設定し、デフォルトのAIを選択してください',
            'prompts_subtitle': 'AIへの質問の送信方法をカスタマイズ',
            'export_settings_subtitle': 'PDF出力のデフォルトフォルダを設定',
            'reset_all_data_subtitle': 'リセット後、すべての設定とデータが完全に削除されます。これには、すべてのAPIキー、AI検索インデックスデータ、言語設定、AIの使用設定、その他のローカルデータが含まれます。',
            
            # プロンプトタブ
            'language_preference_title': '言語設定',
            'language_preference_subtitle': 'AIの回答をインターフェース言語に合わせるかどうかを制御',
            'prompt_templates_title': 'プロンプトテンプレート',
            'prompt_templates_subtitle': '{title}、{author}、{query}などの動的フィールドを使用して、書籍情報をAIに送信する方法をカスタマイズ',
            'ask_prompts': '質問プロンプト',
            'random_questions_prompts': 'ランダム質問プロンプト',
            'multi_book_prompts_label': '複数書籍プロンプト',
            'multi_book_placeholder_hint': '書籍情報には{books_metadata}を、ユーザーの質問には{query}を使用',
            'dynamic_fields_title': '動的フィールドリファレンス',
            'dynamic_fields_subtitle': 'メアリー・シェリーの「フランケンシュタイン」から利用可能なフィールドと例の値',
            'dynamic_fields_examples': '<b>{title}</b> → Frankenstein<br><b>{author}</b> → Mary Shelley<br><b>{publisher}</b> → Lackington, Hughes, Harding, Mavor & Jones<br><b>{pubyear}</b> → 1818<br><b>{language}</b> → English<br><b>{series}</b> → (なし)<br><b>{query}</b> → あなたの質問テキスト',
            'reset_prompts': 'プロンプトをデフォルトにリセット',
            'reset_prompts_confirm': 'すべてのプロンプトテンプレートをデフォルト値にリセットしてもよろしいですか？この操作は元に戻せません。',
            'unsaved_changes_title': '未保存の変更',
            'unsaved_changes_message': 'プロンプトタブに未保存の変更があります。保存しますか？',
            'use_interface_language': 'AIに常に現在のプラグインインターフェース言語で回答するよう依頼する',
            'language_instruction_label': 'プロンプトに追加された言語指示：',
            'language_instruction_text': '{language_name}で回答してください。',
            
            # ペルソナ設定
            'persona_title': 'ペルソナ',
            'persona_subtitle': '研究の背景と目標を定義して、AIがより関連性の高い回答を提供できるようにします',
            'use_persona': 'ペルソナを使用',
            'persona_label': 'ペルソナ',
            'persona_placeholder': '研究者として、書籍データを通じて研究を行いたいと思います。',
            'persona_hint': 'AIがあなたの目標と背景についてより多く知るほど、研究や生成の質が向上します。',
            
            # UI - ボタンとアクション
            'ok_button': 'OK',
            'save_button': '保存',
            'send_button': '送信',
            'stop_button': '停止',
            'suggest_button': 'ランダム質問',
            'copy_response': '回答をコピー',
            'copy_question_response': '問答をコピー',
            'export_pdf': 'PDFをエクスポート',
            'export_current_qa': '現在のQ&Aをエクスポート',
            'export_history': '履歴をエクスポート',
            
            # エクスポート設定
            'export_settings': 'エクスポート設定',
            'enable_default_export_folder': 'デフォルトフォルダにエクスポート',
            'no_folder_selected': 'フォルダが選択されていません',
            'browse': '参照...',
            'select_export_folder': 'エクスポートフォルダを選択',
            
            # ボタンテキストとメニュー項目
            'copy_response_btn': '回答をコピー',
            'copy_qa_btn': 'Q&Aをコピー',
            'export_current_btn': 'Q&AをPDFにエクスポート',
            'export_history_btn': '履歴をPDFにエクスポート',
            'copy_mode_response': '回答',
            'copy_mode_qa': 'Q&A',
            'copy_format_plain': 'プレーンテキスト',
            'copy_format_markdown': 'Markdown',
            'export_mode_current': '現在のQ&A',
            'export_mode_history': '履歴',
            
            # PDFエクスポート関連
            'model_provider': 'プロバイダ',
            'model_name': 'モデル',
            'model_api_url': 'APIベースURL',
            'pdf_model_info': 'AIモデル情報',
            'pdf_software': 'ソフトウェア',
            
            'export_all_history_dialog_title': 'すべての履歴をPDFにエクスポート',
            'export_all_history_title': 'すべての問答履歴',
            'export_history_insufficient': 'エクスポートには少なくとも2件の履歴記録が必要です。',
            'history_record': '記録',
            'question_label': '質問',
            'answer_label': '回答',
            'default_ai': 'デフォルトAI',
            'export_time': 'エクスポート日時',
            'total_records': '総記録数',
            'info': '情報',
            'yes': 'はい',
            'no': 'いいえ',
            'no_book_selected_title': '本が選択されていません',
            'no_book_selected_message': '質問する前に本を選択してください。',
            'set_default_ai_title': 'デフォルトAIを設定',
            'set_default_ai_message': '"{0}"に切り替えました。今後のクエリのデフォルトAIとして設定しますか？',
            'set_default_ai_success': 'デフォルトAIが"{0}"に設定されました。',
            'set_default_ai_after_add_message': '「{0}」を追加しました。デフォルトAIに設定しますか？',
            'copied': 'コピーされました！',
            'pdf_exported': 'PDFをエクスポートしました！',
            'export_pdf_dialog_title': 'PDFにエクスポート',
            'export_pdf_error': 'PDFのエクスポートに失敗しました: {0}',
            'no_question': '質問なし',
            'saved': '保存しました',
            'close_button': '閉じる',
            'open_local_tutorial': 'ローカルチュートリアルを開く',
            'tutorial_open_failed': 'チュートリアルを開けませんでした',
            'tutorial': 'チュートリアル',

            'model_display_name_perplexity': 'Perplexity',
            
            # UI - 設定フィールド
            'token_label': 'APIキー:',
            'api_key_label': 'APIキー:',
            'model_label': 'モデル:',
            'language_label': '言語:',
            'language_label_old': '言語',
            'base_url_label': 'ベースURL:',
            'base_url_placeholder': 'デフォルト: {default_api_base_url}',
            'shortcut': 'ショートカットキー',
            'shortcut_open_dialog': 'ダイアログを開く',
            'shortcut_enter': 'Ctrl + Enter',
            'shortcut_return': 'Command + Return',
            'using_model': 'モデル',
            'action': 'アクション',
            'reset_button': 'リセット',
            'prompt_template': 'プロンプトテンプレート',
            'ask_prompts': '質問プロンプト',
            'random_questions_prompts': 'ランダム質問プロンプト',
            'display': '表示',
            
            # UI - ダイアログ要素
            'input_placeholder': '質問を入力してください...',
            'response_placeholder': '回答はすぐに表示されます...',
            
            # UI - メニューアイテム
            'menu_title': '質問',
            'menu_ask': '質問',
            
            # UI - ステータスメッセージ
            'loading': '読み込み中',
            'loading_text': '質問中',
            'save_success': '設定を保存しました',
            'sending': '送信中...',
            'requesting': 'リクエスト中',
            'formatting': 'リクエスト成功、フォーマット中',
            
            # UI - モデルリスト機能
            'load_models': 'モデルを読み込む',
            'use_custom_model': 'カスタムモデル名を使用',
            'custom_model_placeholder': 'カスタムモデル名を入力',
            'model_placeholder': 'まずモデルを読み込んでください',
            'models_loaded': '{count}個のモデルを正常に読み込みました',
            'load_models_failed': 'モデルの読み込みに失敗しました: {error}',
            'model_list_not_supported': 'このプロバイダーはモデルの自動取得をサポートしていません',
            'api_key_required': 'まずAPIキーを入力してください',
            'invalid_params': '無効なパラメーター',
            'warning': '警告',
            'success': '成功',
            'error': 'エラー',
            'error_opening_dialog': 'ダイアログを開く際にエラーが発生しました:',
            'skipped_books_warning': 'ファイルアクセスエラーのため、{count}冊の本をスキップしました。\nこれはファイルパスに無効な文字が含まれているか、ファイルが他のプログラムによってロックされていることが原因である可能性があります。',
            'failed_to_read_all_books': '選択したすべての本のメタデータを読み取れませんでした。\nこれはファイルパスに無効な文字が含まれているか、ファイルが他のプログラムによってロックされていることが原因である可能性があります。',
            'error_starting_request': 'リクエストの開始中にエラーが発生しました',
            'default_ai_mismatch_title': 'デフォルトAIが変更されました',
            'default_ai_mismatch_message': '設定のデフォルトAIが「{default_ai}」に変更されましたが、\n現在の会話は「{current_ai}」を使用しています。\n\n新しいデフォルトAIに切り替えますか？',
            
            # メタデータフィールド
            'metadata_title': 'タイトル',
            'metadata_authors': '著者',
            'metadata_publisher': '出版社',
            'metadata_pubdate': '出版日',
            'metadata_pubyear': '出版日',
            'metadata_language': '言語',
            'metadata_series': 'シリーズ',
            'no_metadata': 'メタデータなし',
            'no_series': 'シリーズなし',
            'unknown': '不明',
            
            # 複数冊の本の機能
            'books_unit': '冊',
            'new_conversation': '新しい会話',
            'single_book': '単一の本',
            'multi_book': '複数冊の本',
            'deleted': '削除されました',
            'history': '履歴',
            'no_history': '履歴レコードなし',
            'empty_question_placeholder': '（質問なし）',
            'history_ai_unavailable': 'このAIは設定から削除されました',
            'clear_current_book_history': '現在の本の履歴をクリア',
            'confirm_clear_book_history': '以下の本のすべての履歴を消去してもよろしいですか？\n{book_titles}',
            'confirm': '確認',
            'history_cleared': '{deleted_count}件の履歴記録が消去されました。',
            'multi_book_template_label': '複数本プロンプトテンプレート:',
            'multi_book_placeholder_hint': '{books_metadata}を本の情報に、{query}をユーザーの質問に使用してください',
            
            # エラーメッセージ
            'network_error': 'ネットワークエラー',
            'request_timeout': 'リクエストがタイムアウトしました',
            'request_failed': 'リクエスト失敗',
            'request_stopped': 'リクエストが停止されました',
            'question_too_long': '質問が長すぎます',
            'question_too_long_detail': (
                'プロンプトが長すぎます（現在 {current} 文字、制限 {limit} 文字、{over} 文字超過）。'
                '選択した書籍数：{book_count} 冊。'
            ),
            'question_too_long_detail_library': (
                'プロンプトが長すぎます（現在 {current} 文字、制限 {limit} 文字、{over} 文字超過）。'
                'ライブラリインデックスの書籍数：{book_count} 冊。'
            ),
            'question_too_long_hint_ai_search': (
                'ライブラリ全体の検索には AI Search を使用してください（書籍を選択せずに質問する、'
                'または AI Search メニューを使用）。多数の書籍を選択するのではなく。'
            ),
            'question_too_long_hint_library_search': (
                'ライブラリインデックスが現在のプロンプト制限を超えています。'
                'プラグイン設定 → General で「カスタムプロンプト長制限」を有効にしてください'
                '（推奨：524288 文字）、またはより具体的な質問をしてください。'
            ),
            'question_too_long_reduce_books': (
                '少数の書籍を詳しく比較する場合は、約 {count} 冊の選択を解除してみてください。'
            ),
            'question_too_long_hint_default': (
                '現在のデフォルト制限：{limit} 文字（{mode}）。'
                '単一書籍のデフォルトは 128,000 文字、複数書籍は 256,000 文字。'
                '上級ユーザーはプラグイン設定 → General でカスタム制限を有効にできます。'
            ),
            'question_too_long_hint_custom': (
                'カスタムプロンプト長制限が有効です。リクエストがタイムアウトする場合は、'
                'プラグイン設定 → General で制限を下げるか、選択書籍を減らすか、'
                'より具体的な質問にしてください。'
            ),
            'large_selection_dialog_title': '多数の書籍が選択されています',
            'large_selection_dialog_message': (
                '{count} 冊の書籍が選択されています。ライブラリ全体に関する質問には '
                'AI Search が適しており、コンパクトなメタデータでライブラリ全体を検索します。\n\n'
                'AI Search に切り替えますか？それとも選択した書籍でコンパクト形式のまま続けますか？'
            ),
            'large_selection_use_ai_search': 'AI Search を使用',
            'large_selection_continue': '選択した書籍で続行',
            'multi_book_entry_header': '書籍{idx}:',
            'multi_book_truncation_note': (
                '注意：プロンプト制限により、選択した {total} 冊のうち最初の {included} 冊のみが'
                '含まれます。ライブラリ全体を検索するには AI Search を使用するか、'
                'プラグイン設定 → General でカスタム制限を引き上げてください。'
            ),
            'library_metadata_truncation_note': (
                '注意：プロンプト制限により、インデックス済み {total} 冊のうち最初の {included} 冊のみが'
                '含まれます。非常に大きなライブラリでは結果が不完全になる場合があります。'
                'プラグイン設定 → General でカスタム制限を引き上げてください。'
            ),
            'auth_token_required_title': 'APIキーが必要です',
            'auth_token_required_message': 'プラグイン設定で有効なAPIキーを設定してください。',
            'open_configuration': '設定を開く',
            'cancel': 'キャンセル',
            
            # AI Manager Dialog
            'ai_manager_title': 'AIプロバイダーを管理',
            'add_ai_title': 'AIプロバイダーを追加',
            'manage_ai_title': '設定済みAIを管理',
            'configured_ai_list': '設定済みAI',
            'available_ai_list': '追加可能',
            'ai_config_panel': '設定',
            'select_ai_to_configure': 'リストからAIを選択して設定してください',
            'select_provider': 'AIプロバイダーを選択',
            'select_provider_hint': 'リストからプロバイダーを選択してください',
            'select_ai_to_edit': 'リストからAIを選択して編集してください',
            'set_as_default': 'デフォルトに設定',
            'save_ai_config': '保存',
            'remove_ai_config': '削除',
            'delete_ai': '削除',
            'close_button': '閉じる',
            'add_ai_button': 'AIを追加',
            'ai_manager_window_hint': '「追加 / 管理」はリサイズ可能な別ウィンドウで開きます（最大化可）。設定済み AI をダブルクリックで編集できます。',
            'edit_ai_button': 'AIを編集',
            'manage_configured_ai_button': '設定済みAIを管理',
            'manage_ai_button': 'AIを管理',
            'no_configured_ai': 'まだAIが設定されていません',
            'no_configured_ai_hint': 'AIが設定されていません。プラグインは動作しません。「AIを追加」をクリックしてAIプロバイダーを追加してください。',
            'default_ai_label': 'デフォルトAI:',
            'default_ai_tag': 'デフォルト',
            'ai_not_configured_cannot_set_default': 'このAIはまだ設定されていません。まず設定を保存してください。',
            'ai_set_as_default_success': '{name} がデフォルトAIに設定されました。',
            'ai_config_saved_success': '{name} の設定が正常に保存されました。',
            'confirm_remove_title': '削除の確認',
            'confirm_remove_ai': '{name} を削除してもよろしいですか？APIキーがクリアされ、設定がリセットされます。',
            'confirm_delete_title': '削除の確認',
            'confirm_delete_ai': '{name} を削除してもよろしいですか？',
            'api_key_required': 'APIキーは必須です。',
            'success': '成功',
            'configuration': '設定',
            'yes_button': 'はい',
            'no_button': 'いいえ',
            'cancel_button': 'キャンセル',
            "invalid_default_ai_title": "無効なデフォルトAI",
            "invalid_default_ai_message": "デフォルトのAI「{default_ai}」が正しく設定されていません。\n\n代わりに「{first_ai}」に切り替えますか？",
            "switch_to_ai": "{ai} に切り替える",
            "keep_current": "現在のままにする",
            'error_preparing_request': 'リクエストの準備に失敗しました',
            'empty_suggestion': '空の提案',
            'process_suggestion_error': '提案の処理中にエラーが発生しました',
            'unknown_error': '不明なエラー',
            'unknown_model': '不明なモデル: {model_name}',
            'suggestion_error': '提案エラー',
            'random_question_success': 'ランダムな質問が正常に生成されました！',
            'book_title_check': '本のタイトルが必要です',
            'avoid_repeat_question': '別の質問を使用してください',
            'empty_answer': '空の回答',
            'invalid_response': '無効な応答',
            'auth_error_401': '認証されていません',
            'auth_error_403': 'アクセスが拒否されました',
            'rate_limit': 'リクエストが多すぎます',
            'invalid_json': '無効なJSON',
            'no_response': '応答なし',
            'template_error': 'テンプレートエラー',
            'no_model_configured': 'AIモデルが設定されていません。設定でAIモデルを設定してください。',
            'no_ai_configured_title': 'AIが設定されていません',
            'no_ai_configured_message': 'ようこそ！書籍について質問を始めるには、まずAIプロバイダーを設定する必要があります。\n\n朗報：このプラグインには無料プラン（Nvidia AI Free）があり、設定なしですぐに使用できます！\n\nその他のおすすめオプション：\n• Nvidia AI - 電話番号だけで6ヶ月間の無料APIアクセスを取得（クレジットカード不要）\n• Ollama - コンピューター上でローカルにAIモデルを実行（完全無料でプライベート）\n\n今すぐプラグイン設定を開いてAIプロバイダーをセットアップしますか？',
            'open_settings': 'プラグイン設定',
            'ask_anyway': 'とにかく質問する',
            'later': '後で',
            'reset_all_data': 'すべてのデータをリセット',
            'reset_all_data_warning': 'リセット後、すべての設定とデータが完全に削除されます。これには、すべてのAPIキー、AI検索インデックスデータ、言語設定、AIの使用設定、その他のローカルデータが含まれます。',
            'reset_all_data_confirm_title': 'リセットの確認',
            'reset_all_data_confirm_message': 'プラグインを初期状態にリセットしてもよろしいですか？\n\nこれにより永久に削除されます：\n• すべてのAPIキー\n• すべてのカスタムプロンプトテンプレート\n• すべての会話履歴\n• すべてのプラグイン設定（言語設定を含む）\n\nこの操作は元に戻せません！',
            'reset_all_data_success': 'すべてのプラグインデータが正常にリセットされました。変更を有効にするためにcalibreを再起動してください。',
            'reset_all_data_failed': 'プラグインデータのリセットに失敗しました: {error}',
            'random_question_error': 'ランダムな質問の生成中にエラーが発生しました',
            'clear_history_failed': '履歴のクリアに失敗しました',
            'clear_history_not_supported': '単一の本の履歴クリアはまだサポートされていません',
            'missing_required_config': '必要な設定が不足しています: {key}。設定を確認してください。',
            'api_key_too_short': 'APIキーが短すぎます。確認して完全なキーを入力してください。',
            
            # API応答処理
            'api_request_failed': 'APIリクエストに失敗しました: {error}',
            'api_content_extraction_failed': 'API応答からコンテンツを抽出できませんでした',
            'api_invalid_response': '有効なAPI応答を取得できませんでした',
            'api_unknown_error': '不明なエラー: {error}',
            
            # ストリーミング応答処理
            'stream_response_code': 'ストリーミング応答ステータスコード: {code}',
            'stream_continue_prompt': 'すでに提供されたコンテンツを繰り返さずに、前の応答を続けてください。',
            'stream_continue_code_blocks': '前の応答には閉じられていないコードブロックがありました。続けてこれらのコードブロックを完成させてください。',
            'stream_continue_parentheses': '前の応答には閉じられていない括弧がありました。続けて、すべての括弧が適切に閉じられていることを確認してください。',
            'stream_continue_interrupted': '前の応答が中断されたようです。続けて、最後の考えや説明を完了させてください。',
            'stream_timeout_error': 'ストリーミング送信が60秒間新しいコンテンツを受信していません。接続の問題の可能性があります。',
            
            # APIエラーメッセージ
            'api_version_model_error': 'APIバージョンまたはモデル名のエラー: {message}\n\n設定でAPIベースURLを「{base_url}」に、モデルを「{model}」または利用可能な別のモデルに更新してください。',
            'api_format_error': 'APIリクエスト形式のエラー: {message}',
            'api_key_invalid': 'APIキーが無効または認証されていません: {message}\n\nAPIキーを確認し、APIアクセスが有効になっていることを確認してください。',
            'api_rate_limit': 'リクエストレート制限を超過しました。後で再試行してください\n\n無料使用量を超えた可能性があります。次の原因が考えられます：\n1. 1分あたりのリクエストが多すぎる\n2. 1日あたりのリクエストが多すぎる\n3. 1分あたりの入力トークンが多すぎる',
            
            # 設定エラー
            'missing_config_key': '必要な設定キーが不足しています: {key}',
            'api_base_url_required': 'APIベースURLが必要です',
            'model_name_required': 'モデル名が必要です',
            'api_key_empty': 'APIキーが空です。有効なAPIキーを入力してください。',
            
            # モデルリスト取得
            'fetching_models_from': '{url}からモデルを取得中',
            'successfully_fetched_models': '{count}個の{provider}モデルを正常に取得しました',
            'failed_to_fetch_models': 'モデルの取得に失敗しました：{error}',
            
            # 情報について
            'author_name': 'Sheldon',
            'user_manual': 'ユーザーマニュアル',
            'about_plugin': 'Ask AI Pluginの特徴',
            'learn_how_to_use': '使い方',
            'email': 'iMessage',
            'about_title': 'Ask AI Pluginについて',
            'about_version_label': 'バージョン',
            'about_description': '選択したAIサービスを使って、calibreの本について質問できます。',
            'about_latest_update': '最新の更新（2026.10.16）：最新のモデル名に更新しました',
            'about_mobileread_link_text': 'MobileRead',
            'about_open_button': 'MobileRead',
            'about_mobileread_note': '注：MobileRead は calibre プラグインの公開とバージョン更新情報のための開発者ページです。',
            'about_related_plugins': '関連プラグイン',
            'about_markdown_title': 'Markdown for calibre',
            'about_markdown_desc': '本をMarkdownテキストファイルとしてエクスポートします。',
            'about_tradsimp_title': 'Chinese Text Conversion for calibre',
            'about_tradsimp_desc': '電子書籍内の繁体字中国語と簡体字中国語を変換します。',
            'about_simple_goal_title': 'Simple Goal for calibre',
            'about_simple_goal_desc': '読んでいる本の短いリストを管理し、進捗を確認し、ビューアから同期します。',
            'about_booktoast_title': 'Booktoast for calibre',
            'about_booktoast_desc': 'calibre を開いたとき、以前マークしたハイライトを短時間表示します。',
            'about_open_mobileread': 'MobileReadを開く',
            'about_open_nowtiny': 'Nowtinyを開く',
            'about_nowtiny_note': 'その他のツールとプラグインの状態はNowtinyで確認できます。',
            
            # モデル固有の設定
            'model_display_name_grok': 'SpaceXSI',
            'model_display_name_gemini': 'Gemini(Google)',
            'model_display_name_deepseek': 'Deepseek',
            'model_display_name_kimi': 'Kimi（Moonshot）',
            'model_display_name_mistral': 'Mistral',
            'model_display_name_custom': 'カスタム (OpenAI 互換)',
            'model_display_name_ollama': 'Ollama(ローカル)',
            'model_display_name_lmstudio': 'LM Studio(ローカル)',
            'model_display_name_koboldcpp': 'KoboldCpp(ローカル)',
            'custom_openai_compat_notice': 'ヒント：カスタム提供元は OpenAI Chat Completions 形式（/chat/completions）を使用します。互換性のある Base URL とモデル名を入力してください。一部のローカルサーバーでは API Key は任意です。',
            'local_openai_compat_no_api_key_notice': 'ヒント：このローカル OpenAI 互換サービスは通常 API Key を必要としません。先にローカルサーバーを起動してからモデル一覧を更新してください。',
            'lmstudio_no_api_key_notice': 'ヒント：LM Studio はローカルで OpenAI 互換 API を使用し、通常 API Key は不要です。',
            'koboldcpp_no_api_key_notice': 'ヒント：KoboldCpp はローカルで OpenAI 互換 API を使用し、通常 API Key は不要です。',
            'local_service_not_running': 'ローカル AI サービスに接続できません。起動中であることと Base URL が正しいことを確認してください。',
            'model_enable_streaming': 'ストリーミングを有効にする',
            
            # AIスイッチャー
            'current_ai': '現在のAI',
            'no_configured_models': 'AIが設定されていません - 設定で設定してください',
            
            # プロバイダー固有の情報
            'nvidia_free_info': '💡 新規ユーザーは6か月間無料でAPIアクセスを利用できます - クレジットカードは不要です',
            
            # 一般的なシステムメッセージ
            'default_system_message': 'あなたは本の分析の専門家です。あなたの仕事は、洞察に満ちた質問と分析を提供することで、ユーザーが本をよりよく理解できるようにすることです。',
            
            # リクエストタイムアウト設定
            'request_timeout_label': 'リクエストタイムアウト:',
            'seconds': '秒',
            'request_timeout_error': 'リクエストがタイムアウトしました。現在のタイムアウト: {timeout}秒',
            'timeout_too_short_title': 'リクエストがタイムアウトしました',
            'timeout_too_short_message': (
                'タイムアウトが短すぎたためリクエストに失敗しました。現在のリクエストタイムアウトを'
                '「{current_seconds}秒」（{current_minutes}分）から「{new_seconds}秒」（{new_minutes}分）に延長しますか？'
            ),
            'timeout_increase_button': '延長する',
            'timeout_increased_toast': 'タイムアウトを{seconds}秒に変更しました。再試行してください。',
            'max_prompt_length_normalized_title': 'プロンプト制限を調整しました',
            'max_prompt_length_normalized': 'プロンプト長を {value} 文字に正規化しました（カンマやスペースなどの区切り文字を削除しました）。',
            'enable_custom_prompt_limit_label': 'カスタムプロンプト長制限',
            'enable_custom_prompt_limit_tooltip': (
                'デフォルト制限は単一書籍 128,000 文字、複数書籍 256,000 文字です。'
                'ほとんどのユーザーは変更不要です。ライブラリ全体の検索には AI Search を使用してください。'
                'モデルがより大きなコンテキストをサポートし、リクエストが制限に達する場合のみ'
                'カスタム制限を有効にしてください。'
            ),
            'max_prompt_length_label': '最大プロンプト長：',
            'max_prompt_length_unit': '文字',
            'max_prompt_length_tooltip': (
                'カスタム制限が有効な場合に適用されます。デフォルト推奨：524288 文字。'
                '目安：1 トークン ≈ 3–4 文字。Ollama 使用時はモデル側でも num_ctx を設定してください。'
            ),
            
            # 並列AI設定
            'parallel_ai_count_label': '並列AIの数:',
            'parallel_ai_count_tooltip': '同時にクエリを実行するAIモデルの数（1-2が利用可能、3-4は近日公開）',
            'parallel_ai_notice': '注意: これは質問の送信にのみ影響します。ランダムな質問は常に単一のAIを使用します。',
            'suggest_maximize': 'ヒント: 3つのAIでより見やすくするためにウィンドウを最大化してください',
            'ai_panel_label': 'AI {index}:',
            'no_ai_available': 'このパネルで利用可能なAIはありません',
            'add_more_ai_providers': '設定でAIプロバイダーを追加してください',
            'select_ai': '-- AIを選択 --',
            'select_model': '-- モデルを切り替え --',
            'request_model_list': 'モデルリストをリクエストしてください',
            'coming_soon': '近日公開',
            'advanced_feature_tooltip': 'この機能は開発中です。更新情報にご期待ください！',
            
            # PDFエクスポートセクションのタイトル
            'pdf_book_metadata': '書籍のメタデータ',
            'pdf_question': '質問',
            'pdf_answer': '回答',
            'pdf_ai_model_info': 'AIモデル情報',
            'pdf_generated_by': '生成元',
            'pdf_provider': 'プロバイダー',
            'pdf_model': 'モデル',
            'pdf_api_base_url': 'APIベースURL',
            'pdf_panel': 'パネル',
            'pdf_plugin': 'プラグイン',
            'pdf_github': 'GitHub',
            'pdf_software': 'ソフトウェア',
            'pdf_generated_time': '生成時間',
            'pdf_info_not_available': '情報が利用できません',
            
            # Library Chat feature (v1.4.2)
            'library_tab': '検索',
            'library_search': 'AI検索',
            'library_info': 'AI検索は常に有効です。本を選択しない場合、自然言語でライブラリ全体を検索できます。',
            'library_enable': 'AI検索を有効にする',
            'library_enable_tooltip': '有効にすると、本が選択されていない場合にAIを使用してライブラリを検索できます',
            'library_update': 'ライブラリデータを更新',
            'library_update_tooltip': '全冊の書名・著者を索引し、コンパクトなプロンプトキャッシュを再構築します',
            'library_updating': '更新中...',
            'library_status': 'ステータス：{count}冊、最終更新：{time}',
            'library_status_empty': 'ステータス：データなし。「ライブラリデータを更新」をクリックして開始してください。',
            'library_status_error': 'ステータス：データの読み込みエラー',
            'library_update_success': '{count}冊の本を正常に更新しました',
            'library_update_failed': 'ライブラリデータの更新に失敗しました',
            'library_no_gui': 'GUIが利用できません',
            'library_init_title': 'AI検索を初期化',
            'library_init_message': 'AI検索を機能させるにはライブラリメタデータが必要です。今すぐ初期化しますか？\n\nこれにより、ライブラリから書籍のタイトルと著者が抽出されます。',
            'library_init_required': 'ライブラリデータなしではAI検索を有効にできません。この機能を使用する準備ができたら、「ライブラリデータを更新」をクリックしてください。',
            'ai_search_welcome_title': 'AI検索へようこそ',
            'ai_search_welcome_message': (
                'AI検索が有効です。書名・著者で自然言語検索できます。\n'
                '\n'
                '本を選ばずにAskを開くか、ツール → AI検索／ショートカットを使います。\n'
                '本の追加・削除後は「図書館データを更新」でプロンプトキャッシュを更新してください。'
            ),
            'ai_search_not_enough_books_title': '本が足りません',
            'ai_search_not_enough_books_message': 'AI検索を使用するには、ライブラリに少なくとも {min_books} 冊の本が必要です。\n\n現在のライブラリには {book_count} 冊しかありません。\n\nAI検索を使用するには、もっと本を追加してください。',
            'ai_search_mode_info': 'ライブラリ全体を検索中',
            'ai_search_feature_title': 'AI Search',
            'ai_search_feature_subtitle': '自然言語でライブラリ全体を検索',
            'ai_search_feature_description': (
                '書名・著者で自然言語検索します。\n'
                '本を選ばずにAskを開くか、ツール → AI検索を使います。\n'
                '本の追加・削除後は「図書館データを更新」で検索用のコンパクトなプロンプトキャッシュを更新します。'
            ),
            'ai_search_usage_hint': '',
            'ai_search_data_title': 'ライブラリインデックス',
            'ai_search_data_subtitle': '本の追加・削除後に索引とプロンプトキャッシュを再構築',
            'library_search_system_message': 'あなたは calibre のライブラリ検索アシスタントです。ユーザーが指定した HTML リスト形式でのみ一致する本を返してください。分析・思考過程・前置きは不要です。',
            'library_output_only_rule': '重要：一致する書籍だけを上のHTML箇条書きとして出力してください。分析、思考過程、リスト以外の文章は不要です。',
            'library_prompt_template': 'ユーザーの書籍ライブラリにアクセスできます。すべての書籍は次のとおりです：{metadata} ユーザーのクエリ：{query} 現在のライブラリ内で一致する書籍を見つけ、次の形式で返してください（**重要**：HTMLリンク形式を使用して、ユーザーが書籍タイトルをクリックして直接開けるようにしてください）：- <a href="calibre://book/BOOK_ID">書籍タイトル</a> - 著者名 例：- <a href="calibre://book/123">Pythonを学ぶ</a> - Mark Lutz - <a href="calibre://book/456">機械学習実践</a> - Peter Harrington 注意：一部の著者は「unknown」と表示される場合があります。これは正常なデータです。すべての一致する結果を正常に返してください。クエリに一致する書籍のみを返してください。最大5件。',
            
            'default_ai_mismatch_title': 'デフォルトAIが変更されました',
            'default_ai_mismatch_message': '設定のデフォルトAIが"{default_ai}"に変更されましたが、\n現在のダイアログは"{current_ai}"を使用しています。\n\n新しいデフォルトAIに切り替えますか？',
            'discard_changes': '変更を破棄',
            'empty_response': 'APIから空のレスポンスを受信しました',
            'empty_response_after_filter': 'thinkタグのフィルタリング後、レスポンスが空です',
            'error_401': 'APIキー認証に失敗しました。確認してください：APIキーが正しい、アカウントに十分な残高がある、APIキーが期限切れでない。',
            'error_403': 'アクセスが拒否されました。確認してください：APIキーに十分な権限がある、地域アクセス制限がない。',
            'error_404': 'APIエンドポイントが見つかりません。APIベースURLの設定が正しいか確認してください。',
            'error_429': 'リクエストが多すぎます。レート制限に達しました。後でもう一度お試しください。',
            'error_5xx': 'サーバーエラー。後でもう一度お試しいただくか、サービスプロバイダーのステータスを確認してください。',
            'error_network': 'ネットワーク接続に失敗しました。ネットワークが使えること、プロキシ設定が正しいこと、ファイアウォールがアクセスを許可していることを確認してください。APIキーが無効な可能性もあるため、有効なキーに換えて再試行してください。',
            'error_unknown': '不明なエラー。',
            'http_status_detail': 'HTTP {status}、URL: {url}',
            'gemini_geo_restriction': 'Gemini APIはお住まいの地域では利用できません。お試しください：\n1. サポートされている地域からVPNを使用して接続する\n2. 他のAIプロバイダーを使用する（OpenAI、Anthropic、DeepSeekなど）\n3. Google AI Studioで地域の利用可能性を確認する',
            'load_models_list': 'モデルリストを読み込む',
            'loading_models_text': 'モデルを読み込んでいます',
            'model_test_success': 'モデルテストが成功しました！',
            'models_loaded_with_selection': '{count}個のモデルが正常に読み込まれました。\n選択されたモデル：{model}',
            'ollama_model_not_available': 'モデル"{model}"は利用できません。確認してください：\n1. モデルは起動していますか？実行：ollama run {model}\n2. モデル名は正しいですか？\n3. モデルはダウンロードされていますか？実行：ollama pull {model}',
            'ollama_service_not_running': 'Ollamaサービスが実行されていません。最初にOllamaサービスを起動してください。',
            'ollama_service_timeout': 'Ollamaサービス接続タイムアウト。サービスが正常に実行されているか確認してください。',
            'reset_ai_confirm_message': '{ai_name}をデフォルト状態にリセットしようとしています。\n\nこれにより以下がクリアされます：\n• APIキー\n• カスタムモデル名\n• その他の設定パラメータ\n\n続行しますか？',
            'reset_ai_confirm_title': 'リセットの確認',
            'reset_current_ai': '現在のAIをデフォルトにリセット',
            'reset_tooltip': '現在のAIをデフォルト値にリセット',
            'save_and_close': '保存して閉じる',
            'skip': 'スキップ',
            'technical_details': '技術的な詳細',
            'test_current_model': '現在のモデルをテスト',
            'test_model_button': 'モデルをテスト',
            'test_model_prompt': 'モデルが正常に読み込まれました！選択されたモデル"{model}"をテストしますか？',
            'unsaved_changes_message': '保存されていない変更があります。どうしますか？',
            'unsaved_changes_title': '未保存の変更',


            'pdf_info_not_available': '情報なし',
            
            # Field descriptions
            'api_key_desc': '認証用のAPIキー。安全に保管し、共有しないでください。',
            'base_url_desc': 'APIエンドポイントのURL。カスタムエンドポイントがない限り、デフォルトを使用してください。',
            'base_url_desc_kimi': '国際版のキーは https://api.moonshot.ai/v1、中国版のキーは https://api.moonshot.cn/v1 を使用します。混在させないでください。',
            'kimi_region_label': 'プラットフォーム',
            'kimi_region_global': '国際版',
            'kimi_region_china': '中国本土',
            'kimi_base_url_readonly_tip': 'Base URL は選択したプラットフォームによって決まります。',
            'model_desc': 'リストからモデルを選択するか、カスタムモデル名を使用してください。',
            'streaming_desc': 'リアルタイムレスポンスストリーミングを有効にして、より速いフィードバックを得ます。',
            'advanced_section': '詳細設定',
            
            # Provider-specific notices
            'perplexity_model_notice': '注意：Perplexityは公開モデルリストAPIを提供していないため、モデルはハードコードされています。',
            'ollama_no_api_key_notice': 'Note: Ollama uses the OpenAI-compatible API locally and usually does not require an API key.',
            'nvidia_free_credits_notice': '注意：新規ユーザーは無料のAPIクレジットを取得できます - クレジットカード不要。',
            
            # Nvidia Free エラーメッセージ
            'free_tier_rate_limit': '無料プランのレート制限を超えました。しばらくしてから再試行するか、独自のNvidia APIキーを設定してください。',
            'free_tier_gone': '無料の Nvidia チャネルは利用できなくなりました（HTTP 410）。設定 → AI で独自の Nvidia API キー（Nvidia AI）を設定するか、無料サービスが復旧するまでお待ちください。',
            'free_tier_unavailable': '無料プランは一時的に利用できません。しばらくしてから再試行するか、独自のNvidia APIキーを設定してください。',
            'free_tier_server_error': '無料プランのサーバーエラーが発生しました。しばらくしてから再試行してください。',
            'free_tier_error': '無料プランエラー',
            
            # Nvidia Free プロバイダー情報
            'free': '無料',
            'nvidia_free_provider_name': 'Nvidia AI（無料）',
            'nvidia_free_display_name': 'Nvidia AI（無料）',
            'nvidia_free_api_key_info': 'サーバーから取得されます',
            'nvidia_free_desc': 'このサービスは開発者によって維持され、無料で提供されていますが、安定性が低い場合があります。より安定したサービスが必要な場合は、独自のNvidia APIキーを設定してください。',
            
            # Nvidia Free 初回使用リマインダー
            'nvidia_free_first_use_title': 'Ask AI プラグインへようこそ',
            'nvidia_free_first_use_message': '設定なしですぐに質問できます！開発者が無料プランを維持していますが、あまり安定していない可能性があります。お楽しみください！\n\nより安定したサービスを利用するには、設定で独自のAIプロバイダーを設定できます。',
            
            # Model buttons
            'refresh_model_list': '更新',
            'testing_text': 'テスト中',
            'refresh_success': 'モデルリストが正常に更新されました。',
            'refresh_failed': 'モデルリストの更新に失敗しました。',
            'test_failed': 'モデルテストが失敗しました。',
            
            # Tooltip
            'manage_ai_disabled_tooltip': '最初にAIプロバイダーを追加してください。',

            #AI Search v1.4.2
            'library_tab': '検索',
            'library_search': 'AI検索',
            'library_info': 'AI検索は常に有効です。本を選択していない状態では、自然言語を使用してライブラリ全体を検索できます。',
            'library_enable': 'AI検索を有効化',
            'library_enable_tooltip': '有効にすると、本を選択していない時にAIを使用してライブラリを検索できます',
            'library_update': 'ライブラリデータの更新',
            'library_update_tooltip': '全冊の書名・著者を索引し、コンパクトなプロンプトキャッシュを再構築します',
            'library_updating': '更新中...',
            'library_status': 'ステータス: {count} 冊、最終更新: {time}',
            'library_status_empty': 'ステータス: データなし。「ライブラリデータの更新」をクリックして開始してください。',
            'library_status_error': 'ステータス: データの読み込みエラー',
            'library_update_success': '{count} 冊の本の更新に成功しました',
            'library_update_failed': 'ライブラリデータの更新に失敗しました',
            'library_no_gui': 'GUIが利用不可',
            'library_init_title': 'AI検索の初期化',
            'library_init_message': 'AI検索を利用するにはライブラリのメタデータが必要です。今すぐ初期化しますか？\n\nこれにより、ライブラリから本のタイトルと著者名が抽出されます。',
            'library_init_required': 'ライブラリデータなしでAI検索を有効にすることはできません。準備ができたら「ライブラリデータの更新」をクリックしてください。',
            'ai_search_welcome_title': 'AI検索へようこそ',
            'ai_search_welcome_message': (
                'AI検索が有効です。書名・著者で自然言語検索できます。\n'
                '\n'
                '本を選ばずにAskを開くか、ツール → AI検索／ショートカットを使います。\n'
                '本の追加・削除後は「図書館データを更新」でプロンプトキャッシュを更新してください。'
            ),
            'ai_search_not_enough_books_title': '本が足りません',
            'ai_search_not_enough_books_message': 'AI検索を使用するには、ライブラリに少なくとも {min_books} 冊の本が必要です。\n\n現在のライブラリには {book_count} 冊しかありません。\n\nAI検索を使用するには、もっと本を追加してください。',
            'ai_search_mode_info': 'ライブラリ全体を検索中',
            'ai_search_feature_title': 'AI Search',
            'ai_search_feature_subtitle': '自然言語でライブラリ全体を検索',
            'ai_search_feature_description': (
                '書名・著者で自然言語検索します。\n'
                '本を選ばずにAskを開くか、ツール → AI検索を使います。\n'
                '本の追加・削除後は「図書館データを更新」で検索用のコンパクトなプロンプトキャッシュを更新します。'
            ),
            'ai_search_usage_hint': '',
            'ai_search_data_title': 'ライブラリインデックス',
            'ai_search_data_subtitle': '本の追加・削除後に索引とプロンプトキャッシュを再構築',
            'library_output_only_rule': '重要：一致する書籍だけを上のHTML箇条書きとして出力してください。分析、思考過程、リスト以外の文章は不要です。',
            'library_prompt_template': 'ユーザーの書籍ライブラリにアクセスできます。すべての書籍は次のとおりです：{metadata} ユーザーのクエリ：{query} 現在のライブラリ内で一致する書籍を見つけ、次の形式で返してください（**重要**：HTMLリンク形式を使用して、ユーザーが書籍タイトルをクリックして直接開けるようにしてください）：- <a href="calibre://book/BOOK_ID">書籍タイトル</a> - 著者名 例：- <a href="calibre://book/123">Pythonを学ぶ</a> - Mark Lutz - <a href="calibre://book/456">機械学習実践</a> - Peter Harrington 注意：一部の著者は「unknown」と表示される場合があります。これは正常なデータです。すべての一致する結果を正常に返してください。クエリに一致する書籍のみを返してください。最大5件。',
            'ai_search_privacy_title': 'プライバシーに関するお知らせ',
            'ai_search_privacy_alert': 'AI検索はライブラリの本のメタデータ（タイトルと著者）を使用します。この情報は、検索クエリを処理するために設定されたAIプロバイダーに送信されます。',
            'ai_search_updated_info': '{time_ago}に {count} 冊の本を更新',
            'ai_search_books_info': '{count} 冊の本がインデックス済み',
            'days_ago': '{n} 日前',
            'hours_ago': '{n} 時間前',
            'minutes_ago': '{n} 分前',
            'just_now': 'たった今',
            
            # Statistics tab (v1.4.2)
            'stat_tab': '統計',
            'stat_overview': '概要',
            'stat_overview_subtitle': 'AI問い合わせ回数の統計',
            'stat_days_unit': '日',
            'stat_days_label': '利用開始',
            'stat_start_at': '{date}から開始',
            'stat_replies_unit': '回',
            'stat_replies_label': 'AI問い合わせ',
            'stat_books_unit': '冊',
            'stat_books_label': '蔵書数',
            'stat_no_books': '検索タブで更新',
            'stat_trends': 'トレンド',
            'stat_curious_index': '今週のAI問い合わせ回数分布',
            'stat_daily_avg': '1日平均 {n} 回',
            'stat_sample_data': 'サンプルデータを表示中。20回以上のリクエスト後に実データに切り替わります',
            'stat_heatmap': 'ヒートマップ',
            'stat_heatmap_subtitle': '今月のAI問い合わせ回数分布',
            'stat_no_data_week': '今週のデータはありません',
            'stat_no_data_month': '今月のデータはありません',
            'stat_data_not_enough': 'データが不足しています',
            
            # 統計ユーザー称号（問い合わせ回数に基づく）
            'stat_title_curious': '本めくり',
            'stat_title_explorer': '書籍探し',
            'stat_title_seeker': '読書家',
            'stat_title_enthusiast': '蔵書家',
            'stat_title_pursuer': '本の虫',
            
            # 統計書庫評価（蔵書数に基づく、歴史的図書館の典故）
            'stat_books_impressive': '私設文庫',
            'stat_books_collection': '書斎',
            'stat_books_variety': '正倉院',
            'stat_books_awesome': '国立国会図書館',
            'stat_books_unbelievable': 'アレクサンドリア図書館',
            
            # Links (v1.4.2)
            'online_tutorial': 'オンラインチュートリアル',
        }
