#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import logging
import copy

# 初始化日志
logger = logging.getLogger(__name__)

_TEXT_ENCODINGS = (
    'utf-8',
    'utf-16le',
    'utf-16be',
    'gb18030',
    'big5',
    'shift_jis',
    'euc-kr',
    'windows-1256',
    'iso-8859-6',
    'windows-1251',
    'windows-1252',
    'iso-8859-8',
    'windows-1255',
)


def as_unicode_text(value, default=''):
    """把标题/作者等元数据稳妥转成 Unicode，避免非拉丁文字变成 ?。"""
    if value is None:
        return default
    if isinstance(value, bytes):
        for encoding in _TEXT_ENCODINGS:
            try:
                text = value.decode(encoding)
            except (UnicodeDecodeError, LookupError):
                continue
            if '\ufffd' in text:
                continue
            return text.replace('\u2028', '\n').replace('\u2029', '\n')
        return value.decode('utf-8', 'replace').replace('\u2028', '\n').replace('\u2029', '\n')
    return str(value).replace('\u2028', '\n').replace('\u2029', '\n')


OPTIONAL_PROMPT_FIELDS = ('author', 'publisher', 'pubyear', 'language', 'series')
_PLACEHOLDER_TOKENS = frozenset({
    'unknown', 'n/a', 'na', 'none', 'null', 'nil', 'und', 'un', 'zxx',
    '-', '—', '–', '.',
    '未知', '不明',
    'unbekannt', 'inconnu', 'desconocido', 'desconhecido',
    'неизвестно', 'okänd', 'ukendt', 'ukjent', 'onbekend', 'tuntematon',
})


def is_placeholder_metadata(value, field=None):
    """True for empty/Unknown-like metadata, or numeric junk publishers such as 101."""
    if value is None:
        return True
    text = str(value).strip()
    if not text:
        return True
    if text.casefold() in _PLACEHOLDER_TOKENS:
        return True
    if field == 'publisher' and re.fullmatch(r'\d{1,4}', text):
        return True
    # Calibre stores an unknown publication date as year 101.
    if field == 'pubyear' and text in {'101', '0101'}:
        return True
    return False


_WATERMARK_RE = re.compile(
    r'[\(\[【（]\s*(?:'
    r'bookfi(?:\.org)?'
    r'|z-?lib(?:rary)?(?:\.org)?'
    r'|zlib(?:\.org)?'
    r'|libgen(?:\.[a-z]+)?'
    r'|library\s*genesis'
    r'|pdf[\s.\-]?drive(?:\.com)?'
    r'|ebook3000'
    r'|oceanofpdf'
    r'|b-ok(?:\.[a-z]+)?'
    r'|1lib(?:\.[a-z]+)?'
    r'|bookzz'
    r'|avaxhome'
    r')\s*[\)\]】）]',
    re.IGNORECASE,
)
_EMPTY_BRACKET_RE = re.compile(
    r'(?:^|(?<=\s))[\[\(\{【（《<〔｛]\s*[\]\)\}】）》>〕｝](?=\s|$)|'
    r'[\[\(\{【（《<〔｛]\s*[\]\)\}】）》>〕｝]$'
)


def clean_prompt_metadata_text(value):
    """Strip empty []/() wrappers and obvious download-site watermarks from prompt text."""
    if value is None:
        return ''
    text = str(value).strip()
    for _ in range(8):
        stripped = _WATERMARK_RE.sub('', text)
        stripped = _EMPTY_BRACKET_RE.sub('', stripped)
        stripped = re.sub(r'\s{2,}', ' ', stripped).strip(' \t,;')
        if stripped == text:
            break
        text = stripped
    return text


def is_legacy_short_prompt(saved, required_placeholders):
    """True for pre-v1.4.1 built-in prompts: short, and without the calibre context."""
    text = '' if saved is None else str(saved).strip()
    if not text or not required_placeholders:
        return False
    if not all(token in text for token in required_placeholders):
        return False
    if len(text) >= 350:
        return False
    lowered = text.lower()
    if 'calibre' in lowered or 'ask ai' in lowered:
        return False
    return True


def resolve_prompt_template(saved, localized_default, known_defaults, required_placeholders=()):
    """Use the interface-language built-in prompt unless the user wrote their own."""
    localized = '' if localized_default is None else str(localized_default).strip()
    saved_text = '' if saved is None else str(saved).strip()
    if not saved_text or is_legacy_short_prompt(saved_text, required_placeholders):
        return localized
    known = {str(item).strip() for item in known_defaults if item and str(item).strip()}
    if localized:
        known.add(localized)
    if saved_text in known:
        return localized
    return saved_text


def resolve_persona_text(saved_persona, localized_default, known_defaults):
    """Use the interface-language persona unless the user wrote their own."""
    localized = '' if localized_default is None else str(localized_default).strip()
    saved = '' if saved_persona is None else str(saved_persona).strip()
    if not saved:
        return localized
    known = {str(item).strip() for item in known_defaults if item and str(item).strip()}
    if localized:
        known.add(localized)
    if saved in known:
        return localized
    return saved


def omit_placeholder_template_fields(template, values):
    """Remove optional {author}/{publisher}/... clauses when the value is placeholder."""
    if not template:
        return template
    result = template
    for key in OPTIONAL_PROMPT_FIELDS:
        if not is_placeholder_metadata(values.get(key), field=key):
            continue
        result = re.sub(
            r'(?:[,，]\s*)?(?:[^,，{}:\n：]+[：:]\s*)?\{' + key + r'\}',
            '',
            result,
        )
    result = re.sub(r'[,，]\s*[,，]+', ',', result)
    result = re.sub(r'\s+[,，]', ',', result)
    result = re.sub(r'[,，]\s*[.。]', '.', result)
    result = re.sub(r'[ \t]{2,}', ' ', result)
    result = re.sub(r' +\n', '\n', result)
    result = re.sub(r'\n{3,}', '\n\n', result)
    return result.strip()


def mask_api_key(api_key, visible_chars=4, mask_chars=8):
    """
    隐藏API Key，只保留前几位字符，其余全部掩码
    
    :param api_key: 原始API Key
    :param visible_chars: 保留可见的前几位字符数（默认4）
    :param mask_chars: 显示的掩码字符数（默认8）
    :return: 隐藏后的API Key，格式如 "sk-o********"
    """
    if not api_key or len(api_key) <= visible_chars:
        return api_key
    
    # 保留前visible_chars位
    visible_part = api_key[:visible_chars]
    
    # 后面全部用固定数量的*号替代，不暴露任何额外信息
    mask_part = '*' * mask_chars
    
    return visible_part + mask_part

def mask_api_key_in_text(text):
    """
    隐藏文本中的API Key
    
    :param text: 包含API Key的文本
    :return: 隐藏API Key后的文本
    """
    if not text:
        return text
    
    # 隐藏URL参数中的API Key
    text = re.sub(r'(key=|api_key=|token=|auth_token=)([A-Za-z0-9_-]{4})([A-Za-z0-9_-]{8})([A-Za-z0-9_-]*)', 
                 r'\1\2********\4', text)
    
    # 隐藏JSON中的API Key
    text = re.sub(r'("api_key"|"key"|"token"|"auth_token")\s*:\s*"([A-Za-z0-9_-]{4})([A-Za-z0-9_-]{8})([A-Za-z0-9_-]*)"', 
                 r'\1:"\\2********\4"', text)
    
    return text

def safe_log_config(config, keys_to_mask=None):
    """
    安全地记录配置信息，隐藏敏感信息
    
    :param config: 配置字典
    :param keys_to_mask: 需要掩码的键列表，默认为['api_key', 'key', 'token', 'auth_token']
    :return: 处理后的配置字典副本
    """
    if config is None:
        return None
    
    if keys_to_mask is None:
        keys_to_mask = ['api_key', 'key', 'token', 'auth_token']
    
    # 创建配置的深拷贝，避免修改原始配置
    safe_config = copy.deepcopy(config)
    
    # 遍历配置，掩码敏感信息
    for key, value in safe_config.items():
        if key in keys_to_mask and isinstance(value, str) and value:
            safe_config[key] = mask_api_key(value)
        elif isinstance(value, dict):
            safe_config[key] = safe_log_config(value, keys_to_mask)
    
    return safe_config


def _sanitize_metadata_field(text):
    """Normalize title/author text for compact TSV (cross-platform line endings)."""
    text = clean_prompt_metadata_text(text)
    text = text.replace('\r\n', ' ').replace('\r', ' ')
    text = text.replace('\u2028', ' ').replace('\u2029', ' ')
    text = text.replace('|', '/').replace('\n', ' ')
    return text


def split_compact_tsv_lines(tsv_text):
    """Split compact TSV into non-empty lines, tolerating CRLF."""
    if not tsv_text:
        return []
    return [line for line in tsv_text.splitlines() if line.strip()]


def format_books_compact_tsv(books):
    """
    Format book entries as compact TSV lines: id|title|authors

    :param books: list of dicts (id, title, authors) or Calibre Metadata objects
    :return: compact TSV string
    """
    lines = []
    for book in books:
        if isinstance(book, dict):
            book_id = book.get('id', '')
            title = book.get('title', 'Unknown') or 'Unknown'
            authors = book.get('authors', 'Unknown') or 'Unknown'
        else:
            book_id = getattr(book, 'id', '')
            title = getattr(book, 'title', None) or 'Unknown'
            author_list = getattr(book, 'authors', None) or ['Unknown']
            authors = ', '.join(author_list) if author_list else 'Unknown'

        title = _sanitize_metadata_field(title)
        authors = _sanitize_metadata_field(authors)
        lines.append(f"{book_id}|{title}|{authors}")
    return '\n'.join(lines)


def _get_library_book_ids(db):
    """Return all book ids from a Calibre db (full library)."""
    try:
        return list(db.new_api.all_book_ids())
    except AttributeError:
        return list(db.data.search_getting_ids('', db.FIELD_MAP['search']))


def compute_library_ids_fingerprint(book_ids):
    """
    Fingerprint a library by sorted book ids (count + membership).

    :return: (fingerprint_hex, book_count)
    """
    import hashlib
    parts = sorted(str(int(book_id)) for book_id in book_ids)
    digest = hashlib.sha1(','.join(parts).encode('utf-8')).hexdigest()
    return digest, len(parts)


def format_library_metadata_for_prompt(prefs):
    """Return compact TSV for prompts; prefer prebuilt cache, else rebuild from JSON."""
    cached_tsv = prefs.get('library_cached_tsv', '') or ''
    if cached_tsv.strip():
        return cached_tsv

    cached_metadata = get_library_metadata(prefs)
    if not cached_metadata:
        return ''
    try:
        import json
        books = json.loads(cached_metadata)
        if not isinstance(books, list):
            return cached_metadata
        tsv = format_books_compact_tsv(books)
        if tsv:
            prefs['library_cached_tsv'] = tsv
        return tsv
    except (json.JSONDecodeError, TypeError):
        return cached_metadata


def update_library_metadata(db, prefs, force=False):
    """
    提取图书馆元数据（仅书名和作者名），索引全库。

    未 force 且 id 指纹未变、JSON/TSV 缓存齐全时跳过全量重建。
    
    :param db: Calibre数据库对象
    :param prefs: 插件配置对象
    :param force: True 时强制重建（手动 Update Library Data）
    :return: (成功标志, 书籍数量, 错误信息)
    """
    try:
        import json
        from datetime import datetime

        book_ids = _get_library_book_ids(db)
        fingerprint, book_count = compute_library_ids_fingerprint(book_ids)
        cached_fp = prefs.get('library_ids_fingerprint', '') or ''
        cached_json = prefs.get('library_cached_metadata', '') or ''
        cached_tsv = prefs.get('library_cached_tsv', '') or ''

        if (
            not force
            and cached_fp
            and cached_fp == fingerprint
            and cached_json.strip()
            and cached_tsv.strip()
        ):
            logger.info(
                "Library metadata cache is fresh (%s books), skip rebuild",
                book_count,
            )
            try:
                from .statistics_widget import update_book_count
                update_book_count(prefs, book_count)
            except Exception as stat_error:
                logger.warning(f"Failed to update book count in statistics: {stat_error}")
            return True, book_count, None
        
        books = []
        for book_id in book_ids:
            try:
                # 使用 index_is_id=True 确保正确获取元数据
                mi = db.get_metadata(book_id, index_is_id=True)
                if mi:
                    books.append({
                        'id': book_id,
                        'title': mi.title or 'Unknown',
                        'authors': ', '.join(mi.authors or ['Unknown'])
                    })
                else:
                    logger.warning(f"Book {book_id} metadata is None, skipping")
            except Exception as e:
                logger.warning(f"Failed to get metadata for book {book_id}: {e}")
                continue
        
        compact_tsv = format_books_compact_tsv(books)
        prefs['library_cached_metadata'] = json.dumps(books, ensure_ascii=False)
        prefs['library_cached_tsv'] = compact_tsv
        prefs['library_ids_fingerprint'] = fingerprint
        prefs['library_last_update'] = datetime.now().isoformat()
        
        # 更新统计页面的书籍数量
        try:
            from .statistics_widget import update_book_count
            update_book_count(prefs, len(books))
        except Exception as stat_error:
            logger.warning(f"Failed to update book count in statistics: {stat_error}")
        
        logger.info(f"Successfully updated library metadata: {len(books)} books")
        return True, len(books), None
        
    except Exception as e:
        error_msg = f"Failed to update library metadata: {str(e)}"
        logger.error(error_msg)
        return False, 0, error_msg

def get_library_metadata(prefs):
    """
    获取缓存的图书馆元数据
    
    :param prefs: 插件配置对象
    :return: 元数据JSON字符串，如果未缓存则返回None
    """
    return prefs.get('library_cached_metadata', None)

def get_library_last_update(prefs):
    """
    获取图书馆元数据最后更新时间
    
    :param prefs: 插件配置对象
    :return: ISO格式的时间字符串，如果未更新过则返回None
    """
    return prefs.get('library_last_update', None)

def is_library_chat_enabled(prefs):
    """
    检查是否启用了图书馆对话功能
    
    :param prefs: 插件配置对象
    :return: True/False
    """
    return prefs.get('library_chat_enabled', False)

def build_library_prompt(user_query, prefs, i18n=None):
    """
    构建包含图书馆元数据的AI提示词
    
    :param user_query: 用户查询
    :param prefs: 插件配置对象
    :param i18n: i18n翻译字典（可选）
    :return: 完整的提示词
    """
    cached_metadata = get_library_metadata(prefs)
    
    if not cached_metadata:
        return user_query
    
    # 默认英文模板
    default_template = (
        'You have access to the user\'s book library. Here are all the books: {metadata} '
        'User query: {query} '
        'Find matching books and return them in this format (**IMPORTANT**: Use HTML link format so users can click book titles to open them directly): '
        '- <a href="calibre://book/BOOK_ID">Book Title</a> - Author Name '
        'Example: - <a href="calibre://book/123">Learning Python</a> - Mark Lutz '
        '- <a href="calibre://book/456">Machine Learning in Action</a> - Peter Harrington '
        'Note: Some authors may be listed as "unknown". This is normal data. '
        'Only return books that match the query. Maximum 5 results. '
        'Output ONLY the bullet list — no analysis, no chain-of-thought, no preamble.'
    )
    
    # 从i18n获取模板，如果没有则使用默认模板
    if i18n:
        template = i18n.get('library_prompt_template', default_template)
    else:
        template = default_template
    
    # 使用紧凑 TSV 格式填充模板（id|title|authors 每行一本）
    compact_metadata = format_library_metadata_for_prompt(prefs)
    if not compact_metadata:
        compact_metadata = cached_metadata

    try:
        from .prompt_limits import get_max_prompt_length
    except ImportError:
        from prompt_limits import get_max_prompt_length

    compact_lines = split_compact_tsv_lines(compact_metadata)
    total_books = len(compact_lines)
    max_length = get_max_prompt_length(True, prefs)
    overhead = len(template.format(metadata='', query=user_query)) + 200

    included_lines = []
    current_len = 0
    for line in compact_lines:
        add_len = len(line) + (1 if included_lines else 0)
        if included_lines and current_len + add_len > max_length - overhead:
            break
        included_lines.append(line)
        current_len += add_len

    metadata_for_prompt = '\n'.join(included_lines)
    if total_books and len(included_lines) < total_books:
        note = (
            'Note: Only the first {included} of {total} indexed books are included due to the prompt limit. '
            'Results may be incomplete for very large libraries.'
        )
        if i18n:
            note = i18n.get('library_metadata_truncation_note', note).format(
                included=len(included_lines), total=total_books,
            )
        else:
            note = note.format(included=len(included_lines), total=total_books)
        metadata_for_prompt = f"{metadata_for_prompt}\n\n{note}"

    prompt = template.format(metadata=metadata_for_prompt, query=user_query)
    # Keep all locales from drifting into long CoT answers (esp. reasoning models).
    # The extra sentence must follow the UI language; English/zh/zht templates
    # already include their own wording and must not get a second copy.
    prompt = _append_library_output_rule(prompt, i18n)
    return prompt


_LIBRARY_OUTPUT_ONLY_RULE = (
    'IMPORTANT: Output ONLY the matching books as the HTML bullet list above. '
    'Do not write analysis, reasoning, or any text outside that list.'
)
# Templates that already state this rule in their own wording.
_LIBRARY_OUTPUT_ONLY_MARKERS = ('Output ONLY', '只输出', '只回傳')


def _append_library_output_rule(prompt, i18n):
    rule = _LIBRARY_OUTPUT_ONLY_RULE
    if i18n:
        rule = i18n.get('library_output_only_rule', _LIBRARY_OUTPUT_ONLY_RULE)
    rule = (rule or '').strip()
    if not rule:
        return prompt
    if rule in prompt or any(marker in prompt for marker in _LIBRARY_OUTPUT_ONLY_MARKERS):
        return prompt
    return prompt + '\n\n' + rule
