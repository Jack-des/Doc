#!/usr/bin/env python
# License: GPLv3 Copyright: 2026, Comfy.n
"""Runtime patches for calibre's AI backends, merged from the former
standalone AI Tweaks plugin. Injects web search options and custom extra
body JSON into OpenAI compatible requests, fixes free model routing, and
logs wire traffic. All configuration controls remain in this plugin's own
dialog.

Guard attributes use the '_ai_config_' prefix (distinct from the old
plugin's '_ai_tweaks_' prefix) so that if the retired AI Tweaks plugin is
still installed, both patch layers coexist instead of one silently
disabling the other.
"""

from __future__ import annotations

import datetime
import json
import sys
import threading
from copy import deepcopy
from typing import Any, Iterator, Sequence
from urllib.error import HTTPError, URLError
from urllib.request import Request

from calibre.constants import numeric_version as calibre_version
from calibre.utils.localization import _
from calibre.utils.logging import prints

# Thread-safe in-memory ring buffer for inspecting wire traffic
_traffic_lock = threading.Lock()
_traffic_history: list[dict[str, Any]] = []
MAX_TRAFFIC_ENTRIES = 50


def record_traffic_event(event: dict[str, Any]) -> str:
    """Record an outgoing request event and return its unique ID."""
    with _traffic_lock:
        event_id = event.get('id') or f"req_{len(_traffic_history)+1}_{int(datetime.datetime.now().timestamp()*1000)}"
        event['id'] = event_id
        if 'status' not in event:
            event['status'] = 'Dispatched'
        _traffic_history.insert(0, event)
        while len(_traffic_history) > MAX_TRAFFIC_ENTRIES:
            _traffic_history.pop()
        return event_id


def update_traffic_event(event_id: str, updates: dict[str, Any]) -> None:
    """Update an existing traffic event with response status, error details, or payload chunks."""
    with _traffic_lock:
        for ev in _traffic_history:
            if ev.get('id') == event_id:
                ev.update(updates)
                break


def get_traffic_history() -> list[dict[str, Any]]:
    with _traffic_lock:
        return deepcopy(_traffic_history)


def clear_traffic_history() -> None:
    with _traffic_lock:
        _traffic_history.clear()


def mask_auth_header(val: str) -> str:
    if not val:
        return ''
    val_str = str(val).strip()
    if val_str.lower().startswith('bearer '):
        token = val_str[7:].strip()
        if len(token) > 10:
            return f'Bearer {token[:4]}...{token[-4:]}'
        return 'Bearer ****'
    if len(val_str) > 10:
        return f'{val_str[:4]}...{val_str[-4:]}'
    return '****'


def tool_call_description(chunk: dict[str, Any]) -> str:
    """Describe an OpenAI-style client tool call in a streamed chunk."""
    names = []
    for choice in chunk.get('choices') or () if isinstance(chunk, dict) else ():
        delta = choice.get('delta') or choice.get('message') or {}
        calls = delta.get('tool_calls') or ()
        if delta.get('function_call'):
            calls = tuple(calls) + ({'function': delta['function_call']},)
        for call in calls:
            function = call.get('function') or {}
            name = str(function.get('name') or call.get('name') or 'unknown tool')
            if name not in names:
                names.append(name)
        if choice.get('finish_reason') in {'tool_calls', 'function_call'} and not names:
            names.append('unknown tool')
    return ', '.join(names)


def is_probable_tool_call_text(text: str) -> bool:
    """Detect provider pseudo-tool output without flagging ordinary JSON answers."""
    compact = ''.join(str(text or '').lower().split())
    return any(marker in compact for marker in (
        'tool-websearch{', 'tool-web_search{', 'tool:websearch{',
        '"name":"web_search"', '"name":"websearch"',
    ))


def apply_ai_tweaks_patch() -> bool:
    """Apply profile routing and network traffic diagnostics to calibre AI."""
    patched_anything = False

    try:
        from calibre_plugins.ai_config.tweaks_config import (
            active_ai_profile,
            is_log_payloads_enabled,
            profile_plain_api_key,
            save_active_profile_from_native,
        )

        # 1. Patch OpenAI-compatible backend if available in the running calibre instance
        try:
            import calibre.ai.openai_compatible.backend as oe_backend

            if not getattr(oe_backend, '_ai_config_pref_patched', False):
                orig_pref = oe_backend.pref

                def patched_pref(key: str, defval: Any = None) -> Any:
                    try:
                        profile = active_ai_profile()
                        if profile.get('backend') in {'openai_compatible', 'nvidia_api'}:
                            if key in {'api_url', 'api_key', 'headers', 'text_model', 'temperature', 'timeout'}:
                                value = profile.get(key)
                                if value not in (None, ''):
                                    return value
                    except Exception:
                        pass
                    return orig_pref(key, defval)

                oe_backend.pref = patched_pref
                oe_backend._ai_config_pref_patched = True
                oe_backend._ai_config_orig_pref = orig_pref
                patched_anything = True

            # Patch chat_request on OpenAI-compatible backend module
            if not getattr(oe_backend, '_ai_config_patched', False):
                orig_chat_request = oe_backend.chat_request

                def patched_chat_request(
                    data: dict[str, Any],
                    url_override: str | None = None,
                    use_api_key: str | None = None,
                    use_headers: Sequence[tuple[str, str]] | None = None,
                ) -> Request:
                    injected_keys = []
                    profile = active_ai_profile()
                    profile_backend = profile.get('backend')
                    profile_url = str(profile.get('api_url') or '').strip()
                    profile_key = str(profile.get('api_key') or '').strip()
                    profile_headers = tuple(profile.get('headers') or ())
                    if isinstance(data, dict):
                        if profile_backend in {'openai_compatible', 'nvidia_api'}:
                            if profile_url:
                                url_override = profile_url
                                injected_keys.append('profile.api_url')
                            use_api_key = profile_key
                            injected_keys.append('profile.api_key')
                            if profile_headers:
                                use_headers = profile_headers
                                injected_keys.append('profile.headers')
                            if profile.get('text_model'):
                                data['model'] = profile['text_model']
                                injected_keys.append('profile.text_model')
                            if 'temperature' in profile:
                                data['temperature'] = profile['temperature']
                                injected_keys.append('profile.temperature')
                            if profile_backend == 'nvidia_api':
                                data.setdefault('max_tokens', 4096)
                                injected_keys.append('nvidia.max_tokens')

                        if is_log_payloads_enabled():
                            try:
                                prints(f'[AI Config] Outgoing OpenAI-compatible request payload:\n{json.dumps(data, indent=2)}')
                            except Exception:
                                pass

                    req: Request = orig_chat_request(
                        data,
                        url_override=url_override,
                        use_api_key=use_api_key,
                        use_headers=use_headers,
                    )

                    try:
                        target_url = req.full_url if hasattr(req, 'full_url') else str(req)
                        raw_body = req.data.decode('utf-8', errors='replace') if req.data else ''
                        headers_clean = {}
                        for h_k, h_v in req.header_items():
                            if h_k.lower() in ('authorization', 'x-goog-api-key', 'api-key'):
                                headers_clean[h_k] = mask_auth_header(h_v)
                            else:
                                headers_clean[h_k] = h_v

                        event = {
                            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'provider': profile.get('name') or 'OpenAI compatible',
                            'url': target_url,
                            'model': data.get('model', '') if isinstance(data, dict) else '',
                            'injected_keys': injected_keys,
                            'payload_dict': deepcopy(data) if isinstance(data, dict) else {},
                            'payload_json': raw_body,
                            'headers': headers_clean,
                            'byte_count': len(req.data) if req.data else 0,
                            'status': 'Sending...',
                            'response_preview': '',
                        }
                        event_id = record_traffic_event(event)
                        setattr(req, '_ai_config_event_id', event_id)
                    except Exception as e:
                        prints(f'[AI Config] Error recording traffic event: {e}')

                    return req

                oe_backend.chat_request = patched_chat_request
                oe_backend._ai_config_patched = True
                oe_backend._ai_config_orig_chat_request = orig_chat_request
                patched_anything = True

            # Make a configured private profile usable even when calibre's native
            # OpenAI-compatible form has never been completed.
            if not getattr(oe_backend, '_ai_config_ready_patched', False):
                orig_ready = oe_backend.is_ready_for_use

                def patched_is_ready_for_use() -> bool:
                    try:
                        profile = active_ai_profile()
                        if profile.get('backend') not in {'openai_compatible', 'nvidia_api'}:
                            return bool(orig_ready())
                        required = bool(profile.get('api_url') and profile.get('text_model'))
                        if profile.get('backend') == 'nvidia_api':
                            required = required and bool(profile.get('api_key'))
                        return required
                    except Exception:
                        return bool(orig_ready())

                oe_backend.is_ready_for_use = patched_is_ready_for_use
                oe_backend._ai_config_ready_patched = True
                oe_backend._ai_config_orig_is_ready_for_use = orig_ready
                patched_anything = True
        except Exception:
            pass

        # Mirror the active plugin profile into calibre's native settings forms
        try:
            import calibre.ai.config as ai_config_module
            try:
                import calibre.ai.openai_compatible.config as oe_config_module
                if not getattr(oe_config_module, '_ai_config_native_widget_patched', False):
                    orig_native_init = oe_config_module.ConfigWidget.__init__
                    orig_native_save = oe_config_module.ConfigWidget.save_settings

                    def native_init(self, parent=None):
                        orig_native_init(self, parent)
                        try:
                            profile = active_ai_profile()
                            if profile.get('backend') != 'openai_compatible':
                                return
                            self.api_url_edit.setText(str(profile.get('api_url') or ''))
                            self.api_key_edit.setText(profile_plain_api_key(profile))
                            self.headers_edit.setPlainText(
                                '\n'.join(f'{key}: {value}' for key, value in profile.get('headers') or ())
                            )
                            self.timeout_sb.setValue(int(profile.get('timeout', 120)))
                            self.temp_sb.setValue(float(profile.get('temperature', 0.7)))
                            model = str(profile.get('text_model') or '')
                            if model:
                                if self.model_combo.findText(model) < 0:
                                    self.model_combo.addItem(model)
                                self.model_combo.setCurrentText(model)
                        except Exception:
                            pass

                    def native_save(self):
                        orig_native_save(self)
                        try:
                            profile = active_ai_profile()
                            if profile.get('backend') == 'openai_compatible':
                                save_active_profile_from_native(self.settings)
                        except Exception:
                            pass

                    oe_config_module.ConfigWidget.__init__ = native_init
                    oe_config_module.ConfigWidget.save_settings = native_save
                    oe_config_module._ai_config_native_widget_patched = True
                    patched_anything = True
            except Exception:
                pass

            try:
                import calibre.ai.anthropic.config as anthropic_config_module
                if not getattr(anthropic_config_module, '_ai_config_native_widget_patched', False):
                    orig_anthropic_save = anthropic_config_module.ConfigWidget.save_settings

                    def anthropic_native_save(self):
                        orig_anthropic_save(self)
                        try:
                            profile = active_ai_profile()
                            if profile.get('backend') == 'anthropic_compatible':
                                save_active_profile_from_native(self.settings, 'anthropic_compatible')
                        except Exception:
                            pass

                    anthropic_config_module.ConfigWidget.save_settings = anthropic_native_save
                    anthropic_config_module._ai_config_native_widget_patched = True
                    patched_anything = True
            except Exception:
                pass

            if not getattr(ai_config_module.ConfigureAI, '_ai_config_provider_patched', False):
                orig_configure_init = ai_config_module.ConfigureAI.__init__

                def configure_init(self, *args, **kwargs):
                    orig_configure_init(self, *args, **kwargs)
                    try:
                        profile = active_ai_profile()
                        if profile.get('backend') == 'openai_compatible' and hasattr(self, 'provider_combo'):
                            from calibre.ai.prefs import prefs as ai_prefs
                            if ai_prefs()['purpose_map'].get(getattr(self.purpose, 'purpose', '')):
                                return
                            try:
                                from calibre.ai.openai_compatible import OpenAICompatible
                                prov_name = OpenAICompatible.name
                            except Exception:
                                prov_name = 'OpenAI compatible'
                            index = self.provider_combo.findText(prov_name)
                            if index >= 0:
                                self.provider_combo.setCurrentIndex(index)
                    except Exception:
                        pass

                ai_config_module.ConfigureAI.__init__ = configure_init
                ai_config_module.ConfigureAI._ai_config_provider_patched = True
                patched_anything = True
        except Exception:
            pass

        # 2. Patch read_streaming_response in calibre.ai.utils to log ALL providers and captures HTTP failures
        try:
            import calibre.ai.utils as ai_utils
            orig_read_streaming = getattr(
                ai_utils, '_ai_config_orig_read_streaming_response',
                ai_utils.read_streaming_response,
            )

            def patched_read_streaming_response(
                rq: Request,
                provider_name: str = 'AI provider',
                timeout: int = 120,
            ) -> Iterator[dict[str, Any]]:
                event_id = getattr(rq, '_ai_config_event_id', None)
                if not event_id:
                    try:
                        target_url = rq.full_url if hasattr(rq, 'full_url') else str(rq)
                        raw_body = rq.data.decode('utf-8', errors='replace') if rq.data else ''
                        headers_clean = {}
                        for h_k, h_v in rq.header_items():
                            if h_k.lower() in ('authorization', 'x-goog-api-key', 'api-key'):
                                headers_clean[h_k] = mask_auth_header(h_v)
                            else:
                                headers_clean[h_k] = h_v

                        parsed_dict = {}
                        try:
                            parsed_dict = json.loads(raw_body) if raw_body else {}
                        except Exception:
                            pass

                        event = {
                            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'provider': provider_name,
                            'url': target_url,
                            'model': parsed_dict.get('model', target_url.split('/')[-1].split('?')[0]),
                            'injected_keys': [],
                            'payload_dict': parsed_dict,
                            'payload_json': raw_body,
                            'headers': headers_clean,
                            'byte_count': len(rq.data) if rq.data else 0,
                            'status': 'Connecting...',
                            'response_preview': '',
                        }
                        event_id = record_traffic_event(event)
                        setattr(rq, '_ai_config_event_id', event_id)
                    except Exception:
                        pass

                try:
                    accumulated_chunks = 0
                    tool_calls = []
                    text_fragments = []
                    response_chunks: list[dict[str, Any]] = []
                    start_time = datetime.datetime.now()

                    for chunk in orig_read_streaming(rq, provider_name=provider_name, timeout=timeout):
                        accumulated_chunks += 1
                        if isinstance(chunk, dict):
                            response_chunks.append(deepcopy(chunk))
                        if description := tool_call_description(chunk):
                            for name in description.split(', '):
                                if name not in tool_calls:
                                    tool_calls.append(name)
                        try:
                            # OpenAI style chunks
                            for choice in chunk.get('choices') or ():
                                content = (choice.get('delta') or choice.get('message') or {}).get('content')
                                if isinstance(content, str):
                                    text_fragments.append(content)
                            # Anthropic style chunks
                            if isinstance(chunk, dict):
                                delta_dict = chunk.get('delta')
                                if isinstance(delta_dict, dict) and isinstance(delta_dict.get('text'), str):
                                    text_fragments.append(delta_dict['text'])
                                cb_dict = chunk.get('content_block')
                                if isinstance(cb_dict, dict) and isinstance(cb_dict.get('text'), str):
                                    text_fragments.append(cb_dict['text'])
                        except Exception:
                            pass
                        if accumulated_chunks == 1 and event_id:
                            update_traffic_event(event_id, {'status': 'HTTP 200 OK (Streaming)'})
                        yield chunk

                    duration = (datetime.datetime.now() - start_time).total_seconds()
                    full_text = ''.join(text_fragments)

                    if event_id:
                        pseudo_tool = is_probable_tool_call_text(full_text)
                        if tool_calls or pseudo_tool:
                            names = ', '.join(tool_calls) if tool_calls else 'web_search'
                            update_traffic_event(event_id, {
                                'status': 'HTTP 200 — unhandled tool call',
                                'duration_sec': round(duration, 2),
                                'chunk_count': accumulated_chunks,
                                'response_preview': (
                                    f'Provider requested client-executed tool(s): {names}.\n'
                                    'The calibre OpenAI-compatible backend cannot execute tool calls.\n'
                                    'Use a provider/model with server-managed search, or disable this search payload.'
                                ),
                                'response_text': full_text,
                                'response_json': json.dumps(response_chunks, indent=2),
                            })
                        else:
                            summary_line = f'Completed in {duration:.2f}s ({accumulated_chunks} chunks, {len(full_text)} characters).'
                            preview = f'{summary_line}\n\n{full_text}' if full_text.strip() else summary_line
                            update_traffic_event(event_id, {
                                'status': 'HTTP 200 OK (Complete)',
                                'duration_sec': round(duration, 2),
                                'chunk_count': accumulated_chunks,
                                'response_preview': preview,
                                'response_text': full_text,
                                'response_json': json.dumps(response_chunks, indent=2),
                            })

                except HTTPError as e:
                    err_body = ''
                    try:
                        err_body = e.fp.read().decode('utf-8', errors='replace')
                    except Exception:
                        pass
                    if event_id:
                        status_msg = f'HTTP Error {e.code}: {e.reason}'
                        try:
                            err_parsed = json.loads(err_body)
                            formatted_err = json.dumps(err_parsed, indent=2)
                        except Exception:
                            formatted_err = err_body
                        update_traffic_event(event_id, {
                            'status': status_msg,
                            'response_preview': formatted_err or f'HTTP Error {e.code}: {e.reason}',
                            'response_json': formatted_err or f'HTTP Error {e.code}: {e.reason}',
                        })
                    raise

                except URLError as e:
                    if event_id:
                        update_traffic_event(event_id, {
                            'status': f'Network Error: {e.reason}',
                            'response_preview': str(e),
                            'response_json': str(e),
                        })
                    raise

                except Exception as e:
                    if event_id:
                        update_traffic_event(event_id, {
                            'status': f'Error: {type(e).__name__}',
                            'response_preview': str(e),
                            'response_json': str(e),
                        })
                    raise

            ai_utils.read_streaming_response = patched_read_streaming_response
            ai_utils._ai_config_orig_read_streaming_response = orig_read_streaming
            ai_utils._ai_config_streaming_patched = True
            # Several calibre backends imported this function directly before
            # the plugin patch ran. Update those module-local aliases too.
            for module in tuple(sys.modules.values()):
                try:
                    if getattr(module, 'read_streaming_response', None) is orig_read_streaming:
                        module.read_streaming_response = patched_read_streaming_response
                except Exception:
                    pass
            patched_anything = True
        except Exception:
            pass

        # 3. Patch GoogleAI backend to route to working free-tier models (Gemini 2.5 Flash) with Search Grounding
        try:
            import calibre.ai.google.backend as g_backend
            if not getattr(g_backend, '_ai_config_google_patched', False):
                orig_gemini_models = g_backend.gemini_models

                def patched_gemini_models(version: float = 0):
                    models = {}
                    for m in g_backend.get_available_models().values():
                        if m.family and 'preview' not in m.name_parts:
                            fm = models.setdefault(m.family, {})
                            fm.setdefault(m.family_version, []).append(m)

                    gemini = models.get('gemini', {})
                    if not gemini:
                        return orig_gemini_models(version)

                    # Prefer version 2.5 (active free tier quota with search grounding) over 3.7 (which lacks free quota)
                    if not version:
                        target_ver = 2.5 if 2.5 in gemini else max(gemini)
                    else:
                        target_ver = version

                    ans = {}
                    for m in gemini.get(target_ver, []):
                        if m.name_parts[-1] == 'pro':
                            ans['high'] = m
                        elif m.name_parts[-1] == 'flash':
                            ans['medium'] = m
                        elif m.name_parts[-2:] == ('flash', 'lite'):
                            ans['low'] = m
                    return ans or orig_gemini_models(version)

                g_backend.gemini_models = patched_gemini_models
                g_backend._ai_config_google_patched = True
                patched_anything = True
        except Exception:
            pass

    except Exception as e:
        prints(f'[AI Config] Error applying monkey-patches: {e}')
        import traceback
        traceback.print_exc()
        return False

    return True
