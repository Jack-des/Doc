#!/usr/bin/env python
# License: GPLv3 Copyright: 2026, Comfy.n
"""Configuration widget, prefs helpers and settings dialog for the AI Config
plugin. Contains named AI profiles, custom request parameters, prompt testing,
and diagnostic traffic logging.
"""

from __future__ import annotations

import json
import os
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

from qt.core import (
    QApplication,
    QCheckBox,
    QColor,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QEvent,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QIcon,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QObject,
    QPalette,
    QPlainTextEdit,
    QPushButton,
    QPixmap,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTextEdit,
    QThread,
    QTimer,
    Qt,
    QVBoxLayout,
    QWidget,
    pyqtSignal,
)

from calibre.constants import numeric_version
from calibre.gui2 import error_dialog, info_dialog, open_url
from calibre.utils.config import JSONConfig, config_dir
from calibre.utils.localization import _

try:
    load_translations()
except NameError:
    pass

try:
    _
except NameError:
    def _(msg):
        return msg

# Preferences configuration stored in Calibre's plugins configuration folder.
# Single shared instance: action.py imports this same object so both modules
# always write the same in-memory dict (JSONConfig instances do NOT share
# state between each other).
plugin_prefs = JSONConfig('plugins/ai_config')

KEY_ENFORCE_WEB_SEARCH = 'enforce_web_search'
KEY_WEB_SEARCH_OPTIONS = 'web_search_options_json'
KEY_EXTRA_BODY_ENABLED = 'extra_body_enabled'
KEY_EXTRA_BODY_JSON = 'extra_body_json'
KEY_LOG_PAYLOADS = 'log_payloads'
KEY_HIDE_API_KEYS = 'hide_api_keys'
KEY_TWEAKS_MIGRATED = 'tweaks_prefs_migrated'
KEY_MODEL_DISCOVERY_ENDPOINT_HISTORY = 'model_discovery_endpoint_history'
KEY_SELECTED_ACTION = 'selected_action'
DEFAULT_SELECTED_ACTION = 'ai_settings_viewer'

DEFAULT_WEB_SEARCH_OPTIONS = '{}'
DEFAULT_EXTRA_BODY_JSON = '{\n  "web_search_options": {}\n}'

# Initialize defaults if not present
plugin_prefs.defaults[KEY_ENFORCE_WEB_SEARCH] = True
plugin_prefs.defaults[KEY_WEB_SEARCH_OPTIONS] = DEFAULT_WEB_SEARCH_OPTIONS
plugin_prefs.defaults[KEY_EXTRA_BODY_ENABLED] = False
plugin_prefs.defaults[KEY_EXTRA_BODY_JSON] = DEFAULT_EXTRA_BODY_JSON
plugin_prefs.defaults[KEY_LOG_PAYLOADS] = False
plugin_prefs.defaults[KEY_HIDE_API_KEYS] = False
plugin_prefs.defaults[KEY_TWEAKS_MIGRATED] = False
plugin_prefs.defaults[KEY_MODEL_DISCOVERY_ENDPOINT_HISTORY] = []
plugin_prefs.defaults[KEY_SELECTED_ACTION] = DEFAULT_SELECTED_ACTION

CYOA_MIN_CALIBRE_VERSION = (9, 15, 0)


def is_running_from_source() -> bool:
    """Return True if calibre is running from source or in develop mode."""
    try:
        from calibre.constants import isfrozen, is_running_from_develop
        return not isfrozen or bool(is_running_from_develop)
    except Exception:
        return False


def cyoa_disabled_tooltip() -> str:
    return _('Upcoming feature.\nRequires the next calibre release (9.15 or newer).')


def cyoa_menu_enabled() -> bool:
    return numeric_version >= CYOA_MIN_CALIBRE_VERSION or is_running_from_source()


def toolbar_action_choices() -> list[dict[str, Any]]:
    choices = [
        {
            'key': 'ai_settings_viewer',
            'label': _('E-book viewer'),
            'icon': 'images/iconplugin2',
        },
        {
            'key': 'ai_settings_library',
            'label': _('Main'),
            'icon': 'images/iconplugin',
        },
    ]
    if numeric_version >= (9, 14, 0):
        choices.append({
            'key': 'cover_generation_settings',
            'label': _('Cover generation'),
            'icon': 'images/iconplugin3',
        })
    choices.append({
        'key': 'cyoa_settings',
        'label': _('CYOA settings'),
        'icon': 'images/iconplugin4',
        'enabled': cyoa_menu_enabled(),
        'disabled_reason': cyoa_disabled_tooltip(),
    })
    return choices


def normalise_toolbar_action_key(key: str | None) -> str:
    for choice in toolbar_action_choices():
        if choice['key'] == key and choice.get('enabled', True):
            return choice['key']
    return DEFAULT_SELECTED_ACTION


# Protected profile state is kept in calibre's ai.json, not in the plugin's
# ordinary namespace, because profiles may contain API keys.
AI_PROFILES_KEY = 'ai_config_profiles'
AI_PROFILES_SCHEMA_VERSION = 2
DEFAULT_NVIDIA_API_URL = 'https://integrate.api.nvidia.com'
DEFAULT_NVIDIA_MODEL = 'nvidia/nemotron-3-super-120b-a12b'
try:
    from calibre.ai.openai_compatible import OpenAICompatible
    OPENAI_COMPATIBLE_PROVIDER_NAME = OpenAICompatible.name
    HAS_OPENAI_COMPATIBLE_BACKEND = True
except Exception:
    OPENAI_COMPATIBLE_PROVIDER_NAME = 'OpenAI compatible'
    HAS_OPENAI_COMPATIBLE_BACKEND = False

try:
    from calibre.ai.anthropic import AnthropicAI
    ANTHROPIC_PROVIDER_NAME = AnthropicAI.name
    HAS_ANTHROPIC_BACKEND = True
except Exception:
    ANTHROPIC_PROVIDER_NAME = 'Anthropic'
    HAS_ANTHROPIC_BACKEND = False

SUPPORTED_PROFILE_BACKENDS = {'openai_compatible', 'nvidia_api'}
if HAS_ANTHROPIC_BACKEND:
    SUPPORTED_PROFILE_BACKENDS.add('anthropic_compatible')


def _normalise_profile(profile: dict[str, Any], index: int = 0) -> dict[str, Any]:
    from uuid import uuid4
    backend = str(profile.get('backend') or 'openai_compatible').strip()
    if backend not in SUPPORTED_PROFILE_BACKENDS:
        backend = 'openai_compatible'
    headers = profile.get('headers') or ()
    if isinstance(headers, dict):
        headers = tuple(headers.items())
    clean_headers = []
    for item in headers if isinstance(headers, (list, tuple)) else ():
        if isinstance(item, (list, tuple)) and len(item) == 2:
            key, value = str(item[0]).strip(), str(item[1]).strip()
            if key and value:
                clean_headers.append((key, value))
    try:
        timeout = max(15, min(600, int(profile.get('timeout', 120))))
    except Exception:
        timeout = 120
    try:
        temperature = max(0.0, min(2.0, float(profile.get('temperature', 0.7))))
    except Exception:
        temperature = 0.7
    return {
        'id': str(profile.get('id') or uuid4().hex),
        'name': str(profile.get('name') or '').strip() or f'Profile {index + 1}',
        'backend': backend,
        'api_url': str(profile.get('api_url') or '').strip().rstrip('/'),
        'api_key': str(profile.get('api_key') or '').strip(),
        'headers': tuple(clean_headers),
        'text_model': str(profile.get('text_model') or profile.get('model') or '').strip(),
        'timeout': timeout,
        'temperature': temperature,
        'model_choice_strategy': str(profile.get('model_choice_strategy') or 'medium').strip(),
        'reasoning_strategy': str(profile.get('reasoning_strategy') or 'auto').strip(),
        'allow_web_searches': bool(profile.get('allow_web_searches', False)),
    }


def _initial_profiles() -> tuple[list[dict[str, Any]], str]:
    from calibre.ai.prefs import prefs
    providers = prefs()['providers']
    native_openai = providers.get(OPENAI_COMPATIBLE_PROVIDER_NAME, {})
    if not isinstance(native_openai, dict):
        native_openai = {}
    primary = _normalise_profile({
        'name': 'OpenAI compatible', 'backend': 'openai_compatible',
        'api_url': native_openai.get('api_url', ''), 'api_key': native_openai.get('api_key', ''),
        'headers': native_openai.get('headers', ()), 'text_model': native_openai.get('text_model', ''),
        'timeout': native_openai.get('timeout', 120), 'temperature': native_openai.get('temperature', 0.7),
    })
    nvidia = _normalise_profile({
        'name': 'NVIDIA API', 'backend': 'nvidia_api',
        'api_url': DEFAULT_NVIDIA_API_URL, 'text_model': DEFAULT_NVIDIA_MODEL,
    }, 1)
    profiles = [primary, nvidia]
    if HAS_ANTHROPIC_BACKEND:
        native_anthropic = providers.get(ANTHROPIC_PROVIDER_NAME, {})
        if not isinstance(native_anthropic, dict):
            native_anthropic = {}
        anthropic = _normalise_profile({
            'name': 'Anthropic compatible', 'backend': 'anthropic_compatible',
            'api_url': native_anthropic.get('api_url', ''), 'api_key': native_anthropic.get('api_key', ''),
            'text_model': native_anthropic.get('model', ''),
            'model_choice_strategy': native_anthropic.get('model_choice_strategy', 'medium'),
            'reasoning_strategy': native_anthropic.get('reasoning_strategy', 'auto'),
            'allow_web_searches': native_anthropic.get('allow_web_searches', False),
        }, 2)
        profiles.append(anthropic)
    return profiles, primary['id']


def _write_profiles(profiles: list[dict[str, Any]], active_id: str) -> None:
    from copy import deepcopy
    from calibre.ai.prefs import prefs
    payload = {
        'schema_version': AI_PROFILES_SCHEMA_VERSION,
        'active_id': active_id,
        'profiles': [deepcopy(_normalise_profile(item, index)) for index, item in enumerate(profiles)],
    }
    p = prefs()
    p[AI_PROFILES_KEY] = payload
    p.set(AI_PROFILES_KEY, payload)
    _mirror_active_profile_to_native(payload)


def _mirror_active_profile_to_native(payload: dict[str, Any]) -> None:
    """Push the active profile into calibre's native provider preferences.

    OpenAI-compatible and NVIDIA profiles use calibre's OpenAI-compatible backend;
    Anthropic-compatible profiles use the native Anthropic Messages backend. The
    real prefs are updated so calibre's own settings dialogs and purpose routing
    stay consistent with this plugin.
    """
    try:
        from calibre.ai import AICapabilities
        from calibre.ai.prefs import prefs, set_prefs_for_provider

        active_id = str(payload.get('active_id') or '')
        profile = next(
            (item for item in payload.get('profiles') or () if item.get('id') == active_id),
            None,
        )
        if not profile:
            return
        backend = profile.get('backend')
        api_url = str(profile.get('api_url') or '').strip()
        text_model = str(profile.get('text_model') or '').strip()
        if backend in {'openai_compatible', 'nvidia_api'}:
            if not api_url or not text_model:
                # The Chat Completions transport needs both an endpoint and model.
                return
            native = {
                'api_url': api_url,
                'api_key': str(profile.get('api_key') or ''),
                'text_model': text_model,
                'timeout': int(profile.get('timeout', 120)),
                'temperature': float(profile.get('temperature', 0.7)),
            }
            headers = tuple(profile.get('headers') or ())
            if headers:
                native['headers'] = headers
            provider_name = OPENAI_COMPATIBLE_PROVIDER_NAME
        elif backend == 'anthropic_compatible' and HAS_ANTHROPIC_BACKEND:
            if not profile.get('api_key'):
                # Native Anthropic requires a key, but an empty URL means the
                # official API and an empty model means automatic selection.
                return
            native = {
                'api_url': api_url,
                'api_key': str(profile.get('api_key') or ''),
                'model': text_model,
                'model_choice_strategy': str(profile.get('model_choice_strategy') or 'medium'),
                'reasoning_strategy': str(profile.get('reasoning_strategy') or 'auto'),
                'allow_web_searches': bool(profile.get('allow_web_searches', False)),
            }
            provider_name = ANTHROPIC_PROVIDER_NAME
        else:
            return

        set_prefs_for_provider(provider_name, native)
        p = prefs()
        purpose_map = dict(p['purpose_map'])
        purpose_map[AICapabilities.text_to_text.purpose] = provider_name
        p.set('purpose_map', purpose_map)
    except Exception:
        # Mirroring is a convenience; never block saving the plugin's own profiles.
        pass


def get_ai_profiles() -> tuple[list[dict[str, Any]], str]:
    from calibre.ai.prefs import prefs
    raw = prefs().get(AI_PROFILES_KEY, {})
    raw_profiles = raw.get('profiles', []) if isinstance(raw, dict) else []
    active_id = str(raw.get('active_id') or '').strip() if isinstance(raw, dict) else ''
    schema_version = int(raw.get('schema_version') or 1) if isinstance(raw, dict) else 1
    profiles = [_normalise_profile(item, index) for index, item in enumerate(raw_profiles) if isinstance(item, dict)]
    if not profiles:
        profiles, active_id = _initial_profiles()
        _write_profiles(profiles, active_id)
    else:
        changed = False
        if HAS_ANTHROPIC_BACKEND and schema_version < AI_PROFILES_SCHEMA_VERSION and not any(item['backend'] == 'anthropic_compatible' for item in profiles):
            initial_profiles, _initial_id = _initial_profiles()
            for item in initial_profiles:
                if item['backend'] == 'anthropic_compatible':
                    profiles.append(item)
                    changed = True
                    break
        if not any(item['id'] == active_id for item in profiles):
            active_id = profiles[0]['id']
            changed = True
        if changed or schema_version < AI_PROFILES_SCHEMA_VERSION:
            _write_profiles(profiles, active_id)
    return profiles, active_id


def save_ai_profiles(profiles: list[dict[str, Any]], active_id: str) -> None:
    clean = [_normalise_profile(item, index) for index, item in enumerate(profiles)]
    if not clean:
        clean, active_id = _initial_profiles()
    if not any(item['id'] == active_id for item in clean):
        active_id = clean[0]['id']
    _write_profiles(clean, active_id)


def active_ai_profile() -> dict[str, Any]:
    profiles, active_id = get_ai_profiles()
    return next((item for item in profiles if item['id'] == active_id), profiles[0])


def profile_plain_api_key(profile: dict[str, Any]) -> str:
    from calibre.ai.prefs import decode_secret
    encoded = str(profile.get('api_key') or '').strip()
    if not encoded:
        return ''
    try:
        return decode_secret(encoded)
    except Exception:
        return encoded


def save_active_profile_from_native(settings: dict[str, Any], provider_name: str = '') -> None:
    profiles, active_id = get_ai_profiles()
    profile = next((item for item in profiles if item['id'] == active_id), None)
    if profile is None:
        return
    if provider_name == 'Anthropic AI' or profile.get('backend') == 'anthropic_compatible':
        if profile.get('backend') != 'anthropic_compatible':
            return
        profile.update({
            'api_url': str(settings.get('api_url') or '').strip().rstrip('/'),
            'api_key': str(settings.get('api_key') or '').strip(),
            'text_model': str(settings.get('model') or '').strip(),
            'model_choice_strategy': str(settings.get('model_choice_strategy') or profile.get('model_choice_strategy', 'medium')),
            'reasoning_strategy': str(settings.get('reasoning_strategy') or profile.get('reasoning_strategy', 'auto')),
            'allow_web_searches': bool(settings.get('allow_web_searches', profile.get('allow_web_searches', False))),
        })
    elif profile.get('backend') == 'openai_compatible':
        profile.update({
            'api_url': str(settings.get('api_url') or '').strip().rstrip('/'),
            'api_key': str(settings.get('api_key') or '').strip(),
            'text_model': str(settings.get('text_model') or '').strip(),
            'timeout': int(settings.get('timeout', profile.get('timeout', 120))),
            'temperature': float(settings.get('temperature', profile.get('temperature', 0.7))),
            'headers': tuple(settings.get('headers') or ()),
        })
    else:
        return
    save_ai_profiles(profiles, active_id)


def set_hide_api_keys(val: bool) -> None:
    plugin_prefs[KEY_HIDE_API_KEYS] = bool(val)


def hide_api_keys() -> bool:
    return bool(plugin_prefs.get(KEY_HIDE_API_KEYS, False))


def migrate_from_ai_tweaks() -> None:
    """One-time import of settings from the retired standalone AI Tweaks
    plugin (namespace 'plugins/ai_tweaks') into this plugin's namespace."""
    if plugin_prefs.get(KEY_TWEAKS_MIGRATED, False):
        return
    try:
        old_file = os.path.join(config_dir, 'plugins', 'ai_tweaks.json')
        if os.path.exists(old_file):
            with open(old_file, 'r', encoding='utf-8') as f:
                old = json.load(f)
            if isinstance(old, dict):
                for key in (
                    KEY_ENFORCE_WEB_SEARCH,
                    KEY_WEB_SEARCH_OPTIONS,
                    KEY_EXTRA_BODY_ENABLED,
                    KEY_EXTRA_BODY_JSON,
                    KEY_LOG_PAYLOADS,
                ):
                    if key in old:
                        plugin_prefs[key] = old[key]
        plugin_prefs[KEY_TWEAKS_MIGRATED] = True
        plugin_prefs.commit()
    except Exception:
        pass


migrate_from_ai_tweaks()


def is_web_search_enforced() -> bool:
    return bool(plugin_prefs.get(KEY_ENFORCE_WEB_SEARCH, True))


def set_web_search_enforced(val: bool) -> None:
    plugin_prefs[KEY_ENFORCE_WEB_SEARCH] = bool(val)


def get_web_search_options_raw() -> str:
    return str(plugin_prefs.get(KEY_WEB_SEARCH_OPTIONS, DEFAULT_WEB_SEARCH_OPTIONS) or DEFAULT_WEB_SEARCH_OPTIONS).strip()


def set_web_search_options_raw(val: str) -> None:
    plugin_prefs[KEY_WEB_SEARCH_OPTIONS] = str(val or '').strip()


def get_web_search_options_dict() -> dict[str, Any]:
    raw = get_web_search_options_raw()
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    return {}


def is_extra_body_enabled() -> bool:
    return bool(plugin_prefs.get(KEY_EXTRA_BODY_ENABLED, False))


def set_extra_body_enabled(val: bool) -> None:
    plugin_prefs[KEY_EXTRA_BODY_ENABLED] = bool(val)


def get_extra_body_raw() -> str:
    return str(plugin_prefs.get(KEY_EXTRA_BODY_JSON, DEFAULT_EXTRA_BODY_JSON) or DEFAULT_EXTRA_BODY_JSON).strip()


def set_extra_body_raw(val: str) -> None:
    plugin_prefs[KEY_EXTRA_BODY_JSON] = str(val or '').strip()


def get_extra_body_dict() -> dict[str, Any]:
    if not is_extra_body_enabled():
        return {}
    raw = get_extra_body_raw()
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    return {}


def is_log_payloads_enabled() -> bool:
    return bool(plugin_prefs.get(KEY_LOG_PAYLOADS, False))


def set_log_payloads_enabled(val: bool) -> None:
    plugin_prefs[KEY_LOG_PAYLOADS] = bool(val)


def _plugin_version_text() -> str:
    try:
        from calibre_plugins.ai_config import AIConfig
        return '.'.join(str(x) for x in AIConfig.version)
    except Exception:
        return '1.1.0'


def _calibre_version_text() -> str:
    try:
        return '.'.join(str(x) for x in tuple(numeric_version[:3]))
    except Exception:
        return '?.?.?'


def _is_dark_theme(widget=None) -> bool:
    try:
        from calibre.gui2 import is_dark_theme
        return bool(is_dark_theme())
    except Exception:
        pass
    try:
        pal = widget.palette() if widget is not None else QApplication.instance().palette()
        return pal.color(pal.ColorRole.WindowText).lightness() > pal.color(pal.ColorRole.Window).lightness()
    except Exception:
        return False


def _theme_tab_colors(widget=None) -> dict[str, str]:
    # Tab styling theme-adaptive for light (orange, matching light icon)
    # and dark palettes (lighter "ouro branco" / white gold, matching dark icon).
    if _is_dark_theme(widget):
        return {
            'accent': '#E8DCAC',
            'accent_hover': '#F5ECC8',
            'tab_selected_text': '#FAF5DC',
            'text': '#DCE3EB',
            'muted': '#98A6B5',
            'border': '#5C5746',
            'tab_bg': '#18212B',
            'tab_hover': '#262720',
            'pane_bg': '#11161D',
        }
    return {
        'accent': '#E67E22',
        'accent_hover': '#F5A623',
        'tab_selected_text': '#C5610D',
        'text': '#24303C',
        'muted': '#6B5D4E',
        'border': '#C4956C',
        'tab_bg': 'transparent',
        'tab_hover': '#FDF2E3',
        'pane_bg': 'transparent',
    }


def goldendict_tab_stylesheet(widget=None, font_size_pt: int = 9) -> str:
    """Return the orange-toned config tab styling shared with Best Sellers.

    Inactive tabs use the full text colour and the selected/hovered tabs are
    outlined in the accent colour, while the pane background stays native.
    """
    c = _theme_tab_colors(widget)
    return (
        'QTabWidget::pane {'
        ' border-top: none;'
        ' margin-left: 8px;'
        ' margin-right: 8px;'
        '}'
        'QTabBar::tab {'
        ' min-width: 96px;'
        ' padding-top: 6px;'
        ' padding-bottom: 6px;'
        ' padding-left: 12px;'
        ' padding-right: 12px;'
        f' font-size: {int(font_size_pt)}pt;'
        ' font-style: normal;'
        ' font-weight: 600;'
        f' background: {c["tab_bg"]};'
        f' color: {c["text"]};'
        f' border-top: 1px solid {c["border"]};'
        f' border-left: 1px solid {c["border"]};'
        f' border-right: 1px solid {c["border"]};'
        ' border-bottom: none;'
        ' margin-right: 3px;'
        ' border-top-left-radius: 7px;'
        ' border-top-right-radius: 7px;'
        '}'
        'QTabBar::tab:selected {'
        ' font-style: normal;'
        ' font-weight: 700;'
        f' color: {c.get("tab_selected_text", c["accent"])};'
        f' border-top: 2px solid {c["accent"]};'
        f' border-left: 2px solid {c["accent"]};'
        f' border-right: 2px solid {c["accent"]};'
        '}'
        'QTabBar::tab:hover:!selected {'
        f' background: {c["tab_hover"]};'
        f' border-top: 1px solid {c["accent_hover"]};'
        f' border-left: 1px solid {c["accent_hover"]};'
        f' border-right: 1px solid {c["accent_hover"]};'
        f' color: {c["text"]};'
        '}'
        'QTabBar::tab:!selected {'
        ' font-style: normal;'
        ' margin-top: 2px;'
        '}'
    )


def ccr_scrollbar_stylesheet() -> str:
    """Return the compact scrollbar styling used by CCR dialogs."""
    return """
QScrollBar::handle {
    border: 1px solid #5B6985;
}
QScrollBar:vertical {
    background: transparent;
    width: 12px;
    margin: 0px;
    padding: 6px 0px;
}
QScrollBar::handle:vertical {
    background: rgba(140, 172, 204, 0.25);
    min-height: 22px;
    border-radius: 4px;
    margin: 4px 0px;
}
QScrollBar::handle:vertical:hover {
    background: rgba(140, 172, 204, 0.45);
}
QScrollBar:horizontal {
    background: transparent;
    height: 12px;
    margin: 0px;
    padding: 0px 6px;
}
QScrollBar::handle:horizontal {
    background: rgba(140, 172, 204, 0.25);
    min-width: 22px;
    border-radius: 4px;
    margin: 0px 4px;
}
QScrollBar::handle:horizontal:hover {
    background: rgba(140, 172, 204, 0.45);
}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical,
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
    background: none;
}
QScrollBar::add-line, QScrollBar::sub-line {
    height: 0px;
    width: 0px;
}
"""


def ccr_combo_stylesheet() -> str:
    """Return the compact combo-box styling used by CCR filter controls."""
    return """
QComboBox {
    border: 1px solid #6B6C6B;
    min-height: 20px;
    padding: 2px 20px 2px 4px;
}
QComboBox:focus {
    border: 1px solid #1976D2;
}
"""


class CtrlWheelZoomFilter(QObject):
    """Event filter that enables Ctrl + Mouse Wheel zooming on targeted widgets."""

    def __init__(self, parent: QObject | None = None, min_pt: float = 7.0, max_pt: float = 20.0, step: float = 1.0):
        super().__init__(parent)
        self.min_pt = float(min_pt)
        self.max_pt = float(max_pt)
        self.step = float(step)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        try:
            if event.type() != QEvent.Type.Wheel:
                return False
            mods = event.modifiers() if hasattr(event, 'modifiers') else QApplication.keyboardModifiers()
            if not (mods & Qt.KeyboardModifier.ControlModifier):
                return False
            delta = event.angleDelta().y()
            if not delta:
                return False
            step = self.step if delta > 0 else -self.step
            target = obj if isinstance(obj, QWidget) else self.parent()
            if target and hasattr(target, 'font') and hasattr(target, 'setFont'):
                f = target.font()
                cur = f.pointSizeF() if hasattr(f, 'pointSizeF') and f.pointSizeF() > 0 else float(f.pointSize())
                new_sz = max(self.min_pt, min(self.max_pt, cur + step))
                if hasattr(f, 'setPointSizeF'):
                    f.setPointSizeF(new_sz)
                else:
                    f.setPointSize(int(round(new_sz)))
                target.setFont(f)
                return True
        except Exception:
            pass
        return False


class TestRequestWorker(QThread):
    """Background worker thread for running live AI test requests without freezing the Qt GUI."""
    chunk_received = pyqtSignal(str)
    status_updated = pyqtSignal(str)
    finished_result = pyqtSignal(bool, str)

    def __init__(self, prompt: str, profile: dict[str, Any], parent: QObject | None = None):
        super().__init__(parent)
        self.prompt = prompt
        self.profile = profile
        self._is_aborted = False

    def abort(self) -> None:
        self._is_aborted = True

    def run(self) -> None:
        try:
            from calibre.ai import ChatMessage, ChatMessageType
            from calibre.ai.utils import plugin_for_name
            from calibre_plugins.ai_config.tweaks import apply_ai_tweaks_patch, is_probable_tool_call_text

            apply_ai_tweaks_patch()
            profile = self.profile
            profile_name = profile.get('name') or 'Selected profile'
            provider_name = ANTHROPIC_PROVIDER_NAME if profile.get('backend') == 'anthropic_compatible' else OPENAI_COMPATIBLE_PROVIDER_NAME
            plugin = plugin_for_name(provider_name)
            backend = plugin.builtin_live_module

            if not backend.is_ready_for_use():
                self.finished_result.emit(
                    False,
                    _('[Error] The selected profile "{0}" is not ready for use.\n'
                      'Check its API key, endpoint URL, and model settings.').format(profile_name)
                )
                return

            self.status_updated.emit(_('Connecting to model...'))
            messages = (ChatMessage(type=ChatMessageType.user, query=self.prompt),)
            accumulated_text = []
            saw_error = False

            for resp in backend.text_chat(messages):
                if self._is_aborted:
                    self.finished_result.emit(False, _('\n\n--- [Cancelled] Request stopped by user. ---'))
                    return
                if resp.exception:
                    saw_error = True
                    self.finished_result.emit(
                        False,
                        f'\n[Exception] {resp.exception}\nDetails: {resp.error_details}\n'
                    )
                    break
                if resp.content:
                    accumulated_text.append(resp.content)
                    self.chunk_received.emit(resp.content)

            if not saw_error and not self._is_aborted:
                answer = ''.join(accumulated_text)
                if is_probable_tool_call_text(answer):
                    self.finished_result.emit(
                        True,
                        _('\n\n--- [Unsupported tool call] The endpoint returned a web-search tool request instead of a final answer. '
                          'Calibre cannot execute client-side tools. Use server-managed search for this endpoint or disable the search payload. ---')
                    )
                elif not answer.strip():
                    self.finished_result.emit(
                        True,
                        _('\n\n--- [Incomplete] The provider returned no assistant text. Check the traffic log for details. ---')
                    )
                else:
                    self.finished_result.emit(
                        True,
                        _('\n\n--- [Success] Request completed successfully. ---')
                    )
        except Exception as e:
            if not self._is_aborted:
                import traceback
                self.finished_result.emit(
                    False,
                    f'\n[Execution Error] {e}\n\nTraceback:\n{traceback.format_exc()}'
                )


class OpenAIModelDiscoveryWorker(QThread):
    """Fetch model IDs from an OpenAI-compatible /models endpoint."""
    finished_result = pyqtSignal(bool, str)

    def __init__(self, api_url: str, api_key: str = '', parent: QObject | None = None):
        super().__init__(parent)
        self.api_url = api_url
        self.api_key = api_key

    def _models_url(self) -> str:
        url = (self.api_url or '').strip().rstrip('/')
        if not url:
            raise ValueError(_('Please enter an endpoint URL.'))
        parsed = urlsplit(url)
        if parsed.scheme not in {'http', 'https'} or not parsed.netloc:
            raise ValueError(_('Endpoint URL must start with http:// or https://.'))
        if url.endswith('/models'):
            return url
        if url.endswith('/chat/completions'):
            url = url[:-len('/chat/completions')]
        return url.rstrip('/') + '/models'

    @staticmethod
    def _extract_model_ids(payload: Any) -> list[str]:
        if isinstance(payload, dict):
            candidates = payload.get('data') or payload.get('models') or []
        elif isinstance(payload, list):
            candidates = payload
        else:
            candidates = []
        model_ids: list[str] = []
        for item in candidates:
            if isinstance(item, dict):
                model_id = item.get('id') or item.get('name') or item.get('model')
            else:
                model_id = item
            if model_id:
                model_ids.append(str(model_id))
        return sorted(dict.fromkeys(model_ids), key=str.casefold)

    def run(self) -> None:
        models_url = ''
        try:
            models_url = self._models_url()
            headers = {'Accept': 'application/json', 'User-Agent': 'AI Config calibre plugin'}
            if self.api_key.strip():
                headers['Authorization'] = 'Bearer ' + self.api_key.strip()
            req = Request(models_url, headers=headers, method='GET')
            with urlopen(req, timeout=20) as response:
                raw = response.read().decode('utf-8', 'replace')
            payload = json.loads(raw)
            model_ids = self._extract_model_ids(payload)
            if not model_ids:
                self.finished_result.emit(
                    False,
                    _('Endpoint reached, but no model IDs were found in the response from:\n{0}\n\nRaw response:\n{1}').format(models_url, raw[:4000]),
                )
                return
            lines = [
                _('Fetched {0} model(s) from:').format(len(model_ids)),
                models_url,
                '',
            ]
            lines.extend(model_ids)
            self.finished_result.emit(True, '\n'.join(lines))
        except HTTPError as err:
            try:
                details = err.read().decode('utf-8', 'replace')[:2000]
            except Exception:
                details = ''
            self.finished_result.emit(False, _('HTTP {0} while fetching models from:\n{1}\n\n{2}').format(err.code, models_url or self.api_url, details))
        except URLError as err:
            self.finished_result.emit(False, _('Network error while fetching models from:\n{0}\n\n{1}').format(models_url or self.api_url, err.reason))
        except Exception as err:
            self.finished_result.emit(False, _('Could not fetch models from:\n{0}\n\n{1}').format(models_url or self.api_url, err))


class ConfigWidget(QWidget):
    """Configuration widget containing all merged AI Tweaks options:
    OpenAI compatible tweaks, live testing, and traffic inspection."""

    # Emitted from a worker thread when the NVIDIA model id list has been
    # refreshed, so the combo can be repopulated on the GUI thread.
    nvidia_models_ready = pyqtSignal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.nvidia_models_ready.connect(self._on_nvidia_models_ready)
        self.setStyleSheet(ccr_scrollbar_stylesheet() + ccr_combo_stylesheet())
        self.zoom_filter = CtrlWheelZoomFilter(self)
        self.installEventFilter(self.zoom_filter)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(8)

        # Tab widget (styled following the Goldendict Bridge / CCR pattern)
        self.tabs = QTabWidget(self)
        try:
            self.tabs.setStyleSheet(goldendict_tab_stylesheet(self.tabs))
        except Exception:
            pass

        # Named AI provider profile and backend management
        tab_profiles = self._build_profiles_tab()
        self.tabs.addTab(tab_profiles, _('Profiles && Providers'))

        # Interactive Test Request & Prompt Simulation
        tab_preview = self._build_preview_tab()
        self.tabs.addTab(tab_preview, _('Test && Simulation'))

        # Traffic Log
        tab_traffic = self._build_traffic_tab()
        self.tabs.addTab(tab_traffic, _('Traffic Log'))

        # Related Comfy plugins and support links
        self.tabs.addTab(self._build_more_tab(), _('More'))

        # About and support information
        self.tabs.addTab(self._build_about_tab(), _('About'))

        self.tabs.currentChanged.connect(self._on_tab_changed)
        main_layout.addWidget(self.tabs)

        self._traffic_refresh_timer = QTimer(self)
        self._traffic_refresh_timer.setInterval(1000)
        self._traffic_refresh_timer.timeout.connect(self._refresh_traffic_if_visible)

        self._refresh_profile_editor()
        self.load_settings()

    def _on_tab_changed(self, index: int) -> None:
        self._capture_profile_editor()
        if index == 1:
            self._refresh_provider_info_label()
            self.update_payload_preview()
        elif index == 2:
            self.refresh_traffic_log()
            self._traffic_refresh_timer.start()
        else:
            self._traffic_refresh_timer.stop()

    def _refresh_traffic_if_visible(self) -> None:
        if self.tabs.currentIndex() == 2:
            self.refresh_traffic_log()

    def _refresh_tab_stylesheet(self) -> None:
        try:
            # Same call as the initial setup: a different font size here would
            # silently resize the tab labels whenever the theme was refreshed.
            self.tabs.setStyleSheet(goldendict_tab_stylesheet(self.tabs))
        except Exception:
            pass

    def _build_profiles_tab(self) -> QWidget:
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        try:
            scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        except Exception:
            pass
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        intro = QLabel(_('<b>AI provider profiles</b><br>'
                          'Create multiple named configurations for OpenAI-compatible services, NVIDIA API, and Anthropic-compatible services. '
                          'Choose a profile to edit, then click Apply or OK to make it the profile calibre uses. '
                          'API keys remain in calibre&#39;s protected AI preferences.'))
        intro.setWordWrap(True)
        layout.addWidget(intro)

        profile_row = QHBoxLayout()
        profile_row.addWidget(QLabel(_('Profile to edit/apply:')))
        self.profile_combo = QComboBox(container)
        self.profile_combo.currentIndexChanged.connect(self._profile_selection_changed)
        profile_row.addWidget(self.profile_combo, 1)
        self.profile_add_btn = QPushButton(_('Add'), container)
        self.profile_add_btn.clicked.connect(self._add_profile)
        profile_row.addWidget(self.profile_add_btn)
        self.profile_delete_btn = QPushButton(_('Delete'), container)
        self.profile_delete_btn.clicked.connect(self._delete_profile)
        profile_row.addWidget(self.profile_delete_btn)
        layout.addLayout(profile_row)

        form_group = QGroupBox(_('Selected profile'), container)
        form = QFormLayout(form_group)
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        self.profile_name_edit = QLineEdit(form_group)
        form.addRow(_('Profile name:'), self.profile_name_edit)
        self.profile_backend_combo = QComboBox(form_group)
        self.profile_backend_combo.addItem(_('NVIDIA API'), 'nvidia_api')
        self.profile_backend_combo.addItem(_('OpenAI compatible'), 'openai_compatible')
        if HAS_ANTHROPIC_BACKEND:
            self.profile_backend_combo.addItem(_('Anthropic compatible'), 'anthropic_compatible')
        self.profile_backend_combo.currentIndexChanged.connect(self._profile_backend_changed)
        form.addRow(_('Backend:'), self.profile_backend_combo)
        self.profile_url_edit = QLineEdit(form_group)
        self.profile_url_edit.setClearButtonEnabled(True)
        self.profile_url_label = QLabel(_('API URL:'), form_group)
        form.addRow(self.profile_url_label, self.profile_url_edit)
        self.profile_key_edit = QLineEdit(form_group)
        self.profile_key_edit.setEchoMode(QLineEdit.EchoMode.Normal)
        self.profile_key_edit.setPlaceholderText(_('Required for hosted APIs; optional for local services'))
        form.addRow(_('API key:'), self.profile_key_edit)
        self.profile_hide_keys_cb = QCheckBox(_('Hide API keys'), form_group)
        self.profile_hide_keys_cb.setChecked(hide_api_keys())
        self.profile_hide_keys_cb.toggled.connect(self._set_profile_key_visibility)
        self._set_profile_key_visibility(self.profile_hide_keys_cb.isChecked())
        form.addRow('', self.profile_hide_keys_cb)

        self.profile_nvidia_help = QLabel(
            _('<b>NVIDIA API - experimental external provider</b><br>'
              'Please note that this is not a built-in calibre provider. Generate a free key on the '
              '<a href="https://build.nvidia.com/settings/api-keys">NVIDIA API Keys</a> '
              'page and paste it above. '
              'Free model availability, quotas, and access are controlled by NVIDIA.'),
            form_group,
        )
        self.profile_nvidia_help.setWordWrap(True)
        self.profile_nvidia_help.setOpenExternalLinks(False)
        self.profile_nvidia_help.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse | Qt.TextInteractionFlag.LinksAccessibleByMouse
        )
        self.profile_nvidia_help.linkActivated.connect(open_url)
        form.addRow(self.profile_nvidia_help)

        model_row = QWidget(form_group)
        model_layout = QHBoxLayout(model_row)
        model_layout.setContentsMargins(0, 0, 0, 0)
        self.profile_model_combo = QComboBox(model_row)
        self.profile_model_combo.setEditable(True)
        self.profile_model_combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self.profile_model_combo.setToolTip(_('Choose a model or enter any model ID supported by the service.'))
        model_layout.addWidget(self.profile_model_combo, 1)
        self.profile_browse_models_btn = QPushButton(_('Browse NVIDIA models'), model_row)
        self.profile_browse_models_btn.setToolTip(_('Open the searchable NVIDIA model browser.'))
        self.profile_browse_models_btn.clicked.connect(self._browse_nvidia_profile_models)
        model_layout.addWidget(self.profile_browse_models_btn)
        form.addRow(_('Model:'), model_row)

        self.profile_anthropic_options = QWidget(form_group)
        anthropic_layout = QHBoxLayout(self.profile_anthropic_options)
        anthropic_layout.setContentsMargins(0, 0, 0, 0)
        self.profile_model_strategy_combo = QComboBox(self.profile_anthropic_options)
        for label, value in ((_('Low'), 'low'), (_('Medium'), 'medium'), (_('High'), 'high')):
            self.profile_model_strategy_combo.addItem(label, value)
        anthropic_layout.addWidget(QLabel(_('Choice:'), self.profile_anthropic_options))
        anthropic_layout.addWidget(self.profile_model_strategy_combo)
        self.profile_reasoning_strategy_combo = QComboBox(self.profile_anthropic_options)
        for label, value in ((_('Automatic'), 'auto'), (_('None'), 'none'), (_('Low'), 'low'), (_('Medium'), 'medium'), (_('High'), 'high')):
            self.profile_reasoning_strategy_combo.addItem(label, value)
        anthropic_layout.addWidget(QLabel(_('Reasoning:'), self.profile_anthropic_options))
        anthropic_layout.addWidget(self.profile_reasoning_strategy_combo)
        self.profile_allow_web_search_cb = QCheckBox(_('Allow web search'), self.profile_anthropic_options)
        anthropic_layout.addWidget(self.profile_allow_web_search_cb)
        anthropic_layout.addStretch(1)
        self.profile_anthropic_options_label = QLabel(_('Anthropic options:'), form_group)
        form.addRow(self.profile_anthropic_options_label, self.profile_anthropic_options)

        request_options_row = QWidget(form_group)
        request_options_layout = QHBoxLayout(request_options_row)
        request_options_layout.setContentsMargins(0, 0, 0, 0)
        self.profile_timeout_sb = QSpinBox(request_options_row)
        self.profile_timeout_sb.setRange(15, 600)
        self.profile_timeout_sb.setSuffix(_(' seconds'))
        self.profile_timeout_label = QLabel(_('Timeout:'), request_options_row)
        request_options_layout.addWidget(self.profile_timeout_label)
        request_options_layout.addWidget(self.profile_timeout_sb)
        request_options_layout.addSpacing(16)
        self.profile_temp_sb = QDoubleSpinBox(request_options_row)
        self.profile_temp_sb.setRange(0.0, 2.0)
        self.profile_temp_sb.setSingleStep(0.1)
        self.profile_temp_label = QLabel(_('Temperature:'), request_options_row)
        request_options_layout.addWidget(self.profile_temp_label)
        request_options_layout.addWidget(self.profile_temp_sb)
        request_options_layout.addStretch(1)
        self.profile_request_options_label = QLabel(_('Request options:'), form_group)
        form.addRow(self.profile_request_options_label, request_options_row)
        self.profile_headers_edit = QPlainTextEdit(form_group)
        self.profile_headers_edit.setPlaceholderText(_('Optional HTTP headers, one per line: Header-Name: Value'))
        self.profile_headers_edit.setMaximumHeight(90)
        self.profile_headers_label = QLabel(_('HTTP headers:'), form_group)
        form.addRow(self.profile_headers_label, self.profile_headers_edit)
        layout.addWidget(form_group)

        self.profile_status_label = QLabel('', container)
        self.profile_status_label.setWordWrap(True)
        layout.addWidget(self.profile_status_label)
        layout.addStretch(1)
        scroll.setWidget(container)
        return scroll

    def _build_more_tab(self) -> QWidget:
        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(tab)
        scroll.setWidgetResizable(True)
        try:
            scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        except Exception:
            pass
        host = QWidget()
        host_layout = QVBoxLayout(host)
        host_layout.setContentsMargins(12, 12, 12, 12)
        host_layout.setSpacing(6)

        toolbar_group = QGroupBox(_('Toolbar button'), host)
        toolbar_layout = QFormLayout(toolbar_group)
        toolbar_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        self.toolbar_action_combo = QComboBox(toolbar_group)
        try:
            self.toolbar_action_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            self.toolbar_action_combo.setMinimumContentsLength(24)
        except Exception:
            pass
        selected_key = normalise_toolbar_action_key(plugin_prefs.get(KEY_SELECTED_ACTION, DEFAULT_SELECTED_ACTION))
        for choice in toolbar_action_choices():
            icon = QIcon()
            try:
                from . import common_icons
                icon = common_icons.get_icon(choice['icon'])
            except Exception:
                pass
            self.toolbar_action_combo.addItem(icon, choice['label'], choice['key'])
            index = self.toolbar_action_combo.count() - 1
            if not choice.get('enabled', True):
                try:
                    item = self.toolbar_action_combo.model().item(index)
                    item.setEnabled(False)
                    item.setToolTip(choice.get('disabled_reason', ''))
                except Exception:
                    pass
        self.toolbar_action_combo.setCurrentIndex(max(0, self.toolbar_action_combo.findData(selected_key)))
        toolbar_layout.addRow(_('Main button action:'), self.toolbar_action_combo)
        toolbar_hint = QLabel(_('Choose what opens when clicking the AI Config toolbar button.'), toolbar_group)
        toolbar_hint.setWordWrap(True)
        toolbar_layout.addRow('', toolbar_hint)
        host_layout.addWidget(toolbar_group)

        # Plugin names are proper nouns and stay untranslated; only the
        # descriptions are localised.
        plugins = (
            ('AI Config', _('Quick access to AI settings'), 'https://www.mobileread.com/forums/showthread.php?t=371037'),
            ('BERTRAND Livreiros', _('Downloads metadata and covers from BERTRAND'), 'https://www.mobileread.com/forums/showthread.php?t=374669'),
            ('Best Sellers', _('Book Catalogs, Blurb & Review Finders'), 'https://www.mobileread.com/forums/showthread.php?t=374278'),
            ('Book List Plus', _('Book list view with covers'), 'https://www.mobileread.com/forums/showthread.php?t=373100'),
            ('Calibre Config Reports', _('Configuration reporting tool'), 'https://www.mobileread.com/forums/showthread.php?t=369555'),
            ('Chapter Summarizer', _('Powerful document summarizer'), 'https://www.mobileread.com/forums/showthread.php?t=374061'),
            ('Columns Helper', _('Columns management tools'), 'https://www.mobileread.com/forums/showthread.php?t=372614'),
            ('Comfy Reminders', _('Create and manage reminders'), 'https://www.mobileread.com/forums/showthread.php?t=367258'),
            ('Current Paths', _('Show config/library paths'), 'https://www.mobileread.com/forums/showthread.php?t=371623'),
            ('Custom Action Button', _('Configurable toolbar button'), 'https://www.mobileread.com/forums/showthread.php?t=374301'),
            ('DELFI knjižare', _('Downloads metadata and covers from DELFI'), 'https://www.mobileread.com/forums/showthread.php?t=374478'),
            ('Extended Book Details', _('Book Details on left panel'), 'https://www.mobileread.com/forums/showthread.php?t=372675'),
            ('FTS+', _('FTS with additional features'), 'https://www.mobileread.com/forums/showthread.php?t=372481'),
            ('Goldendict Bridge', _('Multiple dictionary local lookup'), 'https://www.mobileread.com/forums/showthread.php?t=372546'),
            ('Input Order Swap', _('Swap top two input formats'), 'https://www.mobileread.com/forums/showthread.php?t=371116'),
            ('KoboTouch Config Button', _('Quick access to Kobo config'), 'https://www.mobileread.com/forums/showthread.php?t=367728'),
            ('Language Switcher', _('Quick-switch Calibre language'), 'https://www.mobileread.com/forums/showthread.php?t=372153'),
            ('Look & Feel Button', _('Quick access to Look & Feel'), 'https://www.mobileread.com/forums/showthread.php?t=372670'),
            ('Metadata Sources Preview', _('Preview metadata providers'), 'https://www.mobileread.com/forums/showthread.php?t=373625'),
            ('Open Config Folder', _('Open Calibre configuration folder'), 'https://www.mobileread.com/forums/showthread.php?t=372023'),
            ('OPF Helper', _('Toolkit for all things OPF'), 'https://www.mobileread.com/forums/showthread.php?t=371086'),
            ('Output Format Cycler', _('Cycle output format'), 'https://www.mobileread.com/forums/showthread.php?t=371117'),
            ('Quick Palette Customize', _('Quick access to palette config'), 'https://www.mobileread.com/forums/showthread.php?t=372047'),
            ('RSS Reader', _('Read RSS/Atom feeds inside calibre'), 'https://www.mobileread.com/forums/showthread.php?t=371755'),
            ('Shortcuts Helper', _('Quick access to Shortcuts'), 'https://www.mobileread.com/forums/showthread.php?t=372349'),
            ('Template Catalog', _('Manage and organize templates'), 'https://www.mobileread.com/forums/showthread.php?t=366843'),
            ('Toggle Light & Dark', _('Toggle light/dark theme'), 'https://www.mobileread.com/forums/showthread.php?t=371676'),
            ('Toolbars Button', _('Quick access to Toolbars and Menus'), 'https://www.mobileread.com/forums/showthread.php?t=372229'),
            ('VL from selection', _('Create VLs from selection'), 'https://www.mobileread.com/forums/showthread.php?t=371238'),
        )
        for name, description, url in plugins:
            row = QLabel(
                f'<a href="{url}">{name}</a> - {description}',
                host,
            )
            row.setTextFormat(Qt.TextFormat.RichText)
            row.setOpenExternalLinks(False)
            row.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse | Qt.TextInteractionFlag.LinksAccessibleByMouse
            )
            row.linkActivated.connect(open_url)
            host_layout.addWidget(row)
        host_layout.addStretch(1)
        scroll.setWidget(host)
        layout.addWidget(scroll)
        return tab

    def _build_about_tab(self) -> QWidget:
        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        about = QLabel(
                        _('<style>a {{ text-decoration: none; }}</style>'
                            '<h2>AI Config</h2>'
                            '<p>Quick access to AI provider settings, named provider profiles, '
                            'live testing, and traffic inspection.</p>'
                            '<p>Version {}</p>'
                            '<p style="font-size:11pt;"><a href="https://www.mobileread.com/forums/showthread.php?t=371037">MobileRead Forums</a></p>'
                            '<p style="font-size:12pt;"><a href="https://ko-fi.com/comfy_n">Gift me some recognition</a></p>').format(_plugin_version_text()),
            tab,
        )
        about.setAlignment(Qt.AlignmentFlag.AlignCenter)
        about.setWordWrap(True)
        about.setTextFormat(Qt.TextFormat.RichText)
        about.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        about.setOpenExternalLinks(False)
        about.linkActivated.connect(open_url)
        layout.addWidget(about)

        qr = QLabel(tab)
        qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        qr.setMinimumSize(96, 96)
        try:
            from . import common_icons
            pm = common_icons.get_pixmap('images/qrcode.png')
            if pm is None or pm.isNull():
                local_path = os.path.join(os.path.dirname(__file__), 'images', 'qrcode.png')
                pm = QPixmap()
                pm.load(local_path)
            if pm is not None and not pm.isNull():
                pm = pm.scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio,
                               Qt.TransformationMode.SmoothTransformation)
            if pm is not None and not pm.isNull():
                qr.setPixmap(pm)
                qr.setCursor(Qt.CursorShape.PointingHandCursor)
                qr.setToolTip(_('Open donation support'))
                qr.mousePressEvent = lambda _event: open_url('https://ko-fi.com/comfy_n')
        except Exception:
            pass
        layout.addWidget(qr, 0, Qt.AlignmentFlag.AlignCenter)
        layout.addStretch(1)
        return tab

    def _refresh_profile_editor(
        self,
        profiles: list[dict[str, Any]] | None = None,
        active_id: str = '',
    ) -> None:
        if profiles is None:
            profiles, stored_active_id = get_ai_profiles()
            active_id = active_id or stored_active_id
        self._profiles = profiles
        if not active_id and profiles:
            active_id = profiles[0]['id']
        self._profile_active_id = active_id
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        selected_index = 0
        for index, profile in enumerate(profiles):
            label = f"{profile['name']} — {self._profile_backend_label(profile['backend'])}"
            self.profile_combo.addItem(label, profile['id'])
            if profile['id'] == active_id:
                selected_index = index
        self.profile_combo.setCurrentIndex(selected_index)
        self.profile_combo.blockSignals(False)
        self._editing_profile_id = ''
        self._load_profile_into_editor(selected_index)

    def _load_profile_into_editor(self, index: int) -> None:
        if not getattr(self, '_profiles', None) or index < 0 or index >= len(self._profiles):
            return
        profile = self._profiles[index]
        self._loading_profile = True
        try:
            self.profile_name_edit.setText(profile['name'])
            self.profile_backend_combo.setCurrentIndex(max(0, self.profile_backend_combo.findData(profile['backend'])))
            self.profile_url_edit.setText(profile['api_url'])
            self.profile_key_edit.setText(profile_plain_api_key(profile))
            self._populate_profile_models(profile)
            self.profile_model_combo.setCurrentText(profile['text_model'])
            self.profile_model_strategy_combo.setCurrentIndex(max(0, self.profile_model_strategy_combo.findData(profile.get('model_choice_strategy', 'medium'))))
            self.profile_reasoning_strategy_combo.setCurrentIndex(max(0, self.profile_reasoning_strategy_combo.findData(profile.get('reasoning_strategy', 'auto'))))
            self.profile_allow_web_search_cb.setChecked(bool(profile.get('allow_web_searches', False)))
            self.profile_timeout_sb.setValue(profile['timeout'])
            self.profile_temp_sb.setValue(profile['temperature'])
            self.profile_headers_edit.setPlainText('\n'.join(f'{key}: {value}' for key, value in profile['headers']))
            self._editing_profile_id = profile['id']
        finally:
            self._loading_profile = False
        self._update_model_controls()
        self.profile_status_label.setText(
            _('Selected profile: {} — {}. API key configured: {}').format(
                profile['name'], self._profile_backend_label(profile['backend']),
                _('yes') if profile_plain_api_key(profile) else _('no'),
            )
        )

    def _profile_backend_label(self, backend: str) -> str:
        labels = {
            'openai_compatible': _('OpenAI compatible'),
            'nvidia_api': _('NVIDIA API'),
            'anthropic_compatible': _('Anthropic compatible'),
        }
        return labels.get(backend, backend.replace('_', ' '))

    def _profile_backend_changed(self, _index: int) -> None:
        """Reset transport-specific values when a user converts a profile."""
        self._update_model_controls()
        if getattr(self, '_loading_profile', False):
            return
        backend = self.profile_backend_combo.currentData() or 'openai_compatible'
        defaults = {
            'openai_compatible': (_('OpenAI compatible'), '', ''),
            'nvidia_api': (_('NVIDIA API'), DEFAULT_NVIDIA_API_URL, DEFAULT_NVIDIA_MODEL),
            'anthropic_compatible': (_('Anthropic compatible'), '', ''),
        }
        name, api_url, model = defaults[backend]
        self.profile_name_edit.setText(name)
        self.profile_url_edit.setText(api_url)
        self.profile_key_edit.clear()
        self.profile_headers_edit.clear()
        self.profile_timeout_sb.setValue(120)
        self.profile_temp_sb.setValue(0.7)
        self.profile_model_strategy_combo.setCurrentIndex(max(0, self.profile_model_strategy_combo.findData('medium')))
        self.profile_reasoning_strategy_combo.setCurrentIndex(max(0, self.profile_reasoning_strategy_combo.findData('auto')))
        self.profile_allow_web_search_cb.setChecked(False)
        self._populate_profile_models({'backend': backend, 'text_model': model})
        self.profile_model_combo.setCurrentText(model)
        self._capture_profile_editor()

    def _populate_profile_models(self, profile: dict[str, Any]) -> None:
        current = str(profile.get('text_model') or '').strip()
        self.profile_model_combo.blockSignals(True)
        self.profile_model_combo.clear()
        models: list[str] = []
        if profile.get('backend') == 'nvidia_api':
            models = self._cached_nvidia_model_ids()
        elif profile.get('backend') == 'anthropic_compatible':
            try:
                from calibre.ai.anthropic.backend import builtin_models
                models = [str(model.id).strip() for model in builtin_models().values() if str(model.id).strip()]
            except Exception:
                models = []
        if current and current not in models:
            models.insert(0, current)
        self.profile_model_combo.addItems(models)
        self.profile_model_combo.setCurrentText(current)
        self.profile_model_combo.blockSignals(False)

    def _cached_nvidia_model_ids(self) -> list[str]:
        """Return NVIDIA model ids without ever hitting the network.

        Opening this dialog must not block on HTTP. We read whatever is already
        cached (in memory or on disk) and kick off a single background refresh;
        when that finishes the combo is repopulated.
        """
        try:
            from calibre_plugins.ai_config.nvidia_free import get_cached_model_ids
            models = [str(item).strip() for item in get_cached_model_ids() if str(item).strip()]
        except Exception:
            models = []
        self._schedule_nvidia_model_refresh()
        return models

    def _schedule_nvidia_model_refresh(self) -> None:
        if getattr(self, '_nvidia_models_refresh_started', False):
            return
        self._nvidia_models_refresh_started = True

        def worker():
            try:
                from calibre_plugins.ai_config.nvidia_free import get_available_models
                get_available_models()
            except Exception:
                pass
            try:
                self.nvidia_models_ready.emit()
            except Exception:
                pass

        from threading import Thread
        Thread(target=worker, name='AIConfigNvidiaModelIds', daemon=True).start()

    def _on_nvidia_models_ready(self) -> None:
        try:
            index = self.profile_combo.currentIndex()
            if 0 <= index < len(getattr(self, '_profiles', ())):
                profile = self._profiles[index]
                if profile.get('backend') == 'nvidia_api':
                    wanted = self.profile_model_combo.currentText().strip()
                    self._populate_profile_models(dict(profile, text_model=wanted or profile.get('text_model')))
        except Exception:
            pass

    def _update_model_controls(self) -> None:
        backend = self.profile_backend_combo.currentData()
        is_nvidia = backend == 'nvidia_api'
        is_anthropic = backend == 'anthropic_compatible'
        self.profile_browse_models_btn.setVisible(is_nvidia)
        self.profile_nvidia_help.setVisible(is_nvidia)
        self.profile_anthropic_options.setVisible(is_anthropic)
        self.profile_anthropic_options_label.setVisible(is_anthropic)
        self.profile_url_label.setText(_('Anthropic Messages API base URL:') if is_anthropic else _('API URL:'))
        self.profile_url_edit.setToolTip(
            _('Optional base URL for an Anthropic Messages API-compatible gateway. Leave empty for the official Anthropic API.')
            if is_anthropic else ''
        )
        # These controls belong to calibre's OpenAI-compatible transport and are
        # hidden for Anthropic, whose native backend does not read them.
        for widget, label in (
            (self.profile_timeout_sb, self.profile_timeout_label),
            (self.profile_temp_sb, self.profile_temp_label),
            (self.profile_headers_edit, self.profile_headers_label),
        ):
            widget.setVisible(not is_anthropic)
            label.setVisible(not is_anthropic)
        self.profile_request_options_label.setVisible(not is_anthropic)
        self.profile_model_combo.setToolTip(
            _('Choose a NVIDIA model or enter any supported model ID.') if is_nvidia else
            _('Choose a native Anthropic model or enter a model ID supported by the gateway.') if is_anthropic else
            _('Choose a model or enter any model ID supported by the service.')
        )

    def _set_profile_key_visibility(self, hide: bool) -> None:
        set_hide_api_keys(hide)
        self.profile_key_edit.setEchoMode(
            QLineEdit.EchoMode.Password if hide else QLineEdit.EchoMode.Normal
        )

    def _browse_nvidia_profile_models(self) -> None:
        try:
            from calibre_plugins.ai_config.nvidia_models_dialog import ChooseNvidiaModel
            dialog = ChooseNvidiaModel(self.profile_model_combo.currentText().strip(), self)
            if dialog.exec() == QDialog.DialogCode.Accepted and dialog.model_id:
                model_id = dialog.model_id.strip()
                if self.profile_model_combo.findText(model_id) < 0:
                    self.profile_model_combo.addItem(model_id)
                self.profile_model_combo.setCurrentText(model_id)
        except Exception as err:
            error_dialog(self, _('NVIDIA model browser error'), str(err), show=True)

    def _capture_profile_editor(self) -> None:
        editing_id = getattr(self, '_editing_profile_id', '')
        profile = next((item for item in getattr(self, '_profiles', ()) if item['id'] == editing_id), None)
        if profile is None:
            return
        headers = []
        for line in self.profile_headers_edit.toPlainText().splitlines():
            key, sep, value = line.partition(':')
            if sep and key.strip() and value.strip():
                headers.append((key.strip(), value.strip()))
        from calibre.ai.prefs import encode_secret
        profile.update({
            'name': self.profile_name_edit.text().strip() or _('Unnamed profile'),
            'backend': self.profile_backend_combo.currentData() or 'openai_compatible',
            'api_url': self.profile_url_edit.text().strip().rstrip('/'),
            'api_key': encode_secret(self.profile_key_edit.text().strip()) if self.profile_key_edit.text().strip() else '',
            'text_model': self.profile_model_combo.currentText().strip(),
            'timeout': self.profile_timeout_sb.value(),
            'temperature': self.profile_temp_sb.value(),
            'model_choice_strategy': self.profile_model_strategy_combo.currentData() or 'medium',
            'reasoning_strategy': self.profile_reasoning_strategy_combo.currentData() or 'auto',
            'allow_web_searches': self.profile_allow_web_search_cb.isChecked(),
            'headers': tuple(headers),
        })
        index = self.profile_combo.findData(editing_id)
        if index >= 0:
            self.profile_combo.blockSignals(True)
            self.profile_combo.setItemText(index, f"{profile['name']} — {self._profile_backend_label(profile['backend'])}")
            self.profile_combo.blockSignals(False)

    def _profile_selection_changed(self, index: int) -> None:
        self._capture_profile_editor()
        active_id = self.profile_combo.itemData(index)
        if active_id:
            self._profile_active_id = active_id
        self._load_profile_into_editor(index)

    def _add_profile(self) -> None:
        self._capture_profile_editor()
        from uuid import uuid4
        profile = _normalise_profile({'id': uuid4().hex, 'name': _('New profile')}, len(self._profiles))
        self._profiles.append(profile)
        self._refresh_profile_editor(self._profiles, profile['id'])

    def _delete_profile(self) -> None:
        if len(getattr(self, '_profiles', [])) <= 1:
            info_dialog(self, _('Cannot delete profile'), _('At least one profile must remain.'), show=True)
            return
        self._capture_profile_editor()
        current_id = self.profile_combo.currentData()
        index = max(0, self.profile_combo.currentIndex())
        self._profiles = [item for item in self._profiles if item['id'] != current_id]
        next_index = min(index, len(self._profiles) - 1)
        self._refresh_profile_editor(self._profiles, self._profiles[next_index]['id'])

    def _save_profile_settings(self) -> None:
        self._capture_profile_editor()
        active_id = self.profile_combo.currentData() or self._profile_active_id
        save_ai_profiles(self._profiles, active_id)
        self._profile_active_id = active_id

    def _build_settings_tab(self) -> QWidget:
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        try:
            scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        except Exception:
            pass

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(12)

        # --- Section 1: Provider-managed Chat Completions web search ---
        gb_web = QGroupBox(_('OpenAI-compatible Provider-managed Web Search'), container)
        v_web = QVBoxLayout(gb_web)
        v_web.setSpacing(8)

        self.cb_enforce_web_search = QCheckBox(
            _('Send the provider-specific "web_search_options" request field'),
            gb_web,
        )
        self.cb_enforce_web_search.setToolTip(
            _('Use only with an OpenAI-compatible endpoint that documents server-managed web search via "web_search_options".\n'
              'This does not enable a generic calibre search tool and cannot execute client-side tool calls.')
        )
        self.cb_enforce_web_search.toggled.connect(self._on_web_search_toggled)
        v_web.addWidget(self.cb_enforce_web_search)

        search_warning = QLabel(
            _('<b>Compatibility note:</b> This field is not part of the core Chat Completions protocol. '
              'A compatible server must perform the search itself and return final assistant text. '
              'If it returns <code>tool_calls</code> or text such as <code>tool - web search {...}</code>, '
              'calibre cannot execute that client-side tool; the traffic inspector will report it explicitly. '
              'Anthropic profiles use their separate native “Allow web search” option.'),
            gb_web,
        )
        search_warning.setWordWrap(True)
        v_web.addWidget(search_warning)

        la_web_desc = QLabel(
            _('Provider-specific <code>web_search_options</code> JSON object:'),
            gb_web,
        )
        la_web_desc.setWordWrap(True)
        v_web.addWidget(la_web_desc)

        self.edit_web_search_options = QLineEdit(gb_web)
        self.edit_web_search_options.setPlaceholderText('{}')
        self.edit_web_search_options.setToolTip(
            _('Enter the JSON object documented by your endpoint for "web_search_options".\n'
              'For Perplexity Sonar, for example: {"search_context_size": "normal"}.\n'
              'Do not enable this for endpoints that expose search only as a client-executed tool.')
        )
        self.edit_web_search_options.textChanged.connect(self._validate_web_search_options)
        self.edit_web_search_options.installEventFilter(self.zoom_filter)
        v_web.addWidget(self.edit_web_search_options)

        # Presets bar for web search
        h_presets = QHBoxLayout()
        h_presets.setSpacing(6)
        la_preset = QLabel(_('Quick presets:'), gb_web)
        h_presets.addWidget(la_preset)

        btn_preset_empty = QPushButton(_('Default ({})'), gb_web)
        btn_preset_empty.clicked.connect(lambda: self.edit_web_search_options.setText('{}'))
        h_presets.addWidget(btn_preset_empty)

        btn_preset_sonar = QPushButton(_('Perplexity Normal Context'), gb_web)
        btn_preset_sonar.clicked.connect(lambda: self.edit_web_search_options.setText('{"search_context_size": "normal"}'))
        h_presets.addWidget(btn_preset_sonar)

        btn_preset_sonar_high = QPushButton(_('Perplexity High Context'), gb_web)
        btn_preset_sonar_high.clicked.connect(lambda: self.edit_web_search_options.setText('{"search_context_size": "high"}'))
        h_presets.addWidget(btn_preset_sonar_high)

        h_presets.addStretch()
        v_web.addLayout(h_presets)

        self.lbl_web_search_status = QLabel('', gb_web)
        v_web.addWidget(self.lbl_web_search_status)

        layout.addWidget(gb_web)

        # --- Section 2: Arbitrary Extra JSON Body ---
        gb_extra = QGroupBox(_('Custom Extra Body JSON Parameters'), container)
        v_extra = QVBoxLayout(gb_extra)
        v_extra.setSpacing(8)

        self.cb_extra_body = QCheckBox(
            _('Include additional custom JSON body parameters in outgoing requests'),
            gb_extra,
        )
        self.cb_extra_body.setToolTip(
            _('When checked, all top-level keys defined in the JSON editor below will be merged\n'
              'directly into the OpenAI compatible chat completion request payload.')
        )
        self.cb_extra_body.toggled.connect(self._on_extra_body_toggled)
        v_extra.addWidget(self.cb_extra_body)

        self.edit_extra_body = QPlainTextEdit(gb_extra)
        self.edit_extra_body.setPlaceholderText('{\n  "web_search_options": {}\n}')
        self.edit_extra_body.setMinimumHeight(110)
        self.edit_extra_body.textChanged.connect(self._validate_extra_body_json)
        self.edit_extra_body.installEventFilter(self.zoom_filter)
        v_extra.addWidget(self.edit_extra_body)

        h_extra_tools = QHBoxLayout()
        self.btn_format_json = QPushButton(_('Format / Prettify JSON'), gb_extra)
        self.btn_format_json.clicked.connect(self._prettify_extra_body_json)
        h_extra_tools.addWidget(self.btn_format_json)

        self.btn_reset_extra = QPushButton(_('Reset to Default'), gb_extra)
        self.btn_reset_extra.clicked.connect(lambda: self.edit_extra_body.setPlainText(DEFAULT_EXTRA_BODY_JSON))
        h_extra_tools.addWidget(self.btn_reset_extra)

        h_extra_tools.addStretch()
        self.lbl_extra_status = QLabel('', gb_extra)
        h_extra_tools.addWidget(self.lbl_extra_status)
        v_extra.addLayout(h_extra_tools)

        layout.addWidget(gb_extra)

        # --- Section 3: Diagnostic & Runtime Logging ---
        gb_diag = QGroupBox(_('Diagnostic && Runtime Logging'), container)
        v_diag = QVBoxLayout(gb_diag)
        self.cb_log_payloads = QCheckBox(
            _('Log outgoing OpenAI compatible request payloads to calibre debug log'),
            gb_diag,
        )
        self.cb_log_payloads.setToolTip(
            _('When enabled, the complete JSON request payload sent to the OpenAI compatible provider\n'
              'will be printed in calibre debug logs for auditing and inspection.')
        )
        v_diag.addWidget(self.cb_log_payloads)
        layout.addWidget(gb_diag)

        layout.addStretch()
        scroll.setWidget(container)
        return scroll

    def _build_preview_tab(self) -> QWidget:
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        try:
            scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        except Exception:
            pass
        container = QWidget(scroll)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # Top info panel showing configured provider status
        self.lbl_provider_info = QLabel('', container)
        self.lbl_provider_info.setWordWrap(True)
        layout.addWidget(self.lbl_provider_info)

        # Buttons row
        h_btns = QHBoxLayout()
        self.btn_preview_payload = QPushButton(_('Preview Request JSON'), container)
        self.btn_preview_payload.clicked.connect(self.update_payload_preview)
        h_btns.addWidget(self.btn_preview_payload)

        self.btn_test_live = QPushButton(_('Send Live Test Request'), container)
        self.btn_test_live.clicked.connect(self.run_live_test_request)
        h_btns.addWidget(self.btn_test_live)

        self.btn_cancel_test = QPushButton(_('Stop Request'), container)
        self.btn_cancel_test.clicked.connect(self._cancel_live_test_request)
        self.btn_cancel_test.setEnabled(False)
        self.btn_cancel_test.setVisible(False)
        h_btns.addWidget(self.btn_cancel_test)

        h_btns.addStretch()

        self.lbl_test_status = QLabel('', container)
        h_btns.addWidget(self.lbl_test_status)
        layout.addLayout(h_btns)

        discovery_group = QGroupBox(_('OpenAI-compatible model discovery'), container)
        discovery_layout = QFormLayout(discovery_group)
        discovery_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)

        self.model_discovery_url_combo = QComboBox(discovery_group)
        self.model_discovery_url_combo.setEditable(True)
        self.model_discovery_url_combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self.model_discovery_url_combo.setMaxVisibleItems(10)
        try:
            self.model_discovery_url_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            self.model_discovery_url_combo.setMinimumContentsLength(32)
        except Exception:
            pass
        self.model_discovery_url_combo.setToolTip(_('Enter or choose a previous OpenAI-compatible endpoint URL.'))
        try:
            line_edit = self.model_discovery_url_combo.lineEdit()
            if line_edit is not None:
                line_edit.setClearButtonEnabled(True)
                line_edit.setPlaceholderText(_('e.g. https://api.openai.com/v1 or http://localhost:11434/v1'))
                line_edit.editingFinished.connect(self._commit_model_discovery_endpoint_history)
                line_edit.returnPressed.connect(self._commit_model_discovery_endpoint_history)
        except Exception:
            pass
        self.model_discovery_url_combo.activated.connect(self._on_model_discovery_endpoint_activated)
        self._refresh_model_discovery_endpoint_history('')
        discovery_layout.addRow(_('Endpoint URL:'), self.model_discovery_url_combo)

        self.model_discovery_key_edit = QLineEdit(discovery_group)
        self.model_discovery_key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.model_discovery_key_edit.setPlaceholderText(_('Optional API key'))
        discovery_layout.addRow(_('API key:'), self.model_discovery_key_edit)

        discovery_controls = QHBoxLayout()
        self.btn_fetch_models = QPushButton(_('Fetch Models'), discovery_group)
        self.btn_fetch_models.clicked.connect(self.fetch_openai_compatible_models)
        discovery_controls.addWidget(self.btn_fetch_models)
        self.btn_fill_model_discovery_from_profile = QPushButton(_('Use Current Profile'), discovery_group)
        self.btn_fill_model_discovery_from_profile.clicked.connect(self._fill_model_discovery_from_current_profile)
        discovery_controls.addWidget(self.btn_fill_model_discovery_from_profile)
        discovery_controls.addStretch(1)
        self.lbl_model_discovery_status = QLabel('', discovery_group)
        discovery_controls.addWidget(self.lbl_model_discovery_status)
        discovery_layout.addRow('', discovery_controls)
        layout.addWidget(discovery_group)

        self._fill_model_discovery_from_current_profile()

        # Prompt input
        la_prompt = QLabel(_('Test prompt to simulate / send:'), container)
        layout.addWidget(la_prompt)
        self.edit_test_prompt = QLineEdit(container)
        self.edit_test_prompt.setText('Tell me something genuinely fascinating that most people don\'t know about. Answer in English.')
        self.edit_test_prompt.installEventFilter(self.zoom_filter)
        layout.addWidget(self.edit_test_prompt)

        # Output / Preview viewer
        la_viewer = QLabel(_('Request preview / Provider response:'), container)
        layout.addWidget(la_viewer)
        self.txt_output_viewer = QTextEdit(container)
        self.txt_output_viewer.setReadOnly(True)
        self.txt_output_viewer.setPlaceholderText(_('Click "Preview Request JSON" or "Send Live Test Request" above.'))
        self.txt_output_viewer.setMinimumHeight(140)
        self.txt_output_viewer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.txt_output_viewer.installEventFilter(self.zoom_filter)
        layout.addWidget(self.txt_output_viewer)

        scroll.setWidget(container)
        return scroll

    def _build_traffic_tab(self) -> QWidget:
        container = QWidget(self)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # Top explanation
        la_desc = QLabel(
            _('This table captures all HTTP transactions sent by Calibre AI providers in real time (including successful queries, streamed tokens, and error details).\n'
              'Select any transaction below to inspect the outgoing request body, headers, latency, and full server response.'),
            container,
        )
        la_desc.setWordWrap(True)
        layout.addWidget(la_desc)

        # Action buttons
        h_ctrl = QHBoxLayout()
        self.btn_refresh_traffic = QPushButton(_('Refresh Traffic Log'), container)
        self.btn_refresh_traffic.clicked.connect(self.refresh_traffic_log)
        h_ctrl.addWidget(self.btn_refresh_traffic)

        self.btn_clear_traffic = QPushButton(_('Clear History'), container)
        self.btn_clear_traffic.clicked.connect(self.clear_traffic_log)
        h_ctrl.addWidget(self.btn_clear_traffic)

        self.btn_copy_payload = QPushButton(_('Copy Request JSON'), container)
        self.btn_copy_payload.clicked.connect(self.copy_selected_payload)
        h_ctrl.addWidget(self.btn_copy_payload)

        self.btn_copy_response = QPushButton(_('Copy Server Response'), container)
        self.btn_copy_response.clicked.connect(self.copy_selected_response)
        h_ctrl.addWidget(self.btn_copy_response)

        h_ctrl.addStretch()
        layout.addLayout(h_ctrl)

        # Splitter: Top table of requests, Bottom text inspector
        splitter = QSplitter(Qt.Orientation.Vertical, container)

        self.traffic_list = QListWidget(splitter)
        self.traffic_list.currentRowChanged.connect(self._on_traffic_item_selected)
        splitter.addWidget(self.traffic_list)

        v_detail = QWidget(splitter)
        v_det_layout = QVBoxLayout(v_detail)
        v_det_layout.setContentsMargins(0, 4, 0, 0)
        self.lbl_traffic_meta = QLabel(_('Select a request above to view details.'), v_detail)
        self.lbl_traffic_meta.setWordWrap(True)
        v_det_layout.addWidget(self.lbl_traffic_meta)

        self.txt_traffic_body = QTextEdit(v_detail)
        self.txt_traffic_body.setReadOnly(True)
        self.txt_traffic_body.installEventFilter(self.zoom_filter)
        v_det_layout.addWidget(self.txt_traffic_body)

        splitter.addWidget(v_detail)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 5)

        layout.addWidget(splitter)
        return container

    def refresh_traffic_log(self) -> None:
        try:
            from calibre_plugins.ai_config.tweaks import get_traffic_history
            events = get_traffic_history()
            selected_id = ''
            selected_row = self.traffic_list.currentRow()
            if 0 <= selected_row < len(getattr(self, '_cached_traffic_events', [])):
                selected_id = self._cached_traffic_events[selected_row].get('id', '')
            self.traffic_list.clear()
            self._cached_traffic_events = events

            if not events:
                self.traffic_list.addItem(_('No HTTP requests recorded yet. Make a query in Calibre to see live traffic.'))
                self.txt_traffic_body.setPlainText('')
                self.lbl_traffic_meta.setText('')
                return

            for ev in events:
                ts = ev.get('timestamp', '')
                provider = ev.get('provider', 'AI')
                model = ev.get('model', 'unknown')
                status = ev.get('status', 'Dispatched')
                dur = ev.get('duration_sec')
                dur_str = f" • {dur}s" if dur is not None else ""
                bytes_cnt = ev.get('byte_count', 0)
                title = f"[{ts}] [{provider}] {model} — {status}{dur_str} ({bytes_cnt} bytes)"
                item = QListWidgetItem(title)
                if '429' in status or 'Error' in status or 'Failed' in status:
                    item.setForeground(QColor('#E63946'))
                elif '200' in status or 'Complete' in status:
                    item.setForeground(QColor('#2A9D8F'))
                self.traffic_list.addItem(item)

            selected_index = next(
                (index for index, event in enumerate(events) if event.get('id') == selected_id),
                0,
            )
            self.traffic_list.setCurrentRow(selected_index)
        except Exception as e:
            self.lbl_traffic_meta.setText(_('Error reading traffic log: {}').format(str(e)))

    def clear_traffic_log(self) -> None:
        try:
            from calibre_plugins.ai_config.tweaks import clear_traffic_history
            clear_traffic_history()
            self.refresh_traffic_log()
        except Exception:
            pass

    def _on_traffic_item_selected(self, row: int) -> None:
        events = getattr(self, '_cached_traffic_events', [])
        if 0 <= row < len(events):
            ev = events[row]
            status_style = 'color: #E63946;' if ('Error' in ev.get('status', '') or '429' in ev.get('status', '')) else 'color: #2A9D8F;'
            dur_val = ev.get('duration_sec')
            dur_info = f"<b>Duration:</b> {dur_val}s &nbsp;|&nbsp; " if dur_val is not None else ""
            meta = (
                f"<b>Timestamp:</b> {ev.get('timestamp')} &nbsp;|&nbsp; "
                f"<b>Provider:</b> <code>{ev.get('provider')}</code> &nbsp;|&nbsp; "
                f"{dur_info}"
                f"<b>Status:</b> <span style='{status_style} font-weight: bold;'>{ev.get('status')}</span><br>"
                f"<b>Target Endpoint:</b> <code>{ev.get('url')}</code><br>"
                f"<b>Model:</b> <code>{ev.get('model')}</code><br>"
                f"<b>Headers:</b> <code>{ev.get('headers')}</code>"
            )
            self.lbl_traffic_meta.setText(meta)
            raw_json = ev.get('payload_json', '')
            try:
                parsed = json.loads(raw_json)
                formatted = json.dumps(parsed, indent=2)
            except Exception:
                formatted = raw_json

            response_prev = ev.get('response_preview', '')
            body_display = f"=== OUTGOING HTTP REQUEST BODY ===\n{formatted}"
            if response_prev:
                response_body = ev.get('response_json') or response_prev
                body_display += f"\n\n=== SERVER RESPONSE / ERROR DETAILS ===\n{response_body}"

            self.txt_traffic_body.setPlainText(body_display)
        else:
            self.lbl_traffic_meta.setText('')
            self.txt_traffic_body.setPlainText('')

    def copy_selected_payload(self) -> None:
        events = getattr(self, '_cached_traffic_events', [])
        row = self.traffic_list.currentRow()
        if 0 <= row < len(events):
            ev = events[row]
            raw_json = ev.get('payload_json', '')
            try:
                parsed = json.loads(raw_json)
                text = json.dumps(parsed, indent=2)
            except Exception:
                text = raw_json
        else:
            text = self.txt_traffic_body.toPlainText().strip()
        if text:
            app = QApplication.instance()
            if app:
                clipboard = app.clipboard()
                if clipboard:
                    clipboard.setText(text)
                    info_dialog(self, _('Copied'), _('Request JSON copied to clipboard.'), show=True)

    def copy_selected_response(self) -> None:
        events = getattr(self, '_cached_traffic_events', [])
        row = self.traffic_list.currentRow()
        if 0 <= row < len(events):
            ev = events[row]
            text = ev.get('response_text') or ev.get('response_json') or ev.get('response_preview') or ''
            if text:
                app = QApplication.instance()
                if app:
                    clipboard = app.clipboard()
                    if clipboard:
                        clipboard.setText(text)
                        info_dialog(self, _('Copied'), _('Server response copied to clipboard.'), show=True)
                        return
            info_dialog(
                self,
                _('No Response Available'),
                _('The selected request has not produced a server response yet.'),
                show=True,
            )
        else:
            info_dialog(
                self,
                _('No Request Selected'),
                _('Select a traffic entry before copying its server response.'),
                show=True,
            )

    def _on_web_search_toggled(self, checked: bool) -> None:
        self.edit_web_search_options.setEnabled(checked)
        self._validate_web_search_options()

    def _on_extra_body_toggled(self, checked: bool) -> None:
        self.edit_extra_body.setEnabled(checked)
        self.btn_format_json.setEnabled(checked)
        self.btn_reset_extra.setEnabled(checked)
        self._validate_extra_body_json()

    def _validate_web_search_options(self) -> bool:
        text = self.edit_web_search_options.text().strip()
        if not text:
            self.lbl_web_search_status.setText('')
            return True
        try:
            parsed = json.loads(text)
            if not isinstance(parsed, dict):
                self.lbl_web_search_status.setStyleSheet('QLabel { color: #E63946; }')
                self.lbl_web_search_status.setText(_('Error: Value must be a valid JSON object {...}'))
                return False
            self.lbl_web_search_status.setStyleSheet('QLabel { color: #2A9D8F; }')
            self.lbl_web_search_status.setText(_('Valid JSON object'))
            return True
        except Exception as e:
            self.lbl_web_search_status.setStyleSheet('QLabel { color: #E63946; }')
            self.lbl_web_search_status.setText(_('JSON syntax error: {}').format(str(e)))
            return False

    def _validate_extra_body_json(self) -> bool:
        text = self.edit_extra_body.toPlainText().strip()
        if not text:
            self.lbl_extra_status.setText('')
            return True
        try:
            parsed = json.loads(text)
            if not isinstance(parsed, dict):
                self.lbl_extra_status.setStyleSheet('QLabel { color: #E63946; }')
                self.lbl_extra_status.setText(_('Error: Value must be a valid JSON object {...}'))
                return False
            self.lbl_extra_status.setStyleSheet('QLabel { color: #2A9D8F; }')
            self.lbl_extra_status.setText(_('Valid JSON object ({} top-level keys)').format(len(parsed)))
            return True
        except Exception as e:
            self.lbl_extra_status.setStyleSheet('QLabel { color: #E63946; }')
            self.lbl_extra_status.setText(_('JSON syntax error: {}').format(str(e)))
            return False

    def _prettify_extra_body_json(self) -> None:
        text = self.edit_extra_body.toPlainText().strip()
        if not text:
            return
        try:
            parsed = json.loads(text)
            self.edit_extra_body.setPlainText(json.dumps(parsed, indent=2))
        except Exception as e:
            error_dialog(self, _('Invalid JSON'), _('Cannot format invalid JSON: {}').format(str(e)), show=True)

    def load_settings(self) -> None:
        # Legacy payload-tweak preferences are deliberately not loaded: calibre
        # now owns provider-native web search and the old mutation UI is retired.
        self._refresh_provider_info_label()
        self.refresh_traffic_log()

    def _refresh_provider_info_label(self) -> None:
        try:
            self._capture_profile_editor()
            active_id = self.profile_combo.currentData() or getattr(self, '_editing_profile_id', '') or getattr(self, '_profile_active_id', '')
            profile = next((item for item in getattr(self, '_profiles', ()) if item['id'] == active_id), active_ai_profile())

            backend = profile.get('backend', 'openai_compatible')
            backend_label = {
                'openai_compatible': _('OpenAI compatible'),
                'nvidia_api': _('NVIDIA API'),
                'anthropic_compatible': _('Anthropic compatible'),
            }.get(backend, _('OpenAI compatible'))

            api_url = profile.get('api_url') or (DEFAULT_NVIDIA_API_URL if backend == 'nvidia_api' else '')
            model_id = profile.get('text_model', '')
            profile_name = profile.get('name') or _('Unnamed profile')

            if api_url and model_id:
                msg = _('<b>Active Profile:</b> {0} ({1})<br>'
                        '<b>API Endpoint:</b> <code>{2}</code><br>'
                        '<b>Model:</b> <code>{3}</code>').format(profile_name, backend_label, api_url, model_id)
            elif api_url:
                msg = _('<b>Active Profile:</b> {0} ({1})<br>'
                        '<b>API Endpoint:</b> <code>{2}</code><br>'
                        '<b>Model:</b> <i>Not selected yet</i>').format(profile_name, backend_label, api_url)
            else:
                msg = _('<b>Active Profile:</b> {0} ({1})<br>'
                        '<b>Status:</b> <i>API URL has not been configured yet.</i>').format(profile_name, backend_label)
            self.lbl_provider_info.setText(msg)
        except Exception as e:
            self.lbl_provider_info.setText(_('Could not read AI profile configuration: {}').format(str(e)))

    def validate(self) -> bool:
        return True

    def save_settings(self) -> None:
        if not self.validate():
            return
        self._save_toolbar_action_settings()
        self._save_profile_settings()
        plugin_prefs.commit()

        # Re-apply patch to ensure live running sessions pick up updated configuration immediately
        try:
            from calibre_plugins.ai_config.tweaks import apply_ai_tweaks_patch
            apply_ai_tweaks_patch()
        except Exception:
            pass

    def _save_toolbar_action_settings(self) -> None:
        try:
            key = self.toolbar_action_combo.currentData()
        except Exception:
            key = DEFAULT_SELECTED_ACTION
        plugin_prefs[KEY_SELECTED_ACTION] = normalise_toolbar_action_key(str(key or ''))

    def build_sample_payload(self) -> dict[str, Any]:
        prompt = self.edit_test_prompt.text().strip() or 'Tell me something genuinely fascinating that most people don\'t know about. Answer in English.'
        self._capture_profile_editor()
        active_id = self.profile_combo.currentData() or getattr(self, '_editing_profile_id', '') or getattr(self, '_profile_active_id', '')
        profile = next((item for item in getattr(self, '_profiles', ()) if item['id'] == active_id), active_ai_profile())
        model_id = profile.get('text_model') or ''
        backend = profile.get('backend')

        if backend == 'anthropic_compatible':
            data: dict[str, Any] = {
                'model': model_id or '<automatic model choice>',
                'max_tokens': 4096,
                'messages': [{'role': 'user', 'content': prompt}],
                'stream': True,
            }
            if profile.get('allow_web_searches'):
                data['tools'] = [{'type': 'web_search_20250305', 'name': 'web_search'}]
        else:
            data = {
                'model': model_id or 'gpt-4o',
                'messages': [{'role': 'user', 'content': prompt}],
                'stream': True,
                'temperature': float(profile.get('temperature', 0.7)),
            }
            if backend == 'nvidia_api':
                data['max_tokens'] = 4096

        return data

    def update_payload_preview(self) -> None:
        payload = self.build_sample_payload()
        formatted = json.dumps(payload, indent=2)
        self.txt_output_viewer.setPlainText(
            _('--- Outgoing HTTP Request Simulation ---\n\n') + formatted
        )

    def _current_editing_profile(self) -> dict[str, Any]:
        self._capture_profile_editor()
        active_id = self.profile_combo.currentData() or getattr(self, '_editing_profile_id', '') or getattr(self, '_profile_active_id', '')
        return next((item for item in getattr(self, '_profiles', ()) if item['id'] == active_id), active_ai_profile())

    def _fill_model_discovery_from_current_profile(self) -> None:
        profile = self._current_editing_profile()
        api_url = profile.get('api_url') or (DEFAULT_NVIDIA_API_URL if profile.get('backend') == 'nvidia_api' else '')
        self.model_discovery_url_combo.setEditText(api_url)
        self.model_discovery_key_edit.setText(profile_plain_api_key(profile))

    def _model_discovery_endpoint_history(self) -> list[str]:
        raw = plugin_prefs.get(KEY_MODEL_DISCOVERY_ENDPOINT_HISTORY, [])
        if not isinstance(raw, list):
            return []
        seen = set()
        history = []
        for item in raw:
            url = str(item or '').strip()
            if url and url not in seen:
                history.append(url)
                seen.add(url)
        return history[:12]

    def _save_model_discovery_endpoint_history(self, history: list[str]) -> None:
        plugin_prefs[KEY_MODEL_DISCOVERY_ENDPOINT_HISTORY] = history[:12]
        plugin_prefs.commit()

    def _refresh_model_discovery_endpoint_history(self, keep_text: str) -> None:
        combo = self.model_discovery_url_combo
        try:
            combo.blockSignals(True)
            combo.clear()
            history = self._model_discovery_endpoint_history()
            for url in history:
                combo.addItem(url)
            if history:
                try:
                    combo.insertSeparator(combo.count())
                except Exception:
                    pass
                combo.addItem(_('Clear history'), '__clear_model_discovery_endpoint_history__')
            combo.setEditText(keep_text or '')
        finally:
            try:
                combo.blockSignals(False)
            except Exception:
                pass

    def _commit_model_discovery_endpoint_history(self) -> None:
        url = self.model_discovery_url_combo.currentText().strip()
        if not url:
            return
        history = self._model_discovery_endpoint_history()
        if url in history:
            history.remove(url)
        history.insert(0, url)
        self._save_model_discovery_endpoint_history(history)
        self._refresh_model_discovery_endpoint_history(url)

    def _on_model_discovery_endpoint_activated(self, index: int) -> None:
        try:
            if self.model_discovery_url_combo.itemData(index) == '__clear_model_discovery_endpoint_history__':
                self._save_model_discovery_endpoint_history([])
                self._refresh_model_discovery_endpoint_history('')
        except Exception:
            pass

    def fetch_openai_compatible_models(self) -> None:
        api_url = self.model_discovery_url_combo.currentText().strip()
        api_key = self.model_discovery_key_edit.text().strip()
        if not api_url:
            error_dialog(self, _('No Endpoint URL'), _('Please enter an OpenAI-compatible endpoint URL.'), show=True)
            return
        self._commit_model_discovery_endpoint_history()
        self.btn_fetch_models.setEnabled(False)
        self.btn_fill_model_discovery_from_profile.setEnabled(False)
        self.lbl_model_discovery_status.setText(_('Fetching models...'))
        self.txt_output_viewer.setPlainText(_('Fetching model list from endpoint...\n'))
        self._model_discovery_worker = OpenAIModelDiscoveryWorker(api_url, api_key, self)
        self._model_discovery_worker.finished_result.connect(self._on_model_discovery_finished)
        self._model_discovery_worker.start()

    def _on_model_discovery_finished(self, success: bool, text: str) -> None:
        self.txt_output_viewer.setPlainText(text)
        self.lbl_model_discovery_status.setText(_('Models fetched') if success else _('Model fetch failed'))
        self.btn_fetch_models.setEnabled(True)
        self.btn_fill_model_discovery_from_profile.setEnabled(True)

    def run_live_test_request(self) -> None:
        if not self.validate():
            return
        prompt = self.edit_test_prompt.text().strip()
        if not prompt:
            error_dialog(self, _('No Prompt'), _('Please enter a test prompt to send.'), show=True)
            return

        self._save_profile_settings()
        self.btn_test_live.setEnabled(False)
        self.btn_preview_payload.setEnabled(False)
        self.btn_cancel_test.setEnabled(True)
        self.btn_cancel_test.setVisible(True)

        profile_name = self.profile_combo.currentText().split(' — ', 1)[0]
        self.txt_output_viewer.setPlainText(
            _('Sending test request using profile: {0}...\n\n').format(profile_name)
        )
        self.lbl_test_status.setText(_('Connecting...'))

        active_id = self.profile_combo.currentData() or getattr(self, '_editing_profile_id', '') or getattr(self, '_profile_active_id', '')
        profile = next((item for item in getattr(self, '_profiles', ()) if item['id'] == active_id), active_ai_profile())

        self._test_worker = TestRequestWorker(prompt, profile, self)
        self._test_worker.chunk_received.connect(self._on_test_chunk_received)
        self._test_worker.status_updated.connect(self._on_test_status_updated)
        self._test_worker.finished_result.connect(self._on_test_finished_result)
        self._test_worker.start()

    def _on_test_chunk_received(self, text: str) -> None:
        self.txt_output_viewer.insertPlainText(text)
        sb = self.txt_output_viewer.verticalScrollBar()
        if sb:
            sb.setValue(sb.maximum())

    def _on_test_status_updated(self, status: str) -> None:
        self.lbl_test_status.setText(status)

    def _on_test_finished_result(self, success: bool, msg: str) -> None:
        self.txt_output_viewer.append(msg)
        sb = self.txt_output_viewer.verticalScrollBar()
        if sb:
            sb.setValue(sb.maximum())
        self.lbl_test_status.setText(_('Completed') if success else _('Finished with notice/error'))
        self.btn_test_live.setEnabled(True)
        self.btn_preview_payload.setEnabled(True)
        self.btn_cancel_test.setEnabled(False)
        self.btn_cancel_test.setVisible(False)
        self.refresh_traffic_log()

    def _cancel_live_test_request(self) -> None:
        if hasattr(self, '_test_worker') and self._test_worker is not None and self._test_worker.isRunning():
            self.lbl_test_status.setText(_('Stopping...'))
            self._test_worker.abort()


class AIConfigDialog(QDialog):
    """Full-featured configuration dialog for the AI Config plugin,
    containing all features merged from the former AI Tweaks plugin."""

    def __init__(self, parent: QWidget | None = None, icon: QIcon | None = None, settings_applied=None):
        super().__init__(parent)
        self._settings_applied = settings_applied
        self.setStyleSheet(ccr_scrollbar_stylesheet() + ccr_combo_stylesheet())
        self.setWindowTitle(_('Configure AI Config'))
        if icon is not None:
            self.setWindowIcon(icon)

        self.zoom_filter = CtrlWheelZoomFilter(self)
        self.installEventFilter(self.zoom_filter)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # Main config widget
        self.config_widget = ConfigWidget(self)
        layout.addWidget(self.config_widget)
        try:
            app = QApplication.instance()
            if app and hasattr(app, 'palette_changed'):
                app.palette_changed.connect(self._refresh_version_info_styles)
                app.palette_changed.connect(self.config_widget._refresh_tab_stylesheet)
        except Exception:
            pass

        # Dialog footer: Version info widget on the left, buttons on the right
        footer = QHBoxLayout()
        footer.setContentsMargins(0, 4, 0, 0)
        footer.setSpacing(8)

        footer.addWidget(self._create_version_info_widget())
        footer.addStretch(1)

        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel |
            QDialogButtonBox.StandardButton.Apply,
            self,
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        apply_btn = self.button_box.button(QDialogButtonBox.StandardButton.Apply)
        if apply_btn:
            apply_btn.clicked.connect(self.apply_changes)

        footer.addWidget(self.button_box)
        layout.addLayout(footer)

        self.setMinimumSize(720, 520)
        self.resize(720, 560)

    def _create_version_info_widget(self) -> QWidget:
        widget = QWidget(self)
        info_layout = QVBoxLayout(widget)
        info_layout.setContentsMargins(6, 2, 6, 2)
        info_layout.setSpacing(2)
        plugin_text = _('AI Config v.{}').format(_plugin_version_text())
        calibre_text = _('Calibre {}').format(_calibre_version_text())
        self.version_info_label = QLabel(f'{plugin_text} | {calibre_text}', widget)
        info_layout.addWidget(self.version_info_label)
        self.version_info_widget = widget
        self._refresh_version_info_styles()
        return widget

    def _refresh_version_info_styles(self) -> None:
        if _is_dark_theme(self):
            meta_color = '#B6C5D9'
            border_color = '#4C6486'
            background_color = 'rgba(112, 146, 190, 0.12)'
        else:
            meta_color = '#445A77'
            border_color = '#9FB2C8'
            background_color = 'rgba(56, 93, 138, 0.08)'

        if hasattr(self, 'version_info_widget') and self.version_info_widget is not None:
            self.version_info_widget.setStyleSheet(
                f'QWidget {{ background-color: {background_color}; border: 1px solid {border_color}; border-radius: 4px; }}'
                'QWidget QLabel { background: transparent; border: none; }'
            )
        if hasattr(self, 'version_info_label') and self.version_info_label is not None:
            self.version_info_label.setStyleSheet(
                f'QLabel {{ color: {meta_color}; font-size: 8pt; padding: 2px 4px; font-weight: 600; }}'
            )

    def apply_changes(self) -> bool:
        if not self.config_widget.validate():
            return False
        self.config_widget.save_settings()
        if self._settings_applied is not None:
            try:
                self._settings_applied()
            except Exception:
                pass
        return True

    def accept(self) -> None:
        if self.apply_changes():
            super().accept()
