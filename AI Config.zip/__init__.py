#!/usr/bin/env python
__license__   = 'GPL v3'
__copyright__ = '2025, Comfy.n'
__docformat__ = 'restructuredtext en'

from calibre.customize import InterfaceActionBase

load_translations()

class AIConfig(InterfaceActionBase):
    name = 'AI Config'
    description = _('Quick access to AI settings, with named OpenAI-compatible and NVIDIA API profiles, payload tweaks, web search options and traffic inspection')
    supported_platforms = ['windows', 'osx', 'linux']
    author = 'Comfy.n'
    version = (2, 0, 0)
    minimum_calibre_version = (8, 16, 2)
    actual_plugin = 'calibre_plugins.ai_config.action:AIConfigAction'

    def is_customizable(self):
        return True

    def config_widget(self):
        from calibre_plugins.ai_config.tweaks_config import ConfigWidget
        return ConfigWidget()

    def save_settings(self, config_widget):
        if hasattr(config_widget, 'save_settings'):
            config_widget.save_settings()
        return True

    def initialize(self):
        # Call parent initialize first to register the plugin with calibre
        result = super().initialize()

        try:
            from . import common_icons
            import os

            resources = {}
            icon_paths = [
                'images/iconplugin_dark.png',
                'images/iconplugin_light.png',
                'images/iconplugin2_dark.png',
                'images/iconplugin2_light.png',
                'images/iconplugin3_dark.png',
                'images/iconplugin3_light.png',
                'images/qrcode.png',
                'images/openrouter_icon.png',
                'images/google_icon.png',
                'images/github_icon.png',
                'images/ollama_icon.png',
                'images/lm_studio_icon.png',
                'images/open_ai_icon.png',
                'images/open_ai_compatible_icon.png',
                'images/anthropic_icon.png',
                'images/grok_icon.png',
                'images/veniceai_icon.png',
                'images/default_provider_icon.png',
            ]

            plugin_path = getattr(self, 'plugin_path', None)
            if plugin_path and os.path.isfile(plugin_path):
                try:
                    from calibre.utils.zipfile import ZipFile
                    with ZipFile(plugin_path, 'r') as zf:
                        for p in icon_paths:
                            try:
                                with zf.open(p, 'r') as f:
                                    resources[p] = f.read()
                            except Exception:
                                pass
                except Exception:
                    pass

            # Fallback to local files if any resources are still missing
            for p in icon_paths:
                if p not in resources:
                    local_p = os.path.join(os.path.dirname(__file__), p.replace('/', os.sep))
                    if os.path.exists(local_p):
                        try:
                            with open(local_p, 'rb') as f:
                                resources[p] = f.read()
                        except Exception:
                            pass

            common_icons.set_plugin_icon_resources(self.name, resources)
        except Exception:
            # non-fatal: don't prevent plugin loading if we cannot extract icons
            pass

        return result
