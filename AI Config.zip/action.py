# Debug control
DEBUG_AI_CONFIG = False  # Set True to enable debug logs
#!/usr/bin/env python
__license__   = 'GPL v3'
__copyright__ = '2025, Comfy.n'
__docformat__ = 'restructuredtext en'
# -*- coding: utf-8 -*-

from qt.core import QApplication
"""
AI Config plugin - toolbar button with theme-aware icon and action selector
"""

from functools import partial
from typing import Any
from qt.core import QDialog, QIcon, QMenu, QToolButton, QVBoxLayout, QHBoxLayout, QLabel, QDialogButtonBox, QWidget, Qt
from calibre.gui2.actions import InterfaceAction
from calibre.gui2 import Application, gprefs, open_url
from calibre.constants import numeric_version as calibre_version
from calibre.utils.localization import _
from calibre.ai import AICapabilities
from calibre.ai.prefs import plugin_for_purpose, pref_for_provider, prefs
from . import common_icons
from .tweaks_config import (
    KEY_SELECTED_ACTION,
    plugin_prefs,
    _plugin_version_text,
    _calibre_version_text,
    cyoa_disabled_tooltip,
    cyoa_menu_enabled,
    normalise_toolbar_action_key,
    toolbar_action_choices,
)

try:
    load_translations()
except NameError:
    pass

try:
    _
except NameError:
    def _(msg):
        return msg

ACTION_CALLBACKS = {
    'ai_settings_viewer': 'open_ai_settings_viewer',
    'ai_settings_library': 'open_ai_settings_library',
    'cover_generation_settings': 'open_cover_generation_settings',
    'cyoa_settings': 'open_cyoa_settings',
}

ACTION_DESCRIPTIONS = {
    'ai_settings_viewer': _('Open E-book viewer AI settings from the main button'),
    'ai_settings_library': _('Open Main AI settings from the main button'),
    'cover_generation_settings': _('Open Cover generation AI settings from the main button'),
    'cyoa_settings': _('Open Create Your Own Adventure AI settings from the main button'),
}

ACTION_MENU_LABELS = {
    'ai_settings_viewer': _('AI Config: E-book viewer settings'),
    'ai_settings_library': _('AI Config: Main settings'),
    'cover_generation_settings': _('AI Config: Cover generation settings'),
    'cyoa_settings': _('AI Config: Game settings'),
}


def _build_actions():
    return [
        dict(
            choice,
            callback=ACTION_CALLBACKS[choice['key']],
            description=ACTION_DESCRIPTIONS.get(choice['key'], ''),
            requires_cyoa=choice['key'] == 'cyoa_settings',
        )
        for choice in toolbar_action_choices()
    ]


ACTIONS = _build_actions()


def _is_dark_theme() -> bool:
    try:
        app = QApplication.instance()
        if not app:
            return False
        pal = app.palette()
        window_color = pal.color(pal.ColorRole.Window)
        text_color = pal.color(pal.ColorRole.WindowText)
        return text_color.lightness() > window_color.lightness()
    except Exception:
        return False


SUPPORT_URL = 'https://www.mobileread.com/forums/showthread.php?t=371037'
DONATE_URL = 'https://ko-fi.com/comfy_n'


def _get_qrcode_pixmap(size: int = 140):
    """Return the plugin's qrcode.png as a QPixmap scaled to the requested size."""
    try:
        pm = common_icons.get_pixmap('images/qrcode.png')
        if pm is not None and not pm.isNull():
            return pm.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
    except Exception:
        pass
    try:
        local_path = os.path.join(os.path.dirname(__file__), 'images', 'qrcode.png')
        if os.path.exists(local_path):
            pm = QPixmap()
            if pm.load(local_path) and not pm.isNull():
                return pm.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                                 Qt.TransformationMode.SmoothTransformation)
    except Exception:
        pass
    return None


class AIConfigAboutDialog(QDialog):
    """Small About dialog for AI Config — mirrors the EBD AboutDialog pattern."""

    def __init__(self, action, parent=None):
        super().__init__(parent)
        self._action = action
        self.setWindowTitle(_('About {}').format(action.name))
        try:
            icon = None
            if getattr(action, 'qaction', None) is not None:
                icon = action.qaction.icon()
            if icon is not None and (not hasattr(icon, 'isNull') or not icon.isNull()):
                self.setWindowIcon(icon)
        except Exception:
            pass
        self.setModal(False)
        self.resize(460, 410)
        self._restore_geometry()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        description = _('Quick access to AI provider settings, named provider profiles, '
                        'live testing and traffic inspection.')
        html = (
            '<style>a {{ text-decoration: none; }}</style>'
            '<div align="center">'
            '<h2>{name}</h2>'
            '<p>{description}</p>'
            '<p style="font-size:11pt;"><a href="{support}">' + _('MobileRead Forums') + '</a></p>'
            '<p style="font-size:12pt;">&#10084; <a href="{donate}">' + _('Gift me some recognition') + '</a></p>'
            '</div>'
        ).format(
            name=action.name,
            description=description,
            support=SUPPORT_URL,
            donate=DONATE_URL,
        )

        text_label = QLabel(html, self)
        text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        text_label.setWordWrap(True)
        text_label.setTextFormat(Qt.TextFormat.RichText)
        text_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        text_label.setOpenExternalLinks(False)
        try:
            text_label.linkActivated.connect(open_url)
        except Exception:
            pass
        layout.addWidget(text_label)

        # QR Code (links to ko-fi donation page)
        qr = QLabel(self)
        qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        qr.setMinimumSize(96, 96)
        try:
            pm = _get_qrcode_pixmap(140)
            if pm is not None and not pm.isNull():
                qr.setPixmap(pm)
                qr.setCursor(Qt.CursorShape.PointingHandCursor)
                qr.setToolTip(_('Open donation support'))
                qr.mousePressEvent = lambda _ev: open_url(DONATE_URL)
        except Exception:
            pass
        layout.addWidget(qr, 0, Qt.AlignmentFlag.AlignCenter)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, self)
        buttons.rejected.connect(self.close)
        footer = QHBoxLayout()
        footer.setContentsMargins(0, 0, 0, 0)
        footer.setSpacing(8)
        footer.addWidget(self._create_version_label())
        footer.addStretch(1)
        footer.addWidget(buttons)
        layout.addLayout(footer)

    def _create_version_label(self):
        widget = QWidget(self)
        vl = QVBoxLayout(widget)
        vl.setContentsMargins(6, 2, 6, 2)
        vl.setSpacing(2)
        plugin_text = _('{} v.{}').format(self._action.name, _plugin_version_text())
        calibre_text = _('Calibre {}').format(_calibre_version_text())
        lbl = QLabel(f'{plugin_text} | {calibre_text}', widget)
        vl.addWidget(lbl)
        is_dark = _is_dark_theme()
        if is_dark:
            meta_color = '#B6C5D9'
            border_color = '#4C6486'
            background_color = 'rgba(112, 146, 190, 0.12)'
        else:
            meta_color = '#445A77'
            border_color = '#9FB2C8'
            background_color = 'rgba(56, 93, 138, 0.08)'
        widget.setStyleSheet(
            f'QWidget {{ background-color: {background_color}; border: 1px solid {border_color}; border-radius: 4px; }}'
            'QWidget QLabel { background: transparent; border: none; }'
        )
        lbl.setStyleSheet(f'QLabel {{ color: {meta_color}; font-size: 8pt; padding: 2px 4px; font-weight: 600; }}')
        return widget

    def _restore_geometry(self):
        try:
            geom = gprefs.get('ai_config_about_dialog_geometry')
            if geom:
                self.restoreGeometry(geom)
            if int(self.height() or 0) < 410:
                self.resize(int(self.width() or 460), 410)
        except Exception:
            pass

    def closeEvent(self, event):
        try:
            gprefs['ai_config_about_dialog_geometry'] = bytearray(self.saveGeometry())
        except Exception:
            pass
        super().closeEvent(event)


class AIConfigAction(InterfaceAction):
    """Toolbar action. Use action_spec so Calibre will register the action and
    prompt for toolbar placement on first install (same pattern as KoboTouch).
    """
    name = 'AI Config'
    # (text, icon, tooltip, keyboard shortcut)
    action_spec = (_('AI Config'), None, _('Quick access to AI settings'), None)
    # Ensure Calibre renders the popup arrow on the toolbar button
    action_add_menu = True
    popup_type = QToolButton.ToolButtonPopupMode.MenuButtonPopup
    action_type = 'current'
    action_menu_clone_qaction = True

    def genesis(self):
        # Apply merged AI Tweaks monkey-patches to calibre AI backends immediately
        try:
            from .tweaks import apply_ai_tweaks_patch
            apply_ai_tweaks_patch()
        except Exception:
            import traceback
            traceback.print_exc()

        self._about_dialog = None

        # Load plugin icon resources and make available to common_icons
        try:
            resources = self.load_resources([
                'images/iconplugin_dark.png',
                'images/iconplugin_light.png',
                'images/iconplugin2_dark.png',
                'images/iconplugin2_light.png',
                'images/iconplugin3_dark.png',
                'images/iconplugin3_light.png',
                'images/iconplugin4_dark.png',
                'images/iconplugin4_light.png',
                'images/icon_cyoa.png',
                'images/qrcode.png',
                'images/openrouter_icon.png',
                'images/google_icon.png',
                'images/github_icon.png',
                'images/ollama_icon.png',
                'images/lm_studio_icon.png',
                'images/open_ai_icon.png',
                'images/open_ai_compatible_icon.png',
                'images/anthropic_icon.png',
                'images/grok_icon.png',
                'images/veniceai_icon.png',
                'images/default_provider_icon.png',
            ])
        except Exception:
            resources = {}
        if resources:
            common_icons.set_plugin_icon_resources(self.name, resources)

        # Load persisted selection
        self.selected_action = normalise_toolbar_action_key(plugin_prefs.get(KEY_SELECTED_ACTION, ACTIONS[0]['key']))
        # Ensure qaction exists (InterfaceAction provides it via action_spec)
        # Set initial icon/tooltip
        self.rebuild_icon()
        # Update icon when the application palette (theme) changes
        try:
            app = Application.instance()
            if app:
                app.palette_changed.connect(self.rebuild_icon)
        except Exception:
            pass
        self.qaction.triggered.connect(self.trigger_selected_action)

        # Build selector menu and attach to the QAction so the toolbar button has a menu
        self.menu = self._build_menu()
        self.menu.aboutToShow.connect(self._on_menu_about_to_show)
        self.menu.aboutToHide.connect(self._on_menu_about_to_hide)
        self.update_current_provider()
        self._update_tooltip()
        try:
            # QAction has setMenu in newer Qt versions used by calibre
            self.qaction.setMenu(self.menu)
        except Exception:
            # Fallback: nothing — menu will still be accessible via context menu
            pass

        # Register hidden actions for direct shortcuts to each dialog (for accessibility)
        try:
            from qt.core import QAction
            self._viewer_action = QAction(ACTION_MENU_LABELS['ai_settings_viewer'], self.gui)
            self._viewer_action.triggered.connect(self.open_ai_settings_viewer)
            self.gui.addAction(self._viewer_action)
            self.gui.keyboard.register_shortcut('ai_config_viewer', ACTION_MENU_LABELS['ai_settings_viewer'], default_keys=(), action=self._viewer_action, description=ACTION_MENU_LABELS['ai_settings_viewer'], group=self.action_spec[0])

            self._main_action = QAction(ACTION_MENU_LABELS['ai_settings_library'], self.gui)
            self._main_action.triggered.connect(self.open_ai_settings_library)
            self.gui.addAction(self._main_action)
            self.gui.keyboard.register_shortcut('ai_config_main', ACTION_MENU_LABELS['ai_settings_library'], default_keys=(), action=self._main_action, description=ACTION_MENU_LABELS['ai_settings_library'], group=self.action_spec[0])

            if calibre_version >= (9, 14, 0):
                self._cover_action = QAction(ACTION_MENU_LABELS['cover_generation_settings'], self.gui)
                self._cover_action.triggered.connect(self.open_cover_generation_settings)
                self.gui.addAction(self._cover_action)
                self.gui.keyboard.register_shortcut('ai_config_cover_generation', ACTION_MENU_LABELS['cover_generation_settings'], default_keys=(), action=self._cover_action, description=ACTION_MENU_LABELS['cover_generation_settings'], group=self.action_spec[0])

            self._cyoa_action = QAction(ACTION_MENU_LABELS['cyoa_settings'], self.gui)
            self._cyoa_action.setEnabled(cyoa_menu_enabled())
            self._cyoa_action.triggered.connect(self.open_cyoa_settings)
            self.gui.addAction(self._cyoa_action)
            self.gui.keyboard.register_shortcut('ai_config_cyoa_settings', ACTION_MENU_LABELS['cyoa_settings'], default_keys=(), action=self._cyoa_action, description=_('Open Create Your Own Adventure AI settings'), group=self.action_spec[0])

            self._cyoa_game_action = QAction(_('AI Config: Launch CYOA game'), self.gui)
            self._cyoa_game_action.setEnabled(cyoa_menu_enabled())
            self._cyoa_game_action.triggered.connect(self.open_cyoa)
            self.gui.addAction(self._cyoa_game_action)
            self.gui.keyboard.register_shortcut('ai_config_cyoa', _('AI Config: Launch CYOA game'), default_keys=(), action=self._cyoa_game_action, description=_('Open Create Your Own Adventure'), group=self.action_spec[0])
        except Exception:
            pass

        # No-op: Refresh is now built into _build_menu

    def rebuild_icon(self):
        # Use theme-aware get_icon; fall back gracefully
        icon_name = self._get_selected()['icon']
        try:
            icon = common_icons.get_icon(icon_name)
            self.qaction.setIcon(icon)
        except Exception:
            pass

    def _open_text_settings(self):
        """Open the active text AI settings dialog."""
        if self.selected_action == 'ai_settings_viewer':
            self.open_ai_settings_viewer()
        else:
            self.open_ai_settings_library()

    def _open_selected_settings(self):
        """Open the settings dialog for the currently selected action."""
        sel = self._get_selected()
        cb = getattr(self, sel['callback'], None)
        if cb:
            try:
                cb()
            except Exception:
                import traceback
                traceback.print_exc()

    def _build_menu(self):
        from qt.core import QWidgetAction, QLabel, QHBoxLayout, QWidget, QStyle
        menu = QMenu(self.gui)
        try:
            menu.setToolTipsVisible(True)
        except Exception:
            pass
        # Make the provider area (static label) reliably influence menu width.
        # QLabel word-wrapping can produce a very small sizeHint(), so QMenu
        # may not widen even if you call setMinimumWidth().
        from qt.core import QSize
        provider_min_width = plugin_prefs.get('provider_menu_min_width', 460)

        class _ProviderWidget(QWidget):
            def __init__(self, parent, min_w):
                super().__init__(parent)
                self._min_w = int(min_w) if min_w else 0

            def sizeHint(self):
                sh = super().sizeHint()
                return QSize(max(int(sh.width()), self._min_w), int(sh.height()))

            def minimumSizeHint(self):
                sh = super().minimumSizeHint()
                return QSize(max(int(sh.width()), self._min_w), int(sh.height()))

        # Custom widget for current provider (colored icons + text + copy)
        widget = _ProviderWidget(menu, provider_min_width)
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(8)
        from qt.core import Qt, QObject, QEvent, QVBoxLayout
        from qt.core import QPushButton, QClipboard

        rows_container = QWidget(widget)
        rows_layout = QVBoxLayout(rows_container)
        rows_layout.setContentsMargins(0, 0, 0, 0)
        rows_layout.setSpacing(4)

        class _ClickFilter(QObject):
            def __init__(self, callback):
                super().__init__()
                self.callback = callback

            def eventFilter(self, obj, ev):
                try:
                    if ev.type() == QEvent.Type.MouseButtonRelease and ev.button() == Qt.MouseButton.LeftButton:
                        self.callback()
                        return True
                except Exception:
                    return False
                return False

        # Text row
        text_row = QWidget(rows_container)
        text_layout = QHBoxLayout(text_row)
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(6)
        text_row.setCursor(Qt.PointingHandCursor)

        self.provider_icon_label = QLabel(text_row)
        self.provider_icon_label.setFixedSize(18, 18)
        self.provider_icon_label.setScaledContents(True)

        self.provider_text_label = QLabel(text_row)
        self.provider_text_label.setWordWrap(True)
        self.provider_text_label.setStyleSheet('QLabel { font-size: 11px; } QLabel:hover { text-decoration: underline; }')
        self.provider_text_label.setCursor(Qt.PointingHandCursor)
        try:
            self.provider_text_label.setTextInteractionFlags(Qt.NoTextInteraction)
        except Exception:
            pass

        text_layout.addWidget(self.provider_icon_label)
        text_layout.addWidget(self.provider_text_label, 1)
        text_row.setLayout(text_layout)

        self._text_click_filter = _ClickFilter(self._open_text_settings)
        for w in (text_row, self.provider_icon_label, self.provider_text_label):
            try:
                w.installEventFilter(self._text_click_filter)
            except Exception:
                pass
        rows_layout.addWidget(text_row)

        # Cover row (if calibre supports cover generation)
        if calibre_version >= (9, 14, 0):
            cover_row = QWidget(rows_container)
            cover_layout = QHBoxLayout(cover_row)
            cover_layout.setContentsMargins(0, 0, 0, 0)
            cover_layout.setSpacing(6)
            cover_row.setCursor(Qt.PointingHandCursor)

            self.provider_cover_icon_label = QLabel(cover_row)
            self.provider_cover_icon_label.setFixedSize(18, 18)
            self.provider_cover_icon_label.setScaledContents(True)

            self.provider_cover_label = QLabel(cover_row)
            self.provider_cover_label.setWordWrap(True)
            self.provider_cover_label.setStyleSheet('QLabel { font-size: 11px; } QLabel:hover { text-decoration: underline; }')
            self.provider_cover_label.setCursor(Qt.PointingHandCursor)
            try:
                self.provider_cover_label.setTextInteractionFlags(Qt.NoTextInteraction)
            except Exception:
                pass

            cover_layout.addWidget(self.provider_cover_icon_label)
            cover_layout.addWidget(self.provider_cover_label, 1)
            cover_row.setLayout(cover_layout)

            self._cover_click_filter = _ClickFilter(self.open_cover_generation_settings)
            for w in (cover_row, self.provider_cover_icon_label, self.provider_cover_label):
                try:
                    w.installEventFilter(self._cover_click_filter)
                except Exception:
                    pass
            rows_layout.addWidget(cover_row)

        # Game image row (if calibre supports the CYOA game)
        if cyoa_menu_enabled():
            game_row = QWidget(rows_container)
            game_layout = QHBoxLayout(game_row)
            game_layout.setContentsMargins(0, 0, 0, 0)
            game_layout.setSpacing(6)
            game_row.setCursor(Qt.PointingHandCursor)

            self.provider_game_icon_label = QLabel(game_row)
            self.provider_game_icon_label.setFixedSize(18, 18)
            self.provider_game_icon_label.setScaledContents(True)

            self.provider_game_label = QLabel(game_row)
            self.provider_game_label.setWordWrap(True)
            self.provider_game_label.setStyleSheet('QLabel { font-size: 11px; } QLabel:hover { text-decoration: underline; }')
            self.provider_game_label.setCursor(Qt.PointingHandCursor)
            try:
                self.provider_game_label.setTextInteractionFlags(Qt.NoTextInteraction)
            except Exception:
                pass

            game_layout.addWidget(self.provider_game_icon_label)
            game_layout.addWidget(self.provider_game_label, 1)
            game_row.setLayout(game_layout)

            self._game_click_filter = _ClickFilter(self.open_cyoa_settings)
            for w in (game_row, self.provider_game_icon_label, self.provider_game_label):
                try:
                    w.installEventFilter(self._game_click_filter)
                except Exception:
                    pass
            rows_layout.addWidget(game_row)

        rows_container.setLayout(rows_layout)

        self.copy_button = QPushButton('📋', widget)
        self.copy_button.setToolTip(_('Copy provider information to clipboard'))
        self.copy_button.setFixedSize(22, 22)
        self.copy_button.setStyleSheet('QPushButton { border: none; background: transparent; font-size: 13px; } QPushButton:hover { background: #e0e0e0; }')
        def copy_text():
            parts = [self.provider_text_label.text()]
            if hasattr(self, 'provider_cover_label') and self.provider_cover_label.text():
                parts.append(self.provider_cover_label.text())
            if hasattr(self, 'provider_game_label') and self.provider_game_label.text():
                parts.append(self.provider_game_label.text())
            clipboard = QApplication.clipboard()
            clipboard.setText('\n'.join(p for p in parts if p))
        self.copy_button.clicked.connect(copy_text)

        layout.addWidget(rows_container, 1)
        layout.addWidget(self.copy_button, 0, Qt.AlignmentFlag.AlignVCenter)
        widget.setLayout(layout)
        # Keep a reference so update_current_provider can optionally tweak it
        self._provider_widget = widget
        wa = QWidgetAction(menu)
        wa.setDefaultWidget(widget)
        wa.setVisible(False)
        menu.addAction(wa)
        # Menu experiment toggle:
        # 0 = default (Discuss entry after settings, as implemented earlier)
        # 1 = insert "Discuss book with AI" immediately after the provider widget
        # 2 = same as 1, but set a fixed widget width to try to influence menu anchor
        menu_experiment = plugin_prefs.get('ai_menu_experiment', 0)
        if menu_experiment in (1, 2):
            try:
                # Optionally increase widget width for experiment mode 2
                if menu_experiment == 1:
                    try:
                        widget.setFixedWidth(500)
                    except Exception:
                        pass
                # Try to get icon for the discuss action
                try:
                    icon = common_icons.get_icon('ai.png')
                except Exception:
                    icon = None
                if icon:
                    discuss_act = menu.addAction(icon, _('Discuss book with AI'))
                else:
                    discuss_act = menu.addAction(_('Discuss book with AI'))
                discuss_act.triggered.connect(lambda checked=False: self._trigger_discuss_book())
                self._add_generate_cover_action(menu)
            except Exception:
                pass
            menu.addSeparator()
        else:
            menu.addSeparator()
        # Also apply a minimum width to the menu itself
        try:
            menu.setMinimumWidth(int(provider_min_width))
        except Exception:
            pass
        # Reinstate orange hover effect for menu items
        menu.setStyleSheet('''
            QMenu::item:selected {
                background-color: #ffd580;
                color: #000000;
            }
        ''')
        try:
            selected = self._get_selected()
            default_icon = common_icons.get_icon(selected['icon'])
        except Exception:
            selected = self._get_selected()
            default_icon = QIcon()
        default_act = menu.addAction(default_icon, _('Button click: {}').format(selected.get('label', '')))
        default_act.setEnabled(False)

        # Add menu entries below the status row: Discuss first, then AI Generate
        # cover, then a separator before the AI Config settings entries.
        try:
            menu.addSeparator()
            # Discuss book with AI
            if menu_experiment == 0:
                try:
                    icon = common_icons.get_icon('ai.png')
                except Exception:
                    icon = None
                if icon:
                    discuss_act = menu.addAction(icon, _('Discuss book with AI'))
                else:
                    discuss_act = menu.addAction(_('Discuss book with AI'))
                discuss_act.triggered.connect(lambda checked=False: self._trigger_discuss_book())
            self._add_generate_cover_action(menu)
            # Separate the AI Config settings entries from the calibre actions
            menu.addSeparator()
            for action in ACTIONS:
                try:
                    icon = common_icons.get_icon(action['icon'])
                except Exception:
                    icon = None
                label = ACTION_MENU_LABELS.get(action['key'], action['label'])
                if icon:
                    settings_act = menu.addAction(icon, label)
                else:
                    settings_act = menu.addAction(label)
                action_enabled = self._action_enabled(action)
                settings_act.setEnabled(action_enabled)
                desc = action.get('description') or label
                if action.get('requires_cyoa') and not action_enabled:
                    desc = cyoa_disabled_tooltip()
                settings_act.setToolTip(desc)
                settings_act.setStatusTip(desc)
                settings_act.triggered.connect(lambda checked=False, k=action['key']: self._open_action_settings(k))

            try:
                icon = common_icons.get_icon('images/icon_cyoa.png')
            except Exception:
                icon = None
            game_label = _('AI Config: Launch CYOA game')
            if icon:
                cyoa_act = menu.addAction(icon, game_label)
            else:
                cyoa_act = menu.addAction(game_label)
            cyoa_act.setEnabled(cyoa_menu_enabled())
            if cyoa_menu_enabled():
                desc = _('Open Create Your Own Adventure')
            else:
                desc = cyoa_disabled_tooltip()
            cyoa_act.setToolTip(desc)
            cyoa_act.setStatusTip(desc)
            cyoa_act.triggered.connect(lambda checked=False: self.open_cyoa())
            menu.addSeparator()
        except Exception:
            pass
        self.current_provider_action = wa  # For compatibility in update_current_provider

        # --- Features merged from the AI Tweaks plugin ---
        menu.addSeparator()

        # The web search toggle and the payload test tool used to live here, but
        # both are available in the configuration dialog, so the menu does not
        # duplicate them.

        # Configure AI Config (same pattern as other workspace plugins)
        config_act = menu.addAction(QIcon.ic('config.png'), _('Configure AI Config...'))
        config_act.triggered.connect(lambda checked=False: self.show_configuration())
        try:
            self.gui.keyboard.register_shortcut(
                'ai_config_configure',
                _('AI Config: Configure plugin'),
                default_keys=(),
                action=config_act,
                description=_('Open the AI Config configuration and testing dialog'),
                group=self.action_spec[0],
                persist_shortcut=True,
            )
        except Exception:
            pass

        # About action (at the last position inside the menu)
        about_act = menu.addAction(QIcon.ic('help.png'), _('About {}…').format(self.name))
        about_act.triggered.connect(self.show_about)

        return menu

    def open_ai_settings_viewer(self):
        try:
            from calibre.gui2.viewer.llm import LLMSettingsDialog as ViewerLLMSettingsDialog
            d = ViewerLLMSettingsDialog(self.gui)
            # Restore last tab index if available
            last_tab = plugin_prefs.get('last_tab_viewer', 0)
            try:
                d.tabs.setCurrentIndex(last_tab)
            except Exception:
                pass
            # Save tab index on change
            try:
                d.tabs.currentChanged.connect(lambda idx: plugin_prefs.__setitem__('last_tab_viewer', idx))
            except Exception:
                pass
            d.exec()
        except Exception:
            import traceback
            traceback.print_exc()

    def open_ai_settings_library(self):
        try:
            from calibre.gui2.dialogs.llm_book import LLMSettingsDialog as BookLLMSettingsDialog
            d = BookLLMSettingsDialog(self.gui)
            # Restore last tab index if available
            last_tab = plugin_prefs.get('last_tab_library', 0)
            try:
                d.tabs.setCurrentIndex(last_tab)
            except Exception:
                pass
            # Save tab index on change
            try:
                d.tabs.currentChanged.connect(lambda idx: plugin_prefs.__setitem__('last_tab_library', idx))
            except Exception:
                pass
            d.exec()
        except Exception:
            import traceback
            traceback.print_exc()

    def open_cover_generation_settings(self):
        """Open calibre's native AI cover generation settings dialog."""
        try:
            from calibre.gui2.dialogs.llm_cover import CoverSettingsDialog
            CoverSettingsDialog(self.gui).exec()
        except Exception:
            import traceback
            traceback.print_exc()

    def open_cyoa_settings(self):
        """Open calibre's Create Your Own Adventure AI settings dialog."""
        if not cyoa_menu_enabled():
            return
        try:
            from calibre.gui2.cyoa.game import SettingsDialog
            SettingsDialog(self.gui).exec()
        except Exception:
            import traceback
            traceback.print_exc()

    def open_cyoa(self):
        """Open calibre's Create Your Own Adventure game window inside the running GUI."""
        if not cyoa_menu_enabled():
            return
        try:
            if getattr(self, '_cyoa_window', None) is not None:
                try:
                    self._cyoa_window.showNormal()
                    self._cyoa_window.raise_()
                    self._cyoa_window.activateWindow()
                    return
                except Exception:
                    self._cyoa_window = None
            from calibre.gui2.cyoa.main import CYOAMainWindow
            w = CYOAMainWindow()
            try:
                w.set_exception_handler()
            except Exception:
                pass
            self._cyoa_window = w
            try:
                w.destroyed.connect(lambda *a: setattr(self, '_cyoa_window', None))
            except Exception:
                pass
            w.show()
        except Exception:
            import traceback
            traceback.print_exc()

    def _on_menu_action_selected(self, key):
        # Set the default action
        try:
            action = self._get_action(key)
            if action is None or not self._action_enabled(action):
                return
            self.set_selected_action(key)
        except Exception:
            pass
        # Do not auto-open settings dialogs when the settings entry is
        # selected. Selecting simply sets the default action for the button.

    def _open_action_settings(self, key):
        action = self._get_action(key)
        if action is None or not self._action_enabled(action):
            return
        cb = getattr(self, action['callback'], None)
        if cb:
            try:
                cb()
            except Exception:
                import traceback
                traceback.print_exc()

    def _get_action(self, key):
        for a in ACTIONS:
            if a['key'] == key:
                return a
        return None

    def _action_enabled(self, action):
        if action.get('requires_cyoa') or not action.get('enabled', True):
            return cyoa_menu_enabled()
        return True

    def _get_selected(self):
        for a in ACTIONS:
            if a['key'] == self.selected_action and self._action_enabled(a):
                return a
        return ACTIONS[0]


    def _update_menu_checks(self):
        menu = getattr(self, 'menu', None)
        if not menu:
            return
        for act in menu.actions():
            try:
                if act.isSeparator():
                    continue
            except Exception:
                pass
            if hasattr(act, 'data'):
                try:
                    k = act.data()
                    if k:
                        act.setChecked(k == self.selected_action)
                except Exception:
                    pass

    def set_selected_action(self, key):
        self.selected_action = normalise_toolbar_action_key(key)
        plugin_prefs[KEY_SELECTED_ACTION] = self.selected_action
        # update icon and tooltip
        sel = self._get_selected()
        try:
            self.qaction.setIcon(common_icons.get_icon(sel['icon']))
            # Do not set the toolbar text; keep the toolbar icon-only
            self._update_tooltip()
        except Exception:
            pass
        # update menu checks
        self._update_menu_checks()

    def trigger_selected_action(self):
        """When the main plugin action is triggered (toolbar button or shortcut),
        open the dialog for the currently selected action."""
        sel = self._get_selected()
        if not self._action_enabled(sel):
            return
        cb = getattr(self, sel['callback'], None)
        if cb:
            try:
                cb()
            except Exception:
                import traceback
                traceback.print_exc()
        # Update menu state to reflect current selection
        self._update_menu_checks()

    def do_action1(self):
        # Open viewer LLM settings
        try:
            self.open_ai_settings_viewer()
        except Exception:
            import traceback
            traceback.print_exc()

    def do_action2(self):
        # Open library/book LLM settings
        try:
            self.open_ai_settings_library()
        except Exception:
            import traceback
            traceback.print_exc()

    def _update_tooltip(self):
        sel = self._get_selected()
        tt = _('Quick access to AI settings (default click: {})').format(sel.get('label', ''))
        try:
            self.qaction.setToolTip(tt)
            self.qaction.setStatusTip(tt)
        except Exception:
            pass

    def show_configuration(self):
        from .tweaks_config import AIConfigDialog
        d = AIConfigDialog(self.gui, icon=self.qaction.icon(), settings_applied=self._sync_selected_action_from_prefs)
        d.exec()
        self._sync_selected_action_from_prefs()

    def _sync_selected_action_from_prefs(self):
        self.selected_action = normalise_toolbar_action_key(plugin_prefs.get(KEY_SELECTED_ACTION, self.selected_action))
        self.rebuild_icon()
        self._update_tooltip()
        self._update_menu_checks()

    def show_test_dialog(self):
        from .tweaks_config import AIConfigDialog
        d = AIConfigDialog(self.gui, icon=self.qaction.icon())
        # Switch to Preview & Testing tab
        if hasattr(d, 'config_widget') and hasattr(d.config_widget, 'tabs'):
            d.config_widget.tabs.setCurrentIndex(1)
            d.config_widget.update_payload_preview()
        d.exec()

    def show_about(self):
        """Open the custom About dialog (non-modal, geometry-saving) matching the EBD pattern."""
        if getattr(self, '_about_dialog', None) is not None:
            try:
                self._about_dialog.showNormal()
                self._about_dialog.raise_()
                self._about_dialog.activateWindow()
                return
            except Exception:
                self._about_dialog = None
        d = AIConfigAboutDialog(self, self.gui)
        self._about_dialog = d
        try:
            d.finished.connect(lambda *a: setattr(self, '_about_dialog', None))
        except Exception:
            pass
        d.show()

    def _add_generate_cover_action(self, menu):
        """Add the calibre 'AI generate cover' action to the menu, if available."""
        if calibre_version < (9, 14, 0):
            return
        act = menu.addAction(QIcon.ic('ai.png'), _('AI generate cover'))
        act.setToolTip(_('Generate covers for books using AI'))
        act.setStatusTip(_('Generate covers for books using AI'))
        act.triggered.connect(lambda checked=False: self._trigger_generate_covers())
        # The native action is disabled outside the library view; mirror that
        try:
            loc = self.gui.location_manager.location
            act.setEnabled(loc == 'library')
        except Exception:
            pass

    def _trigger_generate_covers(self):
        """Trigger calibre's native 'AI Generate Cover' action if available."""
        try:
            ia = self.gui.iactions.get('AI Generate Cover')
            if ia is None:
                return
            try:
                if hasattr(ia, 'menuless_qaction') and ia.menuless_qaction:
                    ia.menuless_qaction.trigger()
                    return
            except Exception:
                pass
            try:
                if hasattr(ia, 'qaction') and ia.qaction:
                    ia.qaction.trigger()
                    return
            except Exception:
                pass
        except Exception:
            import traceback
            traceback.print_exc()

    def _trigger_discuss_book(self):
        """Trigger the global 'Discuss book with AI' action if available.
        This tries a few common entry points so it works across calibre builds.
        """
        try:
            ia = None
            try:
                ia = self.gui.iactions.get('Discuss book with AI')
            except Exception:
                try:
                    ia = self.gui.iactions['Discuss book with AI']
                except Exception:
                    ia = None

            if ia:
                try:
                    if hasattr(ia, 'ask_ai'):
                        ia.ask_ai()
                        return
                except Exception:
                    pass
                try:
                    if hasattr(ia, 'menuless_qaction') and ia.menuless_qaction:
                        ia.menuless_qaction.trigger()
                        return
                except Exception:
                    pass
                try:
                    if hasattr(ia, 'qaction') and ia.qaction:
                        ia.qaction.trigger()
                        return
                except Exception:
                    pass
        except Exception:
            import traceback
            traceback.print_exc()

    def _display_provider_name(self, provider_name: str, model: object) -> str:
        """Return the name to show for the active provider.

        Calibre only knows the generic provider name ('OpenAI compatible'), but
        the plugin serves several named profiles through it. When the active
        profile is the one currently mirrored into calibre's prefs, show the
        profile's own name so the menu reflects the user's choice.
        """
        try:
            from calibre.ai.openai_compatible import OpenAICompatible
            if provider_name != OpenAICompatible.name:
                return provider_name
            from calibre_plugins.ai_config.tweaks_config import active_ai_profile
            profile = active_ai_profile()
            label = str(profile.get('name') or '').strip()
            if not label:
                return provider_name
            # Only relabel when the profile really is what calibre would use;
            # otherwise the menu would misreport the effective provider.
            profile_model = str(profile.get('text_model') or '').strip()
            if profile_model and profile_model != str(model or '').strip():
                return provider_name
            return label
        except Exception:
            return provider_name

    def _on_menu_about_to_show(self):
        if hasattr(self, 'current_provider_action') and self.current_provider_action is not None:
            self.current_provider_action.setVisible(True)
        self.update_current_provider()

    def _on_menu_about_to_hide(self):
        if hasattr(self, 'current_provider_action') and self.current_provider_action is not None:
            self.current_provider_action.setVisible(False)

    def _get_provider_pixmap(self, provider_name: str | None, size: int = 18):
        icon_map = {
            'OpenRouter': 'images/openrouter_icon.png',
            'GoogleAI': 'images/google_icon.png',
            'Google AI': 'images/google_icon.png',
            'Google': 'images/google_icon.png',
            'GitHubAI': 'images/github_icon.png',
            'GitHub AI': 'images/github_icon.png',
            'GitHub': 'images/github_icon.png',
            'OllamaAI': 'images/ollama_icon.png',
            'Ollama AI': 'images/ollama_icon.png',
            'Ollama': 'images/ollama_icon.png',
            'LMStudio': 'images/lm_studio_icon.png',
            'LM Studio': 'images/lm_studio_icon.png',
            'OpenAI': 'images/open_ai_icon.png',
            'OpenAI compatible': 'images/open_ai_compatible_icon.png',
            'OpenAICompatible': 'images/open_ai_compatible_icon.png',
            'Anthropic': 'images/anthropic_icon.png',
            'AnthropicAI': 'images/anthropic_icon.png',
            'Anthropic AI': 'images/anthropic_icon.png',
            'Grok': 'images/grok_icon.png',
            'GrokAI': 'images/grok_icon.png',
            'Grok AI': 'images/grok_icon.png',
            'Venice AI': 'images/veniceai_icon.png',
            'Venice': 'images/veniceai_icon.png',
            'VeniceAI': 'images/veniceai_icon.png',
        }
        icon_name = icon_map.get(provider_name, 'images/default_provider_icon.png')
        try:
            icon = common_icons.get_icon(icon_name)
            return icon.pixmap(size, size)
        except Exception:
            from qt.core import QPixmap
            return QPixmap()

    def _extract_model_display(self, provider_name: str, raw_model: Any) -> tuple[str, list[str]]:
        """Extract a friendly display string and raw model IDs for a given model pref value.

        Returns (friendly_display_string, list_of_raw_ids).
        """
        def _fmt_one(m):
            try:
                if isinstance(m, (tuple, list)):
                    if len(m) >= 2:
                        return str(m[1])
                    return str(m[0])
                if isinstance(m, dict):
                    if 'name' in m:
                        return str(m.get('name') or '')
                    return str(m.get('id') or m)
                if isinstance(m, str):
                    if m == 'auto':
                        return _('Automatic')
                    return m
                return str(m)
            except Exception:
                return str(m)

        def _id_one(m):
            try:
                if isinstance(m, (list, tuple)):
                    if len(m) >= 1:
                        return str(m[0])
                    return ''
                if isinstance(m, dict):
                    for k in ('id', 'model_id', 'value'):
                        if k in m and m.get(k):
                            return str(m.get(k))
                    return ''
                return str(m)
            except Exception:
                return ''

        ids = []
        if isinstance(raw_model, (list, tuple)) and not isinstance(raw_model, str):
            if len(raw_model) == 2 and isinstance(raw_model[0], str) and isinstance(raw_model[1], str):
                formatted = raw_model[1]
                ids.append(raw_model[0])
            else:
                parts = [_fmt_one(x) for x in raw_model]
                formatted = ', '.join(x for x in parts if x)
                for it in raw_model:
                    i = _id_one(it)
                    if i:
                        ids.append(i)
        elif isinstance(raw_model, dict):
            formatted = _fmt_one(raw_model)
            i = _id_one(raw_model)
            if i:
                ids.append(i)
        elif isinstance(raw_model, str) and raw_model:
            formatted = _fmt_one(raw_model)
            ids.append(raw_model)
        else:
            formatted = ''

        return formatted, [i for i in ids if i]

    def _build_model_tooltip(self, header_label: str, provider_name: str, friendly_text: str, ids: list[str]) -> str:
        tooltip = f"{header_label} - {provider_name}: {friendly_text}"
        if ids:
            id_only = [r.split(',', 1)[0].strip() if ',' in r else r for r in ids]
            id_line = ', '.join(id_only)
            if id_line and id_line not in tooltip:
                tooltip += '\n' + _('ID: {0}').format(id_line)
            if provider_name == 'OpenRouter' and id_only:
                try:
                    from calibre.ai.open_router.backend import get_available_models
                    models_dict = get_available_models()
                    model_id = id_only[0]
                    if model := models_dict.get(model_id):
                        import datetime
                        metadata_lines = []
                        if isinstance(model.created, datetime.datetime):
                            metadata_lines.append(f'Created: {model.created.strftime("%Y-%m-%d")}')
                        elif isinstance(model.created, int):
                            dt = datetime.datetime.fromtimestamp(model.created, datetime.timezone.utc)
                            metadata_lines.append(f'Created: {dt.strftime("%Y-%m-%d")}')
                        if hasattr(model, 'pricing') and hasattr(model.pricing, 'is_free'):
                            metadata_lines.append(f'Price: {"Free" if model.pricing.is_free else "Paid"}')
                        if hasattr(model, 'is_moderated'):
                            metadata_lines.append(f'Moderation: {"Yes" if model.is_moderated else "No"}')
                        if getattr(model, 'context_length', None):
                            metadata_lines.append(f'Context: {model.context_length // 1024}k')
                        if metadata_lines:
                            tooltip += '\n' + '\n'.join(metadata_lines)
                except Exception:
                    pass
        return tooltip

    def update_current_provider(self):
        self._update_menu_checks()
        prefs().refresh()

        # 1. Update Text provider & model
        p_text = plugin_for_purpose(AICapabilities.text_to_text)
        if p_text:
            raw_text_model = pref_for_provider(p_text.name, 'text_model', '') or pref_for_provider(p_text.name, 'model', '')
            name_text = self._display_provider_name(p_text.name, raw_text_model)
            formatted_text, text_ids = self._extract_model_display(name_text, raw_text_model)
            chosen_text = formatted_text or name_text
            display_text = f"{_('Text')} - {name_text}: {chosen_text}"
            self.provider_text_label.setText(display_text)
            self.provider_icon_label.setPixmap(self._get_provider_pixmap(p_text.name, 18))
            tooltip_text = self._build_model_tooltip(_('Text'), name_text, chosen_text, text_ids)
            self.provider_text_label.setToolTip(tooltip_text)
        else:
            self.provider_text_label.setText(f"{_('Text')}: {_('Not configured')}")
            self.provider_icon_label.clear()
            self.provider_text_label.setToolTip(_('No text AI provider configured'))

        # 2. Update Cover provider & model (if calibre supports cover generation)
        if hasattr(self, 'provider_cover_label') and calibre_version >= (9, 14, 0):
            p_cover = plugin_for_purpose(AICapabilities.text_to_image)
            if p_cover:
                raw_cover_model = (
                    pref_for_provider(p_cover.name, 'text_to_image_model', None)
                    or pref_for_provider(p_cover.name, 'image_model', None)
                    or pref_for_provider(p_cover.name, 'image_model_strategy', None)
                    or pref_for_provider(p_cover.name, 'model', '')
                )
                name_cover = self._display_provider_name(p_cover.name, raw_cover_model)
                formatted_cover, cover_ids = self._extract_model_display(name_cover, raw_cover_model)
                chosen_cover = formatted_cover or _('Automatic')
                display_cover = f"{_('Cover')} - {name_cover}: {chosen_cover}"
                self.provider_cover_label.setText(display_cover)
                self.provider_cover_icon_label.setPixmap(self._get_provider_pixmap(p_cover.name, 18))
                tooltip_cover = self._build_model_tooltip(_('Cover'), name_cover, chosen_cover, cover_ids)
                self.provider_cover_label.setToolTip(tooltip_cover)
            else:
                self.provider_cover_label.setText(f"{_('Cover')}: {_('Not configured')}")
                self.provider_cover_icon_label.clear()
                self.provider_cover_label.setToolTip(_('No cover generation AI provider configured'))

        # 3. Update Game image provider & model (if calibre supports the CYOA game).
        # The game stores its AI choices separately in the cyoa prefs, so read
        # them through calibre's cyoa data helpers rather than the purpose map.
        if hasattr(self, 'provider_game_label'):
            game_name, game_model = self._get_game_image_info()
            if game_name:
                display_game = f"{_('Game images')} - {game_name}: {game_model or _('Automatic')}"
                self.provider_game_label.setText(display_game)
                self.provider_game_icon_label.setPixmap(self._get_provider_pixmap(game_name, 18))
                tooltip_game = self._build_model_tooltip(_('Game images'), game_name, game_model or _('Automatic'), [game_model] if game_model else [])
                self.provider_game_label.setToolTip(tooltip_game)
            else:
                self.provider_game_label.setText(f"{_('Game images')}: {_('Not configured')}")
                self.provider_game_icon_label.clear()
                self.provider_game_label.setToolTip(_('No image generation AI configured for the Create Your Own Adventure game'))

    def _get_game_image_info(self) -> tuple[str, str]:
        """Return (provider_name, model) configured for CYOA scene images."""
        try:
            from calibre.gui2.cyoa import data as cyoa_data
            name = cyoa_data.configured_provider_name('image')
            if not name:
                return '', ''
            model = ''
            try:
                model = cyoa_data.configured_model_name('image') or ''
            except Exception:
                model = ''
            if not model:
                model = str((cyoa_data.ai_settings('image').get('settings') or {}).get('text_model')
                            or (cyoa_data.ai_settings('image').get('settings') or {}).get('model')
                            or '').strip()
            return name, model
        except Exception:
            return '', ''
